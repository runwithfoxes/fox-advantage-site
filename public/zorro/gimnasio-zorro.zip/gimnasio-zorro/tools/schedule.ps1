# The clock, on Windows. Wakes tools\monday.py every 30 minutes through Task Scheduler. The runner
# decides whether there is anything to do. Run this once, in PowerShell, from inside the gym folder:
#
#   powershell -ExecutionPolicy Bypass -File tools\schedule.ps1          install the clock
#   powershell -ExecutionPolicy Bypass -File tools\schedule.ps1 demo     in the room: fires in two minutes, for one member
#   powershell -ExecutionPolicy Bypass -File tools\schedule.ps1 off      remove it
#   powershell -ExecutionPolicy Bypass -File tools\schedule.ps1 status   is it there, and what does heartbeat.log say
#
# Written on a Mac and not yet run on a Windows laptop. If a line fails, tell Isa the line and what it said.
param([string]$mode = "on")
$root = Split-Path -Parent $PSScriptRoot
$name = "ZorroMonday"
$py = (Get-Command python).Source
switch ($mode) {
  "off"    { schtasks /Delete /TN $name /F | Out-Null; Write-Host "removed the clock"; exit }
  "status" { schtasks /Query /TN $name /FO LIST 2>$null; Write-Host "--- heartbeat.log, last 5 lines"; Get-Content "$root\heartbeat.log" -Tail 5 -ErrorAction SilentlyContinue; exit }
  "demo"   { $every = 2;  $args = "--member Z0811" }
  default  { $every = 30; $args = "" }
}
schtasks /Delete /TN $name /F 2>$null | Out-Null
schtasks /Create /TN $name /SC MINUTE /MO $every /TR "`"$py`" `"$root\tools\monday.py`" $args" /F | Out-Null
Write-Host "the clock is set: every $every minutes it wakes tools\monday.py $args"
Write-Host "proof of a run is heartbeat.log in the gym folder, not this line"
