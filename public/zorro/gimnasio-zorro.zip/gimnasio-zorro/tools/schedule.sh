#!/bin/zsh
# The clock, on a Mac. Wakes tools/monday.py every 30 minutes. The runner decides whether there is
# anything to do. Run this once, from inside the gym folder:
#
#   zsh tools/schedule.sh          install the clock
#   zsh tools/schedule.sh demo     in the room: fires in two minutes, for one member, then finds it done
#   zsh tools/schedule.sh off      remove it
#   zsh tools/schedule.sh status   is it loaded, and what does heartbeat.log say
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$(dirname "$HERE")"
LABEL="com.zorro.monday"; PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"; LOG="$ROOT/clock.log"
mkdir -p "$HOME/Library/LaunchAgents"
PY="$(command -v python3)"; CLAUDE_DIR="$(dirname "$(command -v claude)")"
case "${1:-on}" in
  off) launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true; rm -f "$PLIST"; echo "removed the clock"; exit 0;;
  status) launchctl print "gui/$(id -u)/$LABEL" 2>/dev/null | grep -E "state|last exit" || echo "the clock is not loaded"; echo "--- heartbeat.log, last 5 lines"; tail -5 "$ROOT/heartbeat.log" 2>/dev/null || echo "no heartbeat yet"; exit 0;;
  demo) INTERVAL=120; ARGS="<string>--member</string><string>Z0811</string>";;
  on|*) INTERVAL=1800; ARGS="";;
esac
launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
cat > "$PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array><string>$PY</string><string>$ROOT/tools/monday.py</string>$ARGS</array>
  <key>WorkingDirectory</key><string>$ROOT</string>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>$CLAUDE_DIR:$PATH</string><key>HOME</key><string>$HOME</string></dict>
  <key>RunAtLoad</key><false/>
  <key>StartInterval</key><integer>$INTERVAL</integer>
  <key>StandardOutPath</key><string>$LOG</string>
  <key>StandardErrorPath</key><string>$LOG</string>
</dict></plist>
PL
launchctl bootstrap "gui/$(id -u)" "$PLIST"
echo "the clock is set: every $INTERVAL seconds it wakes tools/monday.py $ARGS"
echo "proof of a run is heartbeat.log in the gym folder, not this line"
