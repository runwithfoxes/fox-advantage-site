"""The runner. This is what the clock starts. On a Monday nobody types anything.

It runs your four agents in order, each one as a page Claude Code reads, and stops the moment one of
them has not left the file its page promised:
  1. carlos.md    writes carlos-out.json
  2. enrique.md   reads carlos-out.json, writes enrique-out.json
  3. cato.md      reads both, writes cato-out.json
  4. rosa.md      two weeks after a Monday with emails, writes rosa-out.json for that Monday
Every step writes one line to heartbeat.log in this folder. The last line for a Monday says done, or
where it stopped. That file is the proof it ran. A clock that says "loaded" proves nothing.

Most ticks of the clock do nothing: it is not a Monday, or this Monday is already done. That is on
purpose. A laptop with the lid closed at 6am misses a 6am alarm, so the runner asks "has this week's
Monday been done?" every time it wakes.

  python3 tools/monday.py                          this week's Monday, once
  python3 tools/monday.py --monday 2026-08-31      a named Monday
  python3 tools/monday.py --member Z0811 --force   one member, again, in the room, to watch it go
"""
import os, subprocess, sys
from datetime import date, datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
HEART = os.path.join(ROOT, 'heartbeat.log')
args = sys.argv[1:]
force = '--force' in args
member = args[args.index('--member') + 1] if '--member' in args else ''
if '--monday' in args: monday = date.fromisoformat(args[args.index('--monday') + 1])
else:
    today = date.today(); monday = today - timedelta(days=today.weekday())
M = monday.isoformat(); BACK = (monday - timedelta(days=14)).isoformat()
scope = f'for member {member} only' if member else 'for every member in data/members.csv'

# The four agents. Each one is a page in this folder, and the file its page says it writes.
AGENTS = [
    ('carlos', 'carlos.md', 'carlos-out.json', f'Read carlos.md and do what it says {scope}, as of Monday {M}. Write the file carlos.md says to write.'),
    ('enrique', 'enrique.md', 'enrique-out.json', f'Read enrique.md, the three pages in messaging, and carlos-out.json. Do what enrique.md says {scope}, as of Monday {M}. Write the file enrique.md says to write.'),
    ('cato', 'cato.md', 'cato-out.json', f'Read cato.md and pages/cato-brief.md. Do what they say {scope}, as of Monday {M}, without reading carlos-out.json or enrique-out.json until you have your own answer. Then compare, and write the file cato.md says to write.'),
    ('rosa', 'rosa.md', 'rosa-out.json', f'Read rosa.md. Do what it says for the emails sent on Monday {BACK}, reading the check-ins for the fourteen days from that Monday. Write the file rosa.md says to write.'),
]

def beat(text):
    line = f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} monday={M} {text}'
    open(HEART, 'a').write(line + '\n'); print(line)

def done_already():
    return os.path.exists(HEART) and any(f'monday={M} done' in l for l in open(HEART).read().split('\n'))

if done_already() and not force:
    print(f'{M} is already done in heartbeat.log; nothing to do'); sys.exit(0)

beat('start' + (f' (member {member})' if member else ''))
for name, page, out, ask in AGENTS:
    if not os.path.exists(os.path.join(ROOT, page)):
        beat(f'{name} skipped: no {page} in the folder yet'); continue
    before = os.path.getmtime(os.path.join(ROOT, out)) if os.path.exists(os.path.join(ROOT, out)) else 0
    r = subprocess.run(['claude', '-p', ask, '--permission-mode', 'acceptEdits', '--allowedTools', 'Read', 'Write', 'Edit', 'Bash(python3:*)', 'Bash(python:*)'],
                       cwd=ROOT, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=1800)
    written = os.path.exists(os.path.join(ROOT, out)) and os.path.getmtime(os.path.join(ROOT, out)) > before
    ok = r.returncode == 0 and written
    beat(f'{name} {"ok" if ok else "FAILED"}: {out} {"written" if written else "was not written"}')
    if not ok:
        beat(f'STOPPED at {name}. Nothing after it ran. Claude said: {(r.stdout.strip() or r.stderr.strip())[-300:]}')
        sys.exit(1)
beat('done')
