"""The Attio layer for Gimnasio Zorro. Token from the vault, never from here.
Fields on People, import of the 900, and the writes Enrique makes to a record.

  python3 agent/attio.py setup      create the member fields on People (safe to rerun)
  python3 agent/attio.py import     upsert the 900 members by email
  python3 agent/attio.py count      how many people are in the workspace
"""
import csv, json, os, sys, time, urllib.error, urllib.request
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # the gym folder, one up from tools/
def _token():
    """Paul's vault first; a student's .env in this folder second (ATTIO_TOKEN=... on one line)."""
    for path, key in ((os.path.expanduser('~/.secrets/keys.env'), 'ATTIO_ZORRO_TOKEN='), (os.path.join(ROOT, '.env'), 'ATTIO_TOKEN='), (os.path.join(ROOT, '.env'), 'ATTIO_ZORRO_TOKEN=')):
        if os.path.exists(path):
            hits = [l for l in open(path) if l.startswith(key)]
            if hits: return hits[-1].split('=', 1)[1].strip().strip('"').strip("'")
    raise SystemExit('No Attio token. Put ATTIO_TOKEN=... in a file called .env in this folder.')
TOK = _token()
H = {'Authorization': 'Bearer ' + TOK, 'Content-Type': 'application/json'}
API = 'https://api.attio.com/v2'

def call(method, path, payload=None, retries=4):
    body = json.dumps(payload).encode() if payload is not None else None
    for i in range(retries):
        req = urllib.request.Request(API + path, data=body, method=method, headers=H)
        try:
            return json.load(urllib.request.urlopen(req))
        except urllib.error.HTTPError as e:
            txt = e.read().decode()
            if e.code == 429 or e.code >= 500:
                time.sleep(1.5 * (i + 1)); continue
            raise SystemExit(f'{method} {path} -> {e.code} {txt[:400]}')
    raise SystemExit(f'{method} {path} kept failing')

FIELDS = [  # api_slug, title, type
    ('member_id', 'Member id', 'text'),
    ('plan', 'Plan', 'text'),
    ('goal', 'Goal', 'text'),
    ('joined', 'Joined', 'date'),
    ('gym_notes', 'Notes from the desk', 'text'),
    ('status', 'Status', 'select'),
    ('last_flag_week', 'Last flagged', 'text'),
    ('reason', 'Reason', 'text'),
    ('draft_note', 'Draft note', 'text'),
    ('outcome', 'Outcome', 'text'),
    ('cato_check', 'Cato check', 'text'),
    ('cato_verdict', 'Marta on Cato', 'text'),
]
STATUS = ['steady', 'slipping', 'emailed', 'ask marta', 'came back', "didn't come back"]   # renamed 11 Sep 2026 to match the slides

def setup():
    have = {a['api_slug'] for a in call('GET', '/objects/people/attributes')['data']}
    for slug, title, typ in FIELDS:
        if slug in have: print('have', slug); continue
        call('POST', '/objects/people/attributes', {'data': {'title': title, 'api_slug': slug, 'type': typ,
             'is_required': False, 'is_unique': False, 'is_multiselect': False, 'description': 'Gimnasio Zorro', 'config': {}}})
        print('made', slug)
    opts = {o['title'] for o in call('GET', '/objects/people/attributes/status/options')['data']}
    for s in STATUS:
        if s not in opts: call('POST', '/objects/people/attributes/status/options', {'data': {'title': s}}); print('option', s)

def upsert(row, extra=None):
    values = {'name': [{'first_name': row['first_name'], 'last_name': row['last_name'], 'full_name': f"{row['first_name']} {row['last_name']}"}],
              'email_addresses': [{'email_address': row['email']}],
              'member_id': [{'value': row['member_id']}], 'plan': [{'value': row['plan']}], 'goal': [{'value': row['goal']}],
              'joined': [{'value': row['joined']}], 'gym_notes': [{'value': row['notes'] or ''}], 'status': [{'option': 'steady'}]}
    if extra: values.update(extra)
    return call('PUT', '/objects/people/records?matching_attribute=email_addresses', {'data': {'values': values}})

def do_import():
    rows = list(csv.DictReader(open(os.path.join(ROOT, 'data', 'members.csv'))))
    ids = {}
    for i, r in enumerate(rows, 1):
        d = upsert(r); ids[r['member_id']] = d['data']['id']['record_id']
        if i % 100 == 0: print(i, 'done')
    json.dump(ids, open(os.path.join(ROOT, 'attio_ids.json'), 'w'), indent=0)
    print('imported', len(ids), 'members; record ids saved')

def count():
    n = 0; cursor = None
    while True:
        d = call('POST', '/objects/people/records/query', {'limit': 500, 'offset': n})
        n += len(d['data'])
        if len(d['data']) < 500: break
    print('people in workspace:', n)

if __name__ == '__main__' and sys.argv[1] in ('setup', 'import', 'count'):
    {'setup': setup, 'import': do_import, 'count': count}[sys.argv[1]]()


def write_decisions(asof):
    """Enrique's Monday onto the records: status, last flagged, reason, the email. Skips stay steady.
    Since 10 Sep the agent sends, so a draft lands as emailed (this week the send is the email log)."""
    ids = json.load(open(os.path.join(ROOT, 'attio_ids.json')))
    dec = json.load(open(os.path.join(ROOT, 'enrique-out.json')))['decisions']
    n = 0
    for x in dec:
        if x['decision'] == 'skip': continue
        status = 'emailed' if x['decision'] == 'draft' else 'ask marta'
        call('PATCH', f"/objects/people/records/{ids[x['member_id']]}", {'data': {'values': {
            'status': [{'option': status}], 'last_flag_week': [{'value': asof}],
            'reason': [{'value': x['reason'][:2000]}], 'draft_note': [{'value': (x.get('email') or '')[:5000]}]}}})
        n += 1
    print('written', n, 'flags and asks for', asof)

def write_returns(asof):
    """Two weeks on: returned or not, onto the same records."""
    ids = json.load(open(os.path.join(ROOT, 'attio_ids.json')))
    ret = json.load(open(os.path.join(ROOT, 'rosa-out.json')))
    for x in ret['members']:
        call('PATCH', f"/objects/people/records/{ids[x['member_id']]}", {'data': {'values': {
            'status': [{'option': 'came back' if x['returned'] else "didn't come back"}],
            'outcome': [{'value': f"{'Back' if x['returned'] else 'Not back'} in the two weeks after {asof}. Visits: {x['visits_after']}." + (f" Replied: {x['reply_text']}" if x.get('reply_text') else '')}]}}})
    print('written outcomes for', len(ret['members']), 'members;', ret['came_back'], 'returned')

if __name__ == '__main__' and sys.argv[1] in ('decisions', 'returns'):
    {'decisions': write_decisions, 'returns': write_returns}[sys.argv[1]](sys.argv[2] if len(sys.argv) > 2 else '2026-08-31')


def write_cato(asof):
    """Cato's line onto the record where he disagrees; cleared where he agrees."""
    ids = json.load(open(os.path.join(ROOT, 'attio_ids.json')))
    c = json.load(open(os.path.join(ROOT, 'cato-out.json')))
    memory_had = json.load(open(os.path.join(ROOT, 'memory.json')))
    n = 0
    for l in c['lines']:
        val = f"{asof}: Cato says {l.get('cato_decision')}. {l['why']}"[:2000] if l['verdict'] == 'disagree' else None
        if val is None and not memory_had.get(l['member_id']): continue
        call('PATCH', f"/objects/people/records/{ids[l['member_id']]}", {'data': {'values': {'cato_check': [{'value': val}] if val else []}}})
        n += 1
    print('cato lines written:', n)

if __name__ == '__main__' and sys.argv[1] == 'cato':
    write_cato(sys.argv[2] if len(sys.argv) > 2 else '2026-08-31')
