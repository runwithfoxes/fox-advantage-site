# How a Monday runs at Gimnasio Zorro. The runbook, not a job description.

Three roles, each on its own page under students/. Carlos pulls the numbers and cannot write
(prepare_week.py is his code). Enrique judges and writes (judge.py runs him headless). Cato doubts
both (cato.py). check_returns.py is the two-week check. Nothing in the scripts decides who gets
written to or what a note says; that is Enrique's, and Cato's to attack.

## The job

Every Monday, for Gimnasio Zorro, find the members who are drifting away from their own pattern,
write each one a short email in Marta's voice off what they said they wanted, send it, and put the
reason and the email on their record. Two weeks later, say how many came back. Never chase someone
whose record gives a reason. When a reply needs a human, ask Marta instead of writing.

Paul, 10 Sep 2026: the agent sends. There is no approval step. Marta is only asked about the odd
case. This week the gym is made up, so a send means the email goes into the email log
(data/email_log.csv) and the card in Attio moves to emailed.

## How a Monday goes

1. Run `python3 agent/prepare_week.py <monday>`. It writes `agent/out/candidates-<monday>.json`
   with every member's usual rate, last three weeks, notes, and what the agent did for them before.
2. Read that file with `messaging/email-voice-and-rules.md` and `messaging/messages-by-goal.md`
   open. For each member decide one of three things. DRAFT: they are drifting from their own usual
   pattern, they joined more than four weeks ago, they have not been gone eight weeks or more,
   the record gives no reason, and they were not written to in the last four weeks. Write the note.
   SKIP: none of that is true. Say why in one line. ASK MARTA: the record or a reply says something
   only she can judge (injured, moved, wants to pause, angry). Say what and why.
3. Write the decisions to `agent/out/decisions-<monday>.json`, one row per member, in this shape:
   member_id, name, decision (draft / skip / ask), reason (one line quoting the data), email (or
   empty). The shape never changes.
4. Update `agent/state/memory.json`: for every draft or ask, record flagged_on, action, name, and
   the reason. This is what stops the same person being written to twice.
5. Put the reason and the email on the member's record in Attio and set their status: emailed for a
   draft, ask marta for an ask. The columns are steady, slipping, emailed, ask marta, came back,
   didn't come back.

## Two weeks later

Run `python3 agent/check_returns.py <that monday>`. It reads memory and the door log, counts who
came back, reads the email log for replies, and prints the line Marta gets. Replies from people who
did not come back are listed for her, because those are hers to answer.

## What "the same shape every time" means

Two runs on the same Monday must give the same decisions. A second run on a Monday that has already
been run must draft nothing new. That is the test, and it is run in the room on Tuesday.
