> This is Paul's reference runbook, kept here so you can see how the four agents hand work along.
> The script names in it (agent/prepare_week.py and the rest) are his build and are not in your folder.
> In your folder the agents are carlos.md, enrique.md, cato.md and rosa.md, their files land beside
> them, tools/monday.py is the runner and tools/schedule.sh or schedule.ps1 is the clock. Found 12 Sep:
> a Claude Code told to "build me an agent" read this page and went looking for scripts that were not there.

# How a Monday runs at Gimnasio Zorro. The runbook, not a job description.

Four roles, each on its own page under students/. Carlos pulls the numbers and cannot write
(prepare_week.py is his code). Enrique judges and writes (judge.py runs him headless). Cato doubts
both (cato.py). Rosa counts who came back two weeks later (check_returns.py). Nothing in the scripts
decides who gets written to or what a note says; that is Enrique's, and Cato's to attack.

## The job

Every Monday, for Gimnasio Zorro, find the members who are drifting away from their own pattern,
write each one a short email in Marta's voice off what they said they wanted, send it, and put the
reason and the email on their record. Two weeks later, say how many came back. Never chase someone
whose record gives a reason. When a reply needs a human, ask Marta instead of writing.

Paul, 10 Sep 2026: the agent sends. There is no approval step. Marta is only asked about the odd
case. This week the gym is made up, so a send means the email goes into the email log
(data/email_log.csv) and the card in Attio moves to emailed.

## What starts it

Nobody. Paul, 12 Sep 2026: "We are showing students how to build agents that run on their own, not
commands." So a clock on the laptop wakes agent/monday.py every 30 minutes (agent/schedule.sh
installs it). The runner asks two questions, is it Monday and is this Monday done, and if the answers
are yes and no it runs the four in order. Each one starts only when the one before has left its file.
If a file is missing the run stops there and the heartbeat says where.

Every step writes one line to agent/state/heartbeat.log. That file is the proof a run happened. A
clock that says it is loaded proves nothing, and neither does a note in this file.

Why a tick every 30 minutes rather than an alarm at 6am: a laptop with the lid shut at 6am misses
the alarm and it is not made up. A tick asks "is this Monday done?" whenever the laptop is awake.
In a company the same four pages would run in the cloud, on Anthropic's Managed Agents or the like,
on their own timetable, with no laptop involved.

## How a Monday goes, when the runner does it

1. Carlos. `python3 agent/prepare_week.py <monday>` writes `agent/out/candidates-<monday>.json`
   with every member's usual rate, last three weeks, notes, and what the agent did for them before.
2. Enrique. `python3 agent/judge.py <monday>` reads that file with
   `messaging/email-voice-and-rules.md` and `messaging/messages-by-goal.md` open. For each member
   he decides one of three things. DRAFT: they are drifting from their own usual pattern, they
   joined more than four weeks ago, they have not been gone eight weeks or more, the record gives no
   reason, and they were not written to in the last four weeks. He writes the note. SKIP: none of
   that is true, and he says why in one line. ASK MARTA: the record or a reply says something only
   she can judge (injured, moved, wants to pause, angry). He writes `agent/out/decisions-<monday>.json`,
   one row per member, always the same shape: member_id, name, decision (draft / skip / ask), reason
   (one line quoting the data), email (or empty). He updates `agent/state/memory.json` for every
   draft or ask, which is what stops the same person being written to twice.
3. Cato. `python3 agent/cato.py <monday>` recounts from the door log himself, decides for each
   member himself, and writes `agent/out/cato-<monday>.json` with agree or disagree per row and the
   attack list.
4. Rosa. If there was a Monday with emails fourteen days earlier and she has not checked it,
   `python3 agent/check_returns.py <that monday>` reads memory and the door log, counts who came
   back, reads the email log for replies, writes `agent/out/returns-<that monday>.json`, and prints
   the line Marta gets. Replies from people who did not come back are listed for her, because those
   are hers to answer.
5. Attio. `python3 agent/attio.py decisions <monday>` puts the reason and the email on each card and
   sets the status: emailed for a draft, ask marta for an ask. `python3 agent/attio.py returns <that
   monday>` moves Rosa's members to came back or didn't come back. The columns are steady, slipping,
   emailed, ask marta, came back, didn't come back.

To do any of that by hand, for a test, run the script named. To do the whole Monday by hand once:
`python3 agent/monday.py --monday <monday>`. A second run on the same Monday does nothing and says
so; `--force` runs it again.

## What "the same shape every time" means

Two runs on the same Monday must give the same decisions. A second run on a Monday that has already
been run must draft nothing new. That is the test, and it is run in the room on Tuesday.
