# Before Monday 14 September. Please do these four things

You are going to build a working AI agent for a gym during the week, in a team of three, and on
Friday you will show it running and tell us how well it did. To start building on Monday afternoon
you need four things set up before you walk in. Each one takes a few minutes. Do them this week,
not on the bus.

## 1. Claude

Your access to Claude for the week is being arranged by Smurfit; Julie will confirm the details.
Whatever plan it is, make sure you can log in at claude.ai before Monday and that you know your
password. On Monday afternoon you will be building with Claude Code, which runs on your laptop in
a terminal. Install it now so Monday is not spent installing. Go to claude.ai/code and follow the
install steps for your machine (Mac or Windows). Open a terminal, type claude, log in with the
same account. If it opens and says hello, you are done.

## 2. Attio

Attio is the CRM the gym's members live in, and your agent will read and write it. Sign up for a
free account at attio.com with your university email. One person per team creates the workspace
and names it after your team (Zorro Team 4, say), then invites the other two. The free plan allows
three people, which is why teams are three. Do not pay for anything.

## 3. The gym

You will receive a folder called Gimnasio Zorro on Monday morning. It has the members, fourteen
weeks of door swipes, and three short pages about the gym and how its owner writes. Have a place
on your laptop to put it. That is all.

## 4. Your laptop

Charged, with a terminal you can open (Terminal on a Mac, Windows Terminal or PowerShell on
Windows), and enough battery for a full day. The room has power but not at every seat.

## What you will build

Every Monday, your agent reads the gym's door log and the member records, finds the members who
are drifting away, writes each one a short personal email, sends it, and records what it did in
Attio. Two weeks later it looks again and tells the owner how many came back. On
Friday you present the number your agent scored on fifty marked members, and your two worst
mistakes.

## If something will not install

Tell Julie before Monday, not on Monday. If Claude Code will not go on your machine we can still
run Monday in the browser, but you will want it working by Tuesday.
