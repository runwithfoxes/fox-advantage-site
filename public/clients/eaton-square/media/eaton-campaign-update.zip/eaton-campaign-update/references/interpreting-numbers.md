# Interpreting the numbers

Read this before judging any campaign number. It keeps the read honest and stops good campaigns being called failures.

## The 95:5 read (the most important lens)

At any moment, only a small slice of any market is actually in a buying window - roughly 5% (the "95:5" principle; the exact figure varies by category). You don't know which 5%. The job of outreach is to stay visible to all of them so you're remembered when they do enter the market.

What this means when you read numbers:
- **An accepted LinkedIn connection who never replies is a win, not a miss.** They now see the content and build familiarity. Report it as a memory gain.
- **Email opens and clicks matter more than instant replies.** A reply is a bonus signal, not the success metric.
- Never describe an accepted-but-quiet connection as a "non-converting lead." It converted to memory.

So the headline metric is **pool growth** (connections, reach), with replies and meetings as the rarer, higher-value events on top.

## The metrics pyramid (report bottom-up, think top-down)

- **L1 Commercial:** revenue, clients won
- **L2 Behaviour:** meetings, proposals
- **L3 Memory:** connections, followers, reach  ← the primary outreach metric
- **L4 Response:** accept rate, opens, replies
- **L5 Activity:** sends per day, emails out

Report from the bottom (what was sent) up to the top (what it produced), but judge value from the top down. A week of high L5 with growing L3 is healthy even if L2 is still zero.

## What counts as "low" (when to flag)

- **List runway:** look at the "not started yet" count - the leads still queued, untouched. If it's at or near **zero**, the list is worked through: once the in-progress leads finish, the campaign coasts to a stop. Flag it for a top-up. (A campaign showing 0 "not started" with leads still "in progress" is healthy now but about to run dry - say that.)
- **Mind the schedule.** Before calling a campaign slow or stalled, check its send schedule. Most send weekdays only, so quiet weekends/Sundays are normal. Only flag a slowdown on days it's actually scheduled to send.
- **A rate dropping below its own baseline:** compare each campaign to its own recent runs, not to invented industry numbers. If accept rate or reply rate falls clearly below where this campaign normally sits, flag it and look at the list quality or the message.
- Do **not** invent benchmark percentages. The campaign's own running average is the truth. If there's no baseline yet, say it's too early to judge and just report the raw numbers.

## Attention flags (what to surface, most urgent first)

1. **Positive reply waiting** - someone replied with interest. Needs a human response, ideally within a day. Surface who and offer to draft a reply.
2. **Email not sending** - if Smartlead numbers are zero, the sending email (domain + mailbox, warmed up) is probably not set up yet. This is the known blocker; name it, don't read it as failure.
3. **Low list runway** - a campaign about to run dry (see above).
4. **Accepted but no follow-up** - connections that accepted on LinkedIn but haven't had an email follow-up are warm targets for the email side once it's live.
5. **Bounce or complaint** - any bounced or opted-out contact should be marked do-not-contact and removed from all campaigns.

## A/B and "is it working" - don't call it early

Don't declare a sequence or segment a winner or loser until there's enough to judge: a clear gap between variants, a couple of hundred responses, and a couple of weeks running. Before that, it's "too early," and say so.
