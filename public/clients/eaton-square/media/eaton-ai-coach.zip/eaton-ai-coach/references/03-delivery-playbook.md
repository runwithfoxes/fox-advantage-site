# Module 03: Delivery playbook: real consulting jobs, done faster

*Eight copy-paste prompts for the work Eaton Square does every week.*

---

Most of the time consulting teams spend on documents is not thinking time. It is assembly time: turning scattered notes into a structured output, pulling the key points from a long document, reformatting a table, filling in a template. Claude can handle most of that assembly. You keep your thinking for the parts that matter.

This module gives you eight ready-to-use prompts, one for each of the most common Eaton Square delivery tasks. Copy the prompt, fill in the bracketed parts, attach the relevant file where indicated, and you are off. You will still need to check the output, verify any facts or figures, and apply your own judgement before anything goes to a client. That is not a limitation. That is good consulting practice, and it takes far less time when Claude has done the heavy lifting.

A note on Projects: if you are doing sustained work on a programme, set up a Project in Claude (the dedicated workspace feature, available from the left sidebar). Upload your key reference documents there and give it a short instruction such as "You are a consulting analyst working on a public sector transformation programme. Be concise and precise." Everything in that Project shares the same context, so you spend less time re-explaining the situation each time.

---

### 1. Turn messy workshop or meeting notes into a structured summary or board-pack section

**When to use:** After a workshop, steering group, or working session where you have raw notes but need a clean, presentable write-up quickly. Works equally well from your own typed notes or a transcript.

**Prompt:**

```
I am a management consultant and I need to turn rough meeting notes into a clean summary suitable for a board pack or programme update.

Context: [brief description of the meeting, e.g. "Steering group for a public sector HR transformation, 25 attendees including programme sponsor and three workstream leads"]
Audience: [e.g. "Executive steering committee, not involved in day-to-day delivery"]
Format needed: [e.g. "A one-page summary with: key decisions made, actions agreed (owner and due date), issues raised, and next meeting date"]

Here are the raw notes:

[paste your notes here]

Please produce the structured summary. Flag anything where you were not sure how to interpret the notes, and leave a placeholder rather than guessing.
```

*Attach a transcript or notes document via the paperclip if you prefer not to paste.*

**Worked example:** Sarah pastes two pages of bullet-point scrawl from a digital transformation steering group. She tells Claude the audience is the client's CIO and two board members. Claude returns a one-pager with four clear sections: decisions, actions with owners, risks raised, and next steps. It flags one action where two different owners appear in the notes and asks her to confirm.

**What good looks like:** A clean, confident write-up that reads as though a senior consultant drafted it. Decisions and actions are clearly separated, and the tone matches the audience.

**Watch-out:** Claude will sometimes infer ownership of an action from context. Always check that names and owners are correct before distributing.

---

### 2. Summarise and interrogate a long programme document and pull out the key risks and decisions

**When to use:** When you have inherited a thick programme document, a previous consultant's report, or a client-provided baseline and need to get up to speed quickly without reading every page.

**Prompt:**

```
I am uploading a [type of document, e.g. "programme baseline report / business case / diagnostic review"] for a [brief context, e.g. "large-scale ERP implementation at a financial services firm"].

Please do the following:
1. Summarise the document in no more than 300 words: purpose, scope, and main conclusions.
2. List the top five risks identified in the document, with any mitigations mentioned.
3. List the key decisions that have been made or that are still outstanding.
4. Flag any gaps or inconsistencies you notice in the document.

I will follow up with questions once I have read your summary.
```

*Attach the document via the paperclip icon. Claude can handle PDFs and Word documents up to roughly 200 pages.*

**Worked example:** Shane uploads a 75-page programme assurance review from a government client. Claude returns a tight executive summary, a ranked risk list (top risk: "No confirmed business owner for the data migration workstream"), and a list of three decisions still marked as open in the document. Shane spots that the risk register date is six months old, flags it to the team, and picks up the conversation from there.

**What good looks like:** You can brief a colleague or write a covering note in five minutes, and you know which pages to read in full.

**Watch-out:** Claude reads what is in the document. If the document is out of date or incomplete, the summary will reflect that. Always check the date and version of what you upload.

---

### 3. Build and maintain a RAID log from raw notes

**When to use:** At the start of a programme when you need to create a RAID log from scratch, or when you want to update an existing log after a working session or review. RAID stands for Risks, Assumptions, Issues, and Dependencies.

**Prompt:**

```
I need to create (or update) a RAID log for a programme. Please produce a table with five columns: Type (R/A/I/D), ID, Description, Owner, and Status/Notes.

Programme context: [e.g. "Operating model redesign for a professional services firm, currently in discovery phase"]

Here are the raw inputs to work from:

[paste your notes, meeting outputs, or existing log here]

For any new items: assign a sequential ID (R-01, A-01, etc.), infer the type from context, and leave Owner as TBC where it is not clear. Flag any items where you are unsure of the classification.
```

*If you are updating an existing log, attach the current version via the paperclip and ask Claude to merge the new items in.*

**Worked example:** After a two-hour discovery workshop, Sinead pastes eight bullet points of notes into the prompt. Claude returns a formatted RAID table with six entries: two risks, one assumption, two issues, and one dependency. One item it flags as "could be R or I, please confirm" because the wording was ambiguous.

**What good looks like:** A clean, consistently formatted table you can paste straight into your programme pack, with nothing missed from the raw inputs.

**Watch-out:** RAID items often need a risk rating or priority score. If your template requires that, add a column instruction to the prompt, and then apply your own judgement to the ratings.

---

### 4. Draft a business case

**When to use:** When a client needs to secure internal approval for a programme, investment, or change initiative and you are helping them structure the argument.

**Prompt:**

```
I need to draft a business case for internal approval. Please structure it with the following sections:
1. Executive summary (3-4 sentences)
2. Problem statement: what is the current situation and why does it need to change
3. Options considered (at least three, including a do-nothing option)
4. Costs and benefits for the recommended option (use the figures I provide, or clearly mark as TBC)
5. Recommendation and rationale
6. Key risks and mitigations
7. Next steps

Here is the context:

Organisation: [e.g. "Mid-size UK insurance firm"]
Problem: [describe the issue in 2-3 sentences]
Recommended option: [what you are recommending]
Costs: [any figures you have, or "TBC, to be populated"]
Benefits: [quantified if possible, or qualitative if not]
Timeline: [e.g. "18 months to full implementation"]
Audience: [e.g. "Executive committee, formal approval required"]

Draft the business case in a professional tone suitable for [audience]. Do not invent specific figures. Where I have said TBC, leave a clear placeholder.
```

**Worked example:** Sarah is helping a client build a case for a new shared services centre. She fills in the context, provides rough cost estimates, and lists three qualitative benefits. Claude returns a well-structured five-page draft. The benefits section has clear TBC markers where she has not yet pinned down the numbers. She then fills those in from the finance team's model before the draft goes to the client.

**What good looks like:** A coherent, readable draft that makes the argument clearly and guides the reader to the recommendation without burying them in caveats.

**Watch-out:** Never let Claude invent financial figures. If you do not have the numbers yet, say so explicitly in the prompt and check that all TBC markers are still in the output before you share it.

---

### 5. Draft a change and communications plan

**When to use:** When a programme needs a structured plan for bringing people along: who needs to know what, when, and through which channel.

**Prompt:**

```
I need to draft a change and communications plan for a transformation programme.

Programme: [brief description, e.g. "Rolling out a new finance system across 1,200 staff in three regions"]
Go-live date: [e.g. "September 2026"]
Key audiences: [list them, e.g. "Finance team leads, regional managers, end users, union reps"]
Main change impacts: [what is actually changing for people, e.g. "New processes for month-end close, new system login, mandatory training required"]
Channels available: [e.g. "All-staff email, intranet, team briefings, line manager cascade, training sessions"]
Tone: [e.g. "Reassuring and transparent, avoid jargon"]

Please produce:
1. A summary of the key messages for each audience (2-3 bullet points each)
2. A phased communications timeline from now to go-live, showing what goes out when and through which channel
3. A list of change risks to manage (e.g. resistance, low awareness, unclear ownership)
```

**Worked example:** Shane is running a target operating model implementation at a professional services firm. He fills in five audiences, lists the main impacts, and notes that a union consultation process is running in parallel. Claude returns audience-specific key messages, a month-by-month timeline with channel assignments, and a risk list that includes "union process could delay internal messaging, agree a joint comms protocol." That last point saves him from a potential misstep.

**What good looks like:** A plan that feels tailored to the specific programme, not a generic template with names swapped in. The key messages should reflect the actual change, not just say "we are transforming our ways of working."

**Watch-out:** Change plans need sign-off from the programme sponsor before anything goes out. Use Claude's draft as your working document, not the final artefact.

---

### 6. Build a stakeholder map and stakeholder analysis

**When to use:** At the start of a programme or at a key milestone when you need to understand who matters, how much influence they have, and how to engage them.

**Prompt:**

```
I need to build a stakeholder map and analysis for a programme.

Programme: [brief description]
Organisation type: [e.g. "Public sector body, circa 3,000 staff"]
Phase: [e.g. "Discovery and design, pre-approval"]

Here is my initial stakeholder list:

[list names and roles, e.g.:
- CFO: programme sponsor, high influence, currently supportive
- HR Director: affected by the change, influence medium, uncertain
- IT leadership: technical dependency, high influence, resistant
- Front-line team leads (approx 40): must adopt new ways of working, influence low individually, collectively high
- External auditor: compliance interest, low day-to-day influence]

Please produce:
1. A stakeholder analysis table with columns: Name/Group, Role, Influence (H/M/L), Interest (H/M/L), Current sentiment, Engagement approach
2. A brief narrative (one paragraph per stakeholder or group) on how to manage the relationship
3. Any gaps in the list you would suggest I fill

Format the table so I can copy it into a slide or Word document.
```

**Worked example:** Sarah pastes a list of 12 stakeholders from a large public sector transformation. Claude builds the table, writes brief engagement notes for each, and flags that the list has no entry for communications or HR leads at regional level, suggesting she check whether those roles exist and whether they need to be on the map.

**What good looks like:** A map that gives the team a shared, up-to-date picture of the political landscape. The engagement approaches should be specific, not generic ("brief monthly" is better than "keep informed").

**Watch-out:** Stakeholder sentiment changes. Treat this as a live document and update it after every major milestone or significant conversation.

---

### 7. Design a workshop

**When to use:** When you are facilitating a working session and need to plan the agenda, exercises, and materials. Useful whether you have two hours or a full day.

**Prompt:**

```
I need to design a workshop and produce a facilitation guide.

Workshop purpose: [e.g. "Agree the target operating model structure for the client services function"]
Participants: [e.g. "12 people: two directors, four senior managers, six team leads. Mix of functions."]
Duration: [e.g. "Half day, 9am to 1pm including lunch at 12:30"]
Desired outcomes: [list 2-3 concrete things that should be true at the end, e.g. "1. Agreement on the top-level structure. 2. Identified owners for each function. 3. A prioritised list of design questions still to resolve."]
Known tensions: [e.g. "Two directors have conflicting views on where the client onboarding team should sit"]
Room setup: [e.g. "Boardroom, no breakout space"]
Any constraints: [e.g. "Two participants joining remotely on video"]

Please produce:
1. A timed agenda
2. A description of each exercise or segment, including facilitation notes
3. A list of materials I will need to prepare in advance
4. A suggested approach for handling the known tension
```

**Worked example:** Sinead is designing a two-day operating model workshop for a 20-person senior leadership group. She inputs the tensions (two business units competing for resource), the desired outcomes, and the constraint that day two has a hard stop at 3pm. Claude returns a full agenda with timings, a set of three exercises including a prioritisation activity to surface disagreements without making them personal, and a suggestion to run the tension through a structured options exercise on the morning of day two rather than leaving it to open discussion.

**What good looks like:** An agenda that has a clear build through the day, enough time for discussion, and concrete outputs at each stage. The facilitation notes should tell you what to do if energy drops or the conversation gets stuck.

**Watch-out:** Always review the timing. Claude tends to be optimistic about how long activities take in real rooms with real people. Add buffer, especially around breaks and any exercise involving group discussion.

---

### 8. Write a programme status report from raw inputs

**When to use:** When you need to produce a regular programme update (weekly, fortnightly, or monthly) and you have the raw ingredients but not the time to write it up from scratch.

**Prompt:**

```
I need to write a programme status report for [audience, e.g. "the executive steering committee"].

Programme: [name and one-line description]
Reporting period: [e.g. "Week ending 6 June 2026"]
Overall status (RAG): [Red / Amber / Green] because [one sentence reason]

Progress this period:
[bullet points of what was completed or progressed]

Upcoming milestones:
[what is due in the next 2-4 weeks, with dates]

RAID summary:
[paste key risks, issues, or dependencies to highlight, or attach the RAID log]

Decisions or escalations needed from the steering committee:
[list them, or "None this period"]

Budget: [on track / over / under, with brief note if relevant]

Please write this up as a professional status report in a clear, direct tone. Use a RAG (Red, Amber, Green) status indicator for overall programme health. Keep the narrative tight. The steering committee reads this in under five minutes.
```

*Attach your RAID log or any supporting documents via the paperclip if you want Claude to pull specific items through.*

**Worked example:** Shane has ten minutes before the report is due. He pastes the week's bullet points, notes the programme is Amber because a key vendor decision has slipped two weeks, and lists one escalation needed from the steering committee. Claude returns a clean one-page report with a clear amber status narrative, a structured progress section, and a single escalation framed as a question for the committee to answer.

**What good looks like:** A report that takes no more than five minutes to read, gives the steering committee a clear view of status, and makes the ask (if there is one) impossible to miss.

**Watch-out:** The report should reflect your professional assessment, not just Claude's interpretation of your notes. Always read it back and ask yourself whether the status and narrative match what you actually know about the programme.

---

*Next: Module 04, Business development playbook, covers proposals, credentials and client research.*
