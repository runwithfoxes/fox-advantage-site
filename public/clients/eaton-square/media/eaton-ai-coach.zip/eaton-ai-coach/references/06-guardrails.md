# Module 06: Staying safe and accurate

*The habits that let you use Claude confidently on real client work.*

---

## Client confidentiality and data

Claude is a powerful tool, but it is also an external service. Anything you type into claude.ai passes through Anthropic's systems. That means you need to apply the same judgment you would with any third-party platform before pasting in client material.

**Start by checking two things.** First, Eaton's own data and AI usage policy. Second, the client's own data rules, which may be stricter, particularly for regulated sectors such as financial services, healthcare, or public sector work.

Once you know what is permitted, the practical question is: how sensitive is what you are about to share?

**Generally safer to include:**

- Anonymised or lightly disguised material (replace the client's name with "the client" or a fictitious one)
- Information that is already public, such as published reports, annual accounts, or press releases
- Internal Eaton drafts and frameworks that do not contain personal data or client-specific figures
- Your own notes, frameworks, and thinking

**Worth pausing on:**

- Named individuals' personal data, including contact details, performance information, or anything that would fall under data protection rules
- Commercially sensitive figures: revenue projections, deal values, cost structures that are not in the public domain
- Material covered by a non-disclosure agreement, especially where the NDA explicitly restricts sharing with third parties
- Anything you would not be comfortable seeing in a discovery request

The simplest habit to build is anonymisation before you paste. It takes thirty seconds and removes most of the risk. If you are unsure whether something is safe to include, ask your manager or Eaton's compliance lead before proceeding. When in doubt, describe the situation in general terms rather than sharing the underlying document.

---

## Accuracy: the most important thing to understand

Claude can be confidently wrong. This is not a bug or an occasional glitch. It is a structural feature of how large language models work. Claude generates fluent, plausible-sounding text based on patterns in its training data. When it does not know something, it does not always say so. It sometimes produces a statistic, a name, a date, or a quote that sounds exactly right but is not.

This matters enormously in consulting work. A wrong figure in a board pack, a misquoted regulation in a business case, or a fabricated precedent in a proposal can damage your credibility and, in some circumstances, create real liability.

**The rule is simple: verify before it goes to a client or board.**

- Facts, statistics, and research findings: find the original source and check the number yourself. If you cannot find the source, do not use the statistic.
- Names, titles, and organisations: double-check against a live source such as LinkedIn or the organisation's own website.
- Dates and timelines: look them up. Claude's training has a cut-off date, and it may not know about recent events unless you turn on web search.
- Legal and financial specifics: always verify against the authoritative text, whether that is legislation, a contract, or a set of audited accounts.
- Quotes: never use a direct quote that Claude has produced unless you have found and read the original. Claude sometimes invents or misremembers quotes.

**On web search:** claude.ai has a web search feature you can enable for queries that need current information. This helps, but it does not remove the need to check. Web search results can be incomplete, or Claude may still misread or misrepresent what it finds. Treat web search output the same way you would treat a research assistant's first draft: useful starting point, needs verification.

---

## What Claude can and cannot see

Claude works from two things only: what it was trained on, and what you give it in the current conversation. It cannot see anything else.

That means:

- It cannot access your client's systems, internal databases, or live financial data unless you export and upload a file
- It does not know what happened after its training cut-off date unless you tell it, or enable web search
- It has no memory of previous conversations unless you paste in the relevant context yourself
- It cannot see attachments from your email, files on your desktop, or anything on your organisation's network

This is worth keeping in mind when you are working on something time-sensitive or data-heavy. If you need Claude to work from your client's actual numbers, you need to upload the file. If you need it to know about something that happened last month, you need to tell it or enable web search.

---

## The human stays in the loop

No client-facing or board-facing output should go out without a person reviewing and signing off on it. Claude is a drafting and thinking tool. The professional judgement, the accountability, and the relationship are yours.

A useful test before anything leaves your desk: "Would I stake my professional reputation on this exactly as it is?" If the answer is no, or if you have not checked the key facts yourself, it is not ready.

This is not about distrust of the tool. It is about good professional practice, the same standard you would apply to work from a junior colleague or an external researcher.

---

## Quick reference

| Claude is brilliant at | Be careful with / always check |
|------------------------|-------------------------------|
| Drafting, restructuring, and editing documents | Any statistic or research finding it produces |
| Generating options, frameworks, and structures | Names, titles, and organisational details |
| Summarising documents you have uploaded | Dates, timelines, and recent events |
| Stress-testing arguments and spotting gaps | Legal and financial specifics |
| Adapting tone and format to different audiences | Direct quotes attributed to real people |
| Turning rough notes into polished prose | Anything under NDA or containing personal data |
| Thinking through problems out loud | Output intended for a client or board without your own review |

---

Used with these habits in place, Claude is a genuinely powerful advantage: faster drafts, sharper thinking, and more time for the work that actually needs you.
