# Module 02: Projects, and working as a team

*How to stop re-explaining your client every time you open a chat, and how to use Claude consistently as a team.*

---

## Part A: Projects for the individual consultant

### What a Project is, and why it matters

Every time you start a new chat in Claude, you are starting from scratch. Claude knows nothing about your client, your programme, your preferred tone, or the fact that you have been working on this for six months. You have to re-explain it each time. For a busy consultant, that friction adds up fast.

A Project solves this. It is a persistent workspace you create once, for a specific client or programme, where you load in all the relevant background. Every chat you open inside that Project automatically inherits that context. Claude already knows who the client is, what the programme is trying to achieve, and how you like things written before you type a single word.

Think of it as the difference between briefing a new colleague every Monday and working with someone who has been sitting alongside you for months.

### Setting up a Project for a client

In Claude, look for the Projects section in the left-hand sidebar and create a new one. Give it a name that will make sense in three months: the client name and the programme is usually enough. For example: "Corrigan Foods - Finance Transformation" rather than just "Corrigan".

Once the Project is created, you have two things to configure:

**Custom instructions** tell Claude how to behave in every chat inside this Project. This is where you describe the client, the programme context, the audience, and any standing rules about tone, format, or what to avoid.

**Knowledge files** are documents you upload so Claude can reference them directly. Claude can hold roughly 500 pages of uploaded content across a Project.

### What to load as knowledge files

Be selective. Load the documents that define the work, not everything you have ever produced. Good candidates:

- The scope of work or statement of work (SoW), so Claude always knows what you are and are not being asked to do
- The current RAID log (risks, assumptions, issues, dependencies), so you can ask Claude to draft risk summaries or identify gaps without pasting it in every time
- The governance framework or programme structure, so Claude understands who the decision-makers are and how decisions get made
- A stakeholder map or list, with names, roles, and a note on how each person prefers to receive information
- A board pack or steering committee template, so Claude can draft straight into your house format
- Any client style or tone notes, including preferences the client has expressed directly

You do not need to upload every status report you have ever written. The goal is to give Claude a model of the engagement, not an archive.

### Writing good custom instructions

Custom instructions are the most powerful part of a Project, and it is worth spending twenty minutes getting them right. They run silently in the background of every chat. A good set of instructions means you rarely have to repeat yourself.

Here is a worked example for a transformation client:

```
You are supporting a team of management consultants at Eaton Square who are running a
finance and HR operating model transformation for Corrigan Foods, an Irish FMCG company
with around 1,800 employees.

PROGRAMME CONTEXT
The programme is called "One Corrigan". It is a 14-month transformation aiming to
consolidate four business units onto a single shared services model for finance, HR, and
procurement. We are currently in month five. The programme sponsor is the CFO, Orla
Dempsey. The steering committee meets monthly. There is significant change sensitivity
in the HR workstream because it involves restructuring two regional finance teams.

TYPICAL OUTPUTS
We produce: steering committee packs (concise, board-level), programme status reports
(RAG-rated, weekly), RAID log updates, change and communications plans, workshop
materials for senior leaders, and internal briefings for the client comms team.

TONE AND FORMAT
- Write in clear, direct, professional British/Irish English
- Avoid corporate jargon: say "we need to decide" not "a decision is required"
- Use plain language that a senior non-specialist could read without a glossary
- Board-level outputs should be tight and evidence-led, not padded
- Use bullet points for RAID logs, numbered steps for process documents
- Never use em dashes
- RAG statuses: Green = on track, Amber = at risk but recoverable, Red = requires
  immediate steering committee decision

WHAT TO AVOID
- Do not fabricate data, percentages, or timelines. If you do not have the numbers, say so
- Do not produce overly optimistic summaries. Flag risks clearly
- Do not use filler phrases like "it is important to note" or "in conclusion"
```

This takes about ten minutes to write and saves that time on every single chat. Adjust it as the programme evolves.

### Reusing a Project across the life of a programme

A Project is not a single-use thing. As the programme moves forward, update it. When the RAID log changes significantly, upload a fresh version. When you get new information about a stakeholder, add it to the knowledge files or the custom instructions. When the governance structure changes, reflect that.

The Project becomes a running record of your understanding of the engagement. By month ten, it will be doing a great deal of quiet work for you.

---

## Part B: Working as a team

### Shared Projects and what plan you need

This is the part many teams miss until they are well into a programme: Projects on a **Pro plan** are personal. Only you can see them. To share a Project directly with colleagues, you need a **Team or Enterprise plan**.

On a Team or Enterprise plan, sharing is straightforward. Open the Project, find the sharing option, and you can invite colleagues by name or make it visible to everyone in your organisation. There are two permission levels: "Can use" (colleagues can chat inside the Project but cannot change the instructions or knowledge files) and "Can edit" (full access). For most client teams, "Can use" for the wider team and "Can edit" for a lead or two is the right balance.

### The Pro plan workaround

If Eaton Square is on individual Pro plans and shared Projects are not yet available, there is a practical workaround that takes about five minutes to set up and works well.

Create a shared folder in Google Drive or SharePoint, called something like "Claude - Corrigan Foods". Inside it, put two things:

1. A document called "Claude custom instructions" containing the full text of your custom instructions, ready to paste
2. A subfolder of the knowledge files: the SoW, RAID log, stakeholder map, board pack template, and anything else relevant

When a new colleague joins the account team, you send them the link to that folder. They create their own Project in Claude, paste in the custom instructions, upload the knowledge files, and they are up to speed in under ten minutes. It is not as seamless as a true shared Project, but it means everyone is working from the same foundation rather than improvising their own setup.

The discipline this requires is keeping that shared folder current. Nominate one person to own it.

### Keeping everyone consistent

The biggest risk when a team uses AI tools separately is inconsistency. One consultant writes steering committee updates in one register, another in a different one. One person has loaded the current RAID log, another is working from a three-week-old version.

Three habits prevent this:

**Shared custom instructions.** Everyone on the team uses the same instructions. They live in the shared folder. If someone improves them, they update the shared version, and anyone can re-paste them into their own Project.

**Shared knowledge files.** One person (usually the programme manager or the lead consultant) is responsible for keeping the knowledge folder up to date. Everyone else points to it rather than maintaining their own version.

**A shared prompt library.** Over time, your team will develop prompts that reliably produce good results for your most common tasks: status reports, RAID log summaries, change impact assessments, stakeholder briefings. Write these down somewhere accessible. A simple document in the shared folder is enough. When someone new joins, they do not have to reinvent them.

### Onboarding a new joiner in minutes

One of the practical benefits of this setup becomes obvious when someone joins the team mid-programme.

Without a Project: the new joiner spends their first week reading documents, sitting in catch-up meetings, and asking questions that have already been answered. They start contributing slowly.

With a well-maintained Project: you send them the shared folder link, they spend fifteen minutes setting up their own copy of the Project, and their first chat with Claude already reflects six months of programme context. They can ask "catch me up on the open risks in the HR workstream" and get a grounded, accurate answer on day one.

This is not about replacing the human onboarding conversation. It is about clearing the administrative noise so that conversation can be about judgement and relationship rather than background facts.

### Chats stay private by default

One thing worth understanding clearly: even on a Team plan where a Project is shared, each person's individual chats stay private unless they actively share them. Your colleagues can see the Project setup and use it, but they cannot read your conversations.

This matters because people sometimes worry about colleagues seeing half-formed drafts or exploratory thinking. They do not need to. The shared layer is the instructions and knowledge. The conversations are yours.

### Naming conventions

When several people are using the same Project over a long engagement, naming discipline makes a real difference. Without it, the chat history becomes a pile of "New conversation" entries that nobody can navigate.

**For Projects**, use: Client name + programme name. Keep it consistent across the team. "Corrigan Foods - One Corrigan" is better than "Corrigan" (too vague) or "Corrigan TOM Transformation Programme Phase 2" (too long to scan).

**For individual chats**, name them at the start so you can find them later. Something like "Steering pack April" or "RAID update week 22" or "Change impact - HR workstream" is enough. Claude allows you to rename chats; it takes five seconds and saves you scrolling through history trying to find the draft you wrote two weeks ago.

---

## Worked example: setting up a Project end to end

**The situation.** Eaton Square has just been engaged by Meridian Healthcare, a private hospital group, to run a target operating model redesign for their corporate functions (finance, HR, legal, procurement). The programme is called "Meridian 2027". Sarah McDonough is the Eaton Square lead. There are three other consultants on the team. The client is on a Pro plan.

**Step 1: create the Project.** Sarah opens Claude and creates a new Project named "Meridian Healthcare - Meridian 2027".

**Step 2: write the custom instructions.** Sarah drafts instructions covering: what Meridian does and why they are running this programme, the key stakeholders (Group CFO, CHRO, and a cautious General Counsel who needs careful handling), the outputs the team typically produces, the tone Meridian expects (formal but not stuffy), and standing rules about what to avoid. She pastes these into the Project's custom instructions field.

**Step 3: upload the knowledge files.** She uploads the SoW, the initial stakeholder map, the governance framework they agreed with the client in week one, and the board pack template the client uses.

**Step 4: set up the shared folder.** She creates a "Claude - Meridian 2027" folder in the Eaton Square SharePoint. She drops in the custom instructions document and the knowledge files subfolder. She shares the link with the rest of the team and sends a short note explaining what is in it.

**Step 5: each team member sets up their own Project.** The three other consultants spend ten minutes each recreating the same Project setup. From that point forward, everyone is working from the same foundation.

**Step 6: maintain it.** At the end of each month, Sarah uploads a refreshed RAID log and, where needed, updates the custom instructions to reflect anything that has changed in the programme. She updates the shared folder at the same time so the rest of the team can stay current.

Three months in, a new analyst joins for the diagnostics phase. Sarah sends her the SharePoint link. The analyst is contributing meaningfully by the end of her first day.

---

*Next: Module 03 covers writing, editing, and getting the right tone for different client outputs.*
