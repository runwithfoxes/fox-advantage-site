# Business development playbook

Claude is genuinely useful across the full business development cycle, from first research to signed proposal. This module gives you six ready-to-use prompts, each matched to a specific moment in the Eaton Square BD process. The prompts are templates: copy them, fill in the bracketed parts, and adjust as you go. None of them replace your judgement, but all of them save time and sharpen your thinking.

One rule applies everywhere: never send an email, proposal or post that contains a fact, name or number you have not personally verified. Claude can be confidently wrong. Use it to draft, structure and think, then check anything that matters before it leaves your screen.

---

### 1. Research a prospect company before a meeting

**When to use:** Before any first meeting, pitch or check-in call where you need to arrive informed. Turn web search on (the toggle in the Claude interface) so Claude can pull current information rather than relying on training data.

**Prompt:**
```
I have a meeting with [Name], [Title] at [Company] on [Date]. The conversation is likely to be about [transformation / PMO / change programme / other].

With web search on, please research [Company] and give me:
1. What the business does and its scale (size, sector, geography).
2. Any recent news: restructuring, leadership changes, acquisitions, regulatory pressures, technology programmes.
3. The likely transformation or organisational pressures they are facing right now.
4. Who the key stakeholders in a transformation or change programme typically are at this type of organisation.
5. Three smart questions I could ask [Name] to open a useful conversation.

Flag any facts you are uncertain about so I can verify them before the meeting.
```

**Worked example:** Shane is meeting the transformation director at a mid-size Irish financial services firm. He turns on web search and runs this prompt. Claude surfaces a recent regulatory change affecting the sector, notes a new CIO who joined six months ago, and suggests questions about their current programme governance model. Shane checks the CIO hire on LinkedIn before the meeting.

**What good looks like:** You arrive with a clear picture of the company's current pressures and two or three questions that show you have done your homework. The prospect notices.

**Watch-out:** Always check company facts, names and figures against a real source (the company website, LinkedIn or a news article) before using them in conversation. Web search helps but does not guarantee accuracy.

---

### 2. Draft a proposal or scope of work from call notes

**When to use:** After a discovery call or briefing, when you need to turn rough notes into a structured proposal or scope document. Paste in your notes, even if they are messy.

**Prompt:**
```
I have just had a discovery call with [Company]. Here are my notes:

[Paste your call notes]

Please draft a proposal structure for a [programme delivery / change management / PMO / TOM design / other] engagement. Include:
1. Context: what the client is trying to achieve and why now.
2. Proposed approach: the key phases or workstreams, in plain language.
3. What Eaton Square would deliver (outputs and outcomes, not just activities).
4. Indicative timeline: [X weeks / X months].
5. What we need from the client to make this work.
6. A short section on why Eaton Square is the right choice for this.

Keep the language plain and direct. Avoid jargon. The reader is [Title at Company].
```

**Worked example:** Sarah takes fifteen minutes of call notes after a briefing from a retail group's HR director about a people-side transformation. She pastes them into Claude and asks for a change management proposal structure. Claude drafts five clear phases, identifies the comms workstream as a separate deliverable, and flags a dependency on the client's IT timeline. Sarah edits it and sends a polished first draft the same afternoon.

**What good looks like:** A clean, logical structure that reflects what the client actually said, not a generic consulting template. Specific enough that the client feels heard.

**Watch-out:** Claude will sometimes invent plausible-sounding scope items that were not in your notes. Read it carefully and cut anything you cannot trace back to the conversation.

---

### 3. Draft a LinkedIn thought-leadership post in someone's voice

**When to use:** When you need a quick draft for a post and the dedicated voice tools (which exist for Sarah and Sean) are not the right fit, or when someone else on the team needs help. Load two or three of the person's past posts as examples so Claude can match their style.

**Prompt:**
```
I want to write a LinkedIn post for [Name] at Eaton Square. Here are three examples of their previous posts:

[Paste post 1]
[Paste post 2]
[Paste post 3]

The topic for this post is: [Topic or angle, e.g. "why transformation programmes stall at the governance stage" or "what makes a change plan actually land with people"].

Please write a draft in [Name]'s voice. Match the tone, sentence length and structure of the examples. No hashtags. No bullet lists unless they already use them. Keep it under 250 words.
```

**Worked example:** Sinead needs a quick post for Ben on the topic of vendor selection mistakes. She pastes three of Ben's previous posts, notes that he writes in short paragraphs with a direct opener, and asks Claude to match that. The first draft is 80% there. She adjusts the opening line and it goes out that afternoon.

**What good looks like:** The post sounds like the person, not like AI copy. The opener earns attention. The point is specific, not generic.

**Watch-out:** The more example posts you provide, the better the voice match. One example is rarely enough.

---

### 4. Draft a follow-up or outreach email

**When to use:** After a meeting, event or LinkedIn interaction, when you want to follow up in a way that is specific and moves things forward. Also for cold outreach to a warm lead.

**Prompt:**
```
Please draft a short follow-up email from [Your Name] at Eaton Square to [Recipient Name], [Title] at [Company].

Context: [One or two sentences: how we know them, what we discussed, or why we are reaching out now].

The goal of this email is: [e.g. book a second call / share a relevant piece of work / introduce a capability they mentioned interest in].

Keep it under 150 words. No filler phrases like "I hope this finds you well." Make it specific to them, not generic. Plain, direct English.
```

**Worked example:** Shane met a programme director at a financial services event. He follows up the next morning with a note referencing their specific conversation about programme recovery work, includes one sentence connecting it to something Eaton Square has done, and proposes a thirty-minute call. No preamble, no buzzwords.

**What good looks like:** The recipient reads the first two lines and knows immediately why this email is for them and not a hundred other people.

**Watch-out:** Do not let Claude invent details about the company or the conversation. Fill in the context yourself and verify any facts before sending.

---

### 5. Prepare for a pitch

**When to use:** Before a formal pitch or competitive presentation, when you want to stress-test your angle, anticipate objections and prepare a strong opening.

**Prompt:**
```
I am preparing for a pitch to [Company]. The brief is: [One paragraph summary of what they want].

Our proposed approach is: [Brief description of what Eaton Square is proposing].

The key decision-maker in the room will be [Title], and other stakeholders include [Titles].

Please help me prepare by:
1. The three most likely tough questions or objections we will face, with suggested responses.
2. The sharpest angle we can take for this specific buyer (what matters most to a [Title] in this context).
3. A strong opening line or paragraph for the presentation, not generic.
4. One thing we might be underplaying that could differentiate us.
```

**Worked example:** Sarah is pitching a change management programme to a COO at a large utility. She runs this prompt, and Claude identifies that the COO will likely be most worried about business disruption during the transition. It suggests leading with how Eaton Square manages continuity during change, rather than methodology. She restructures the opening five minutes around that.

**What good looks like:** You walk in knowing the one or two things this particular buyer cares about most, and your pitch reflects that.

**Watch-out:** Claude does not know this buyer personally. Treat its assumptions as hypotheses to test, not facts about the individual.

---

### 6. Turn a case study into reusable sales assets

**When to use:** When a project closes and you want to extract maximum value from it for future BD. One case study can generate four or five distinct assets in under an hour.

**Prompt:**
```
Here is a summary of a completed Eaton Square engagement:

Client sector: [e.g. financial services, retail, public sector]
What we did: [Two to three sentences on the scope and approach]
The outcome: [What changed, what was delivered, what the client said]

Please create:
1. A one-page case study (problem / approach / outcome format, under 300 words, plain language).
2. A three-sentence email snippet I can drop into outreach to a similar prospect.
3. Four talking points for a sales conversation (what to say, not what to read out).
4. A short LinkedIn post based on the key lesson from this engagement (under 200 words, no hashtags).

Do not invent specifics. Only use what I have given you above.
```

**Worked example:** After closing a programme governance engagement with a public sector body, Ben pastes a brief summary into Claude. Within ten minutes he has a one-pager, two email snippets and a LinkedIn post. The one-pager goes into the proposal library. The email snippet goes into the next outreach batch for similar public sector prospects.

**What good looks like:** Four distinct assets, each usable in a different context, all consistent in story and tone.

**Watch-out:** Check that the outcome claims match what the client would actually be comfortable with you saying publicly. If in doubt, soften or anonymise before using.

---

## The golden rule

Never send, publish or present anything that contains a company fact, name, figure or claim you have not personally verified against a real source. This applies to proposals, emails, posts and pitch decks. Claude is a fast and capable drafter, but it will sometimes fill gaps with plausible-sounding detail that is simply wrong. The final check is always yours.
