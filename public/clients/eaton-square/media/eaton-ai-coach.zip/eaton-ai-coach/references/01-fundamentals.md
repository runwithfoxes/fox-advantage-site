# Module 01: Getting started with Claude

*For anyone who is new to AI tools and wants to get something genuinely useful done today.*

---

## What Claude is and how a chat works

Claude is an AI assistant made by Anthropic. You talk to it in plain English, in a chat window, exactly as you would message a colleague. You type something, Claude responds, and you keep going back and forth until you have what you need.

There is no special syntax to learn. No commands, no forms. Just conversation.

The one thing worth understanding early: Claude does not browse your files or your organisation's systems. It only knows what is in the current conversation, plus anything you paste in or upload as an attachment. That is it. So the quality of what you get out is directly tied to what you put in.

---

## Your first genuinely useful prompt

Most people start with something like:

```
Write a project status report.
```

Claude will produce something. It will probably be fine in structure. But it will be generic, because it has no idea what your project is, who the audience is, or what tone is right.

A much better starting point:

```
I am a management consultant writing a programme status update for a steering committee
at a large retail client. The programme is a finance system migration, currently at the
end of month three of six. We are on schedule but there is an open risk around data
quality in the legacy system. Write a one-page status summary with sections for overall
RAG status, key progress this period, risks and issues, and next steps. Tone should be
direct and factual, not corporate.
```

Same request. Completely different result.

---

## Five habits that separate a good result from a weak one

### 1. Give context

Claude needs to understand the situation before it can help properly. A sentence or two of background makes an enormous difference. What is the project? What has happened? What problem are you solving?

### 2. Say who you are and who the output is for

"I am a consultant" and "this is for a board" gives Claude important signals about register, assumed knowledge, and appropriate detail level. Without it, Claude has to guess.

### 3. Say what format you want

Do you want bullet points or prose? A table or a narrative? One page or a full deck outline? A draft email or a talking points list? Claude can produce most formats, but only if you ask.

### 4. Show an example if you can

If you have a previous report, a template you follow, or even a rough sketch of what you want, paste it in. "Follow this structure" or "match the tone of this" saves several rounds of iteration.

### 5. Iterate rather than expecting one perfect answer

Claude is not a vending machine. The first response is a starting point. Reply with what worked, what did not, and what you want adjusted. "Good structure, but the risks section is too vague, give me more specifics" is a completely normal and effective next step.

---

## Before and after: four Eaton examples

**Weak prompt:**
```
Write a change management plan.
```
**Stronger prompt:**
```
I am writing a change management plan for a target operating model redesign at a
professional services firm. About 200 staff will be affected. Key concerns are role
changes and a shift to shared services. Write a one-page plan covering stakeholder
groups, key messages, communication channels, and a phased timeline over six months.
```

---

**Weak prompt:**
```
Write a LinkedIn post about project management.
```
**Stronger prompt:**
```
Write a short LinkedIn post in Sean's voice, a senior consultant at a management
consultancy. The topic is why programme governance fails in the first 90 days.
Two to three short paragraphs. Conversational and direct, not corporate. No hashtags.
```

---

**Weak prompt:**
```
Help me with a proposal.
```
**Stronger prompt:**
```
I am putting together a proposal for a mid-size Irish company that needs a PMO set up
from scratch. They have had two failed transformation programmes. I need an executive
summary section, roughly 200 words, that acknowledges the problem, positions our
diagnostic-first approach as the right answer, and ends with a clear call to action.
```

---

**Weak prompt:**
```
Summarise this document.
```
**Stronger prompt:**
```
I have uploaded a programme assurance review. Please summarise it for me under three
headings: overall finding, the three biggest risks, and recommended immediate actions.
Write it so I can paste it into a one-page briefing note for a non-technical sponsor.
```

---

## One-off chats versus Projects

A regular chat is fine for one-off tasks. But if you are working on the same client or programme across many sessions, you will keep repeating background in every conversation, which is slow and error-prone.

That is what Projects are for. A Project lets you store documents (a programme brief, a stakeholder map, a client profile) and custom instructions (your preferred tone, the client's terminology) in one place. Every chat inside that Project automatically has access to all of it.

The Projects module covers this in full. If you are doing anything ongoing, go there next.

---

## Keeping a long conversation on track

Conversations can drift. If you have gone back and forth many times and the outputs are getting confused, the quickest fix is to summarise what you have agreed so far and paste it at the top of a new message:

```
To recap where we are: we have agreed the structure (three sections: context, options,
recommendation). The tone should be formal but not dry. The audience is a CFO who has
limited time. Now I need you to draft section two, the options analysis.
```

This resets the context without starting a new chat and losing the thread.

---

## The single most useful beginner trick

Before you ask Claude to do anything complex, ask it to ask you questions first.

```
I need to write a diagnostic deck for a client whose transformation programme has stalled.
Before you start, ask me the five questions that would help you write something genuinely
useful rather than generic.
```

Claude will ask you about the client, the symptoms, the stakeholders, what a good outcome looks like, and so on. Answering those questions takes two minutes. The resulting output is usually far closer to what you actually need, first time.

This works for almost anything: proposals, reports, change plans, stakeholder presentations. Use it whenever you are not sure how to brief Claude properly, or whenever the stakes are high enough that you want to get it right quickly.

---

## A closing thought

The gap between "Claude gave me something useless" and "Claude saved me an hour" is almost always the quality of the prompt. Not a technical skill. Just the habit of giving a bit more context, being specific about what you want, and treating the first answer as a starting point.

You already know how to have a clear, useful conversation with a colleague. This is the same thing. The more you treat Claude like a smart person who needs a proper brief rather than a machine that reads your mind, the better it gets.

Start with one real task. See what comes back. Go from there.
