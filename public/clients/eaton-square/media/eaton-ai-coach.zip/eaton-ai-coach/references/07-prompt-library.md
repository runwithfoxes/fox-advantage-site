# The prompt library: copy, fill in, send

Copy any prompt below, replace everything in [square brackets] with your own details, attach any files mentioned, and send. Nothing else required.

---

## Group 1: Getting started

**Ask me questions first**
Use this when: you want Claude to gather the right information before it starts writing, so you don't have to edit a half-right first draft.

```
Before you write anything, ask me the questions you need to do this well.
I want to [describe what you want - e.g. write a stakeholder engagement plan / draft a proposal / design a workshop].
Ask me up to 8 questions, one at a time if you prefer, then wait for my answers before producing anything.
```

---

**Improve my prompt**
Use this when: you have a rough idea of what you want but your prompt feels vague or incomplete.

```
I want to ask you to help me with [describe the task in one sentence].
Here is my current prompt: "[paste your draft prompt here]"
Rewrite it so it will get a better result. Explain what you changed and why.
```

---

**Explain this simply**
Use this when: you need to understand a complex document, methodology, or framework quickly.

```
Explain the following to me as if I am an intelligent professional who is not a specialist in this field.
Use plain English, short paragraphs, and no jargon unless you define it.
[Paste the text, or attach the document]
```

---

**Turn a long email chain into a clear picture**
Use this when: you have inherited a messy thread and need to get up to speed fast.

```
I am going to paste an email chain below. Please read the whole thread and give me:
1. A two-sentence summary of what this is about
2. The key decisions made so far
3. Any outstanding questions or actions still open
4. Who the main people are and what their position appears to be

[Paste the email chain]
```

---

## Group 2: Delivery

**Write a board-pack section from rough notes**
Use this when: you have notes, bullet points, or a draft and need a polished board-ready section.

```
Write a [section name - e.g. Programme Status / Executive Summary / Risk Update] for a board pack.
Context: [one paragraph describing the programme, client, and stage]
Audience: [e.g. executive sponsors, non-executive board members]
Tone: formal, concise, no filler.
Use these notes as the source:
[Paste your notes or attach the document]
Format: short narrative paragraphs followed by a RAG-rated summary table where relevant.
```

---

**Summarise a long document and pull the risks**
Use this when: you need to extract the key points and risks from a lengthy report, strategy, or policy document.

```
Please read the attached document and produce:
1. An executive summary (maximum 200 words)
2. A bulleted list of the 5 to 8 most important points
3. A separate list of risks, issues, or concerns, each with a one-line explanation of why it matters

[Attach the document]
```

---

**Build a RAID log**
Use this when: you need to set up or populate a RAID log from project notes, a kick-off meeting transcript, or a document.

```
Using the information below, build a RAID log in table format with these columns:
ID | Category (Risk / Assumption / Issue / Dependency) | Description | Owner | Likelihood (H/M/L) | Impact (H/M/L) | Status | Mitigation or Action

Source material:
[Paste your notes or attach the document]

Programme name: [name]
Client: [client]
Stage: [e.g. mobilisation / delivery / close]

Flag any obvious gaps where you would expect an entry but have no information.
```

---

**Draft a business case**
Use this when: you are building a business case from scratch or need to structure a first draft quickly.

```
Draft a business case for the following initiative.
Use a standard structure: Executive Summary, Strategic Context, Options Considered, Recommended Option, Benefits, Costs and Resources, Risks, and Recommended Next Steps.

Details:
Initiative: [name and one-sentence description]
Organisation: [client name and brief context]
Problem being solved: [describe it]
Proposed solution: [describe it]
Known benefits: [list them]
Known costs or constraints: [list them]
Key risks: [list them]
Decision needed by: [date or milestone]

Keep the tone professional and concise. Flag where you need more information.
```

---

**Draft a change and communications plan**
Use this when: you need to structure how a programme will land with its affected stakeholders.

```
Draft a change and communications plan for the following programme.

Programme: [name]
Organisation: [client]
What is changing: [describe the change in plain terms]
Who is affected: [list the main groups]
Timeline: [key milestones and dates]
Key concerns or resistance expected: [describe if known]

Please produce:
1. A change impact summary by stakeholder group
2. A communications timeline showing what message goes to whom and when
3. A set of key messages for [e.g. senior leaders / front-line staff / external partners]
4. A list of change risks to manage

Flag any gaps in information that would affect quality.
```

---

**Create a stakeholder map**
Use this when: you need to identify and prioritise stakeholders at the start of a programme or for a specific decision.

```
Create a stakeholder map for the following situation.

Programme or decision: [describe it]
Organisation: [client name and brief context]
Stakeholders I know about: [list names, roles, or groups]

Please produce:
1. A table listing each stakeholder with: Name/Group | Role | Interest in this programme | Likely attitude (supportive / neutral / resistant) | Influence level (H/M/L) | Recommended engagement approach
2. A short narrative noting any relationship dynamics or political sensitivities I should be aware of
3. Any stakeholder groups I may have missed based on the context

[Attach any org chart or background document if available]
```

---

**Design a workshop**
Use this when: you need to plan a working session from scratch or want a better structure for an existing agenda.

```
Design a workshop for the following purpose.

Purpose: [e.g. define the target operating model / prioritise the programme roadmap / resolve a key decision]
Audience: [who will attend and their seniority]
Duration: [e.g. half day / full day / 90 minutes]
Number of participants: [approximate]
What a good outcome looks like: [describe it]
Any constraints: [e.g. remote / hybrid / politically sensitive topic]

Please produce:
1. A timed agenda
2. For each session: objective, suggested activity or exercise, facilitator notes
3. A list of materials or pre-reads to prepare in advance
4. Two or three facilitation risks and how to manage them
```

---

**Write a programme status report**
Use this when: you need a consistent, well-structured status report for a programme board or steering committee.

```
Write a programme status report for the following programme.

Programme: [name]
Reporting period: [dates]
Overall RAG status: [Red / Amber / Green]
Audience: [e.g. programme board / steering committee]

Source information:
[Paste your notes, or attach last week's report plus any updates]

Please produce a report with these sections:
- Overall status and headline summary (3 to 4 sentences)
- Progress this period (key achievements)
- Planned next period (key activities)
- RAID update (notable risks, issues, decisions needed)
- Finance summary if relevant
- Any escalations required

Tone: factual, direct, no padding.
```

---

## Group 3: Business development

**Research a prospect before a meeting**
Use this when: you want a fast briefing on a company or individual before a first meeting or call. Requires web search to be turned on.

```
[Turn on web search before sending this prompt]

Research [company name] for me. I have a meeting with [contact name and title] on [date].
Please give me:
1. What the company does and its market position
2. Recent news, announcements, or challenges (last 6 to 12 months)
3. Any signals that suggest they might have programme delivery, transformation, or change management challenges
4. Two or three intelligent questions I could ask that would position us as a knowledgeable partner
5. Any competitors or peers they are likely benchmarking against
```

---

**Draft a proposal from notes**
Use this when: you have a brief, meeting notes, or a scope document and need a first draft proposal quickly.

```
Draft a consulting proposal based on the following information.

Client: [name]
Context: [brief description of their situation and the problem they need help with]
What we are proposing: [describe the engagement - approach, phases, outputs]
Our differentiators: [why Eaton Square is the right choice]
Indicative timeline: [e.g. 10 weeks across 3 phases]
Fee basis: [if you want to include it]

Please structure the proposal as: Executive Summary, Understanding of the Challenge, Our Approach, Deliverables and Timeline, Why Eaton Square, Investment, and Next Steps.

Tone: confident, peer-to-peer, no management consulting clichés.

[Attach any notes, brief, or background documents]
```

---

**Draft a specific follow-up email**
Use this when: you want to follow up after a meeting in a way that moves the conversation forward, not just thanks them for their time.

```
Write a follow-up email after a business development meeting.

Meeting was with: [name, title, company]
Date: [date]
What we discussed: [2 to 3 bullet points on the key topics]
What I want to happen next: [e.g. a second meeting / send a proposal / make an introduction]
Any specific commitments made in the meeting: [list them if any]
My tone: [e.g. warm and direct / formal / relaxed]

Keep it to 150 words or fewer. No filler phrases like "it was great to meet you". Get to the point in the first sentence.
```

---

**Pitch prep: questions and objections**
Use this when: you are preparing for a competitive pitch or a high-stakes client meeting and want to rehearse.

```
Help me prepare for a pitch or client meeting.

Client: [name]
What we are pitching: [brief description of the engagement]
What we know about their priorities: [describe]
Who will be in the room: [names and roles if known]

Please give me:
1. The 6 most likely tough questions they will ask us
2. A strong, honest answer to each question
3. The 3 most likely objections (e.g. on price, approach, or our experience)
4. How to handle each objection without being defensive
5. Two or three questions we should ask them to demonstrate strategic understanding
```

---

**Turn a case study into a one-pager**
Use this when: you want to convert an existing case study, project summary, or set of notes into a clean, shareable one-pager for BD use.

```
Turn the following material into a concise case study one-pager for business development.

Format:
- Client sector (not name unless permitted): [sector]
- Challenge (2 to 3 sentences): what the client was facing
- What we did (3 to 5 bullets): our approach and key activities
- Outcomes (2 to 3 bullets): measurable or observable results
- Why it matters (1 sentence): the broader point it makes about our capability

Source material:
[Paste your notes or attach the document]

Tone: factual and confident. No superlatives. Let the work speak for itself.
```

---

## Group 4: Productivity and team

**Red-team this document**
Use this when: you want a critical review of a document before it goes to a client or senior stakeholder.

```
Act as a rigorous, experienced reviewer. Read the following document and give me an honest critique.

I want to know:
1. Where the logic or argument is weak or unconvincing
2. Any claims that are not backed up with evidence
3. Sections that are unclear, padded, or could be cut without losing anything
4. How a sceptical senior stakeholder would react to this
5. The three most important changes I should make before sending it

Be direct. I would rather hear problems now than after it has gone.

[Paste the document or attach it]
```

---

**Weekly status workflow**
Use this when: you want a repeatable prompt you can use every week to produce a consistent programme status update.

```
I am producing the weekly status update for [programme name].

Here are my notes from this week:
[Paste bullet points, Slack messages, meeting notes, or whatever you have]

Last week's report is attached for reference.
[Attach last week's report]

Please:
1. Write this week's status report in the same format as last week's
2. Update the RAG status to [Red / Amber / Green] with a one-line justification
3. Highlight anything that is new, escalated, or resolved since last week
4. Flag any sections where my notes are thin and I should add more detail before sending
```

---

**Set up custom instructions for a new client Project**
Use this when: you are starting a new client Project in Claude and want to give it the right context so every conversation is grounded in the client's situation.

```
I am setting up a Claude Project for a new client engagement. Help me write the custom instructions for this Project.

Client: [name]
Industry: [sector]
What they have hired us for: [brief description of the engagement]
Key people on their side: [names and roles]
Key people on our side: [names and roles]
Important context Claude should always know: [e.g. political sensitivities, key decisions in flight, terminology they use]
Outputs we will regularly produce: [e.g. board packs, RAID logs, status reports]
Tone we should use in all documents: [e.g. formal / direct / consultative]

Write the instructions in the second person, as if speaking to Claude. Keep them to 200 to 300 words.
```

---

**Summarise a meeting recording transcript into actions**
Use this when: you have a transcript from a recorded meeting and need a clean summary with clear actions.

```
I am going to paste a meeting transcript below. Please read it and produce:

1. A one-paragraph summary of what the meeting was about and what was decided
2. A list of actions in table format: Action | Owner | Due date | Any notes
3. A list of any open questions or topics that were flagged but not resolved
4. Any risks or concerns mentioned in the meeting that should go into the RAID log

Meeting context: [e.g. programme board / steering committee / kick-off / weekly team call]
Programme: [name]
Date: [date]

[Paste the transcript below, or attach it]
```
