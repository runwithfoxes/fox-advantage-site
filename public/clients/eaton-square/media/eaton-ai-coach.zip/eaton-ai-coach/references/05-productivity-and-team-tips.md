# 05 - Productivity, Efficiency, and Team Habits

This module is about working faster, wasting less effort, and building habits across the Eaton Square team so that the knowledge you build up in Claude does not stay locked in one person's chat history.

---

## Part A - Personal Speed and Efficiency

### Use Artifacts to draft and refine in place

When you ask Claude to write a document, a table, or a set of slides, it can place the output in an **Artifact**, a panel that opens on the right-hand side of the screen. The Artifact is live and editable. You can ask Claude to revise sections, reorder rows, or reformat headings and the changes land directly in that panel, so you never have to copy text back and forth. When it is ready, you download it.

Try this for a board pack status summary or a RAID log. Ask Claude to "put this in an Artifact as a formatted table" and then iterate from there.

### Turn web search on only when you need it

Claude has a web search toggle. Turn it on when you genuinely need current information: a competitor's recent news, a technology vendor's current pricing, or the latest government guidance. Turn it off for everything else. When web search is off, Claude focuses entirely on what you have given it rather than pulling in potentially irrelevant results, and responses tend to be tighter.

### Use extended thinking for hard problems

Extended thinking (available from the model selector) makes Claude reason through a problem step by step before answering. It takes longer but produces noticeably better results on genuinely complex work: a business case where the assumptions are uncertain, a programme that has gone off track and needs untangling, or a stakeholder situation with competing interests. Do not use it for simple tasks. It is the equivalent of asking a colleague to take a proper hour with something rather than giving you an off-the-cuff answer.

### Dictate on the mobile app between meetings

The Claude mobile app supports voice dictation. If you have just come out of a client meeting and you want to capture the key points before you forget them, open the app and dictate. You might say:

```
I just came out of the Eaton Square programme board for [client]. Key decisions were [X]. Risks that came up: [Y]. Actions for me: [Z]. Can you turn this into a clean set of meeting notes with a separate actions table?
```

This is one of the quickest ways to convert your own thinking into something usable.

### Know when to start a fresh chat

One long chat where you have moved from topic to topic is harder for Claude to navigate, because it is holding all that earlier context. Start a new chat when you move to a genuinely new task. Continue the same chat when the context from earlier in the conversation still matters, for example when you are drafting multiple sections of the same document or refining the same deliverable.

### Attach the source file rather than pasting

If you are working from a client document, an existing status report, a business case, or a slide deck, attach the file directly using the paperclip or plus button rather than copying and pasting the text into the prompt. Claude reads the file, you keep your prompt short, and there is no risk of formatting breaking during the paste.

### Iterate efficiently: ask for changes to the last output

You do not need to re-explain the whole task every time you want a tweak. Once Claude has produced something, just say what you want to change:

```
Make the executive summary shorter, two sentences maximum.
```
```
Add a risks column to that table.
```
```
Rewrite the recommendation section in a more confident tone.
```

This is much faster than starting again and is how experienced users work.

### Red-team your own output

Before you send a board pack or a business case to a client, ask Claude to critique what it just produced:

```
Play devil's advocate. What are the three weakest points in that business case and how would a sceptical finance director push back?
```

This is a reliable way to raise the quality of your work in under two minutes. You will regularly find gaps you would have missed.

### Compare two approaches in one prompt

If you are unsure which direction to take, ask Claude to give you both and compare them:

```
Write two versions of the opening paragraph for this proposal. Version 1 leads with the problem. Version 2 leads with the outcome. Then tell me which you would recommend and why.
```

### Prep before meetings, write up after

Before a workshop or a difficult stakeholder conversation, brief Claude on who will be in the room and what you are trying to achieve and ask it to help you anticipate objections or prepare your agenda. After the meeting, paste your rough notes and ask it to produce clean minutes with a separate actions table.

```
I have a meeting tomorrow with the CFO and programme sponsor at [client] to review the Q2 business case. The CFO has been resistant to the investment ask. What questions should I be ready for and what data would strengthen our position?
```

---

## Part B - Saving and Reusing Your Best Work

### Build a personal prompt library

Every time you find a prompt that works particularly well, save it. Keep a simple document, a Notes file, a Word doc, a Google Doc, whatever you will actually maintain, with your best prompts organised by task type. A RAID log prompt. A stakeholder map prompt. A programme health summary prompt.

The Eaton Square prompt library file (see `06-prompt-library.md`) gives you a starting set you can copy from directly. But add to it as you go. The prompts that work best are usually the ones you have tuned for your specific clients and output formats.

### Build a repeatable workflow for recurring tasks

For anything you do every week or every fortnight, write down the sequence of prompts once and reuse it. For example, a weekly programme status report might follow this pattern every time:

1. Attach last week's status report so Claude has the baseline.
2. Paste or dictate this week's key updates.
3. Ask Claude to produce the new status report using the same format, updating the RAG ratings and rolling the actions forward.
4. Ask it to flag anything that has changed status since last week.

Write that four-step sequence down. Share it with the rest of the team. It is now a team asset.

---

## Part C - Team Habits

This is where the real efficiency gains are. Individual productivity tips help one person. Team habits compound across the whole consultancy.

### Use a Project so the team shares context

A **Project** in Claude is a workspace that holds a system prompt, uploaded files, and a full chat history that everyone on the team can see and add to. On a Team or Enterprise plan, Projects are shared. This means the whole team working on a client can start from the same foundation rather than each person rebuilding context from scratch.

Set up one Project per client. Load it with the client brief, the agreed deliverable formats, and any background documents. When someone on the team starts a new chat in that Project, Claude already knows the client, the programme, the stakeholder names, and the house style. This is probably the single highest-value thing you can do as a team.

### Agree house style once and load it into every Project

Decide what good looks like for Eaton Square outputs: your preferred tone, heading structure, how you handle RAG ratings, how long executive summaries should be. Write that down as a short style guide. Load it into the system prompt of every client Project. From that point on, every output Claude produces for that client is already aligned to your standards without anyone having to repeat the instructions.

### Build a shared team prompt library

The prompts that work well should belong to the team, not to the individual who discovered them. Keep a shared prompt library, a document everyone can read and contribute to. When someone finds a better way to prompt for a business case or a stakeholder map, they add it to the library with a brief note on when to use it.

This pays off quickly. Instead of each person spending time figuring out how to phrase a prompt, they pull from a proven set and start from a higher baseline.

### Agree clear ownership of each client Project

Every client Project should have a named owner, typically the most senior person on that account. The owner's job is to keep the Project's knowledge files current: updated client documents, revised stakeholder lists, changes to scope. If the files are stale, the context is stale and the outputs suffer. One owner, clear responsibility.

### Use consistent naming conventions

Anyone on the team should be able to find the right Project and the right chat without having to ask. Agree a naming convention for Projects (for example, "Eaton - [Client Name] - [Year]") and a convention for chats within a Project (for example, "Q2 board pack draft" or "Onboarding workshop prep June"). Simple, consistent naming means the knowledge you build up is findable by your colleagues, not just by you.

### Run a light weekly share

At the end of each week, or in whatever team stand-up or update rhythm you already have, spend five minutes on "what worked in Claude this week." One person shares a prompt or a workflow that saved them time. This does not have to be formal. It can be a Slack message or a single agenda item in a weekly call. Over months, this compounds into a team that is measurably faster than one where good habits stay with individuals.

### Consistency means any consultant can pick up any client

The whole point of the Project setup is that no single person should be a bottleneck. If Sarah is the only person who knows the context for a particular client programme, the team is fragile. If the client Project holds that context, loaded, structured, and current, then any consultant can step in, open the Project, and produce a solid output on the first attempt. This is what good team infrastructure looks like.

---

## Five Habits of the Fastest Users

1. They work in Artifacts and iterate in place rather than copy-pasting.
2. They attach files rather than pasting long text.
3. They ask Claude to critique its own output before they send anything important.
4. They save every good prompt to a shared library rather than rediscovering it each time.
5. They load client context into a Project so the whole team starts from the same baseline.
