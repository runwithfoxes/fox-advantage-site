---
name: eaton-heyreach-load
description: "Load the finished upload file into HeyReach and start the campaign, with the SmartLead email upload gated in between. Use when Ben says 'load my list into HeyReach', 'load the HeyReach file', 'start my campaign', or has the upload files from eaton-merge ready. It uploads the LinkedIn leads to HeyReach through the connector, holds before sending, walks Ben through the manual SmartLead upload, then starts only when both are in place. NOT for building the file (that is eaton-merge)."
---

# Eaton HeyReach Load

This skill loads your finished list into **HeyReach** and starts the campaign. It is the only skill that makes things go live, so the careful part is the **hold before sending**: it never starts on its own, and it will not start the campaign until the **SmartLead emails are loaded too**.

You run it in Claude, in the browser. It uses the **HeyReach connector** (which can add leads and start campaigns). SmartLead is uploaded by hand, because SmartLead does not yet work from the browser - the skill walks you through that and waits for you.

## What it needs

The two files from `eaton-merge`:
- the **HeyReach file** (LinkedIn content: connection note + the two LinkedIn messages),
- the **SmartLead file** (email content: the three emails).

If they are not in this chat, ask Ben to paste or upload them first.

## Step A - check the HeyReach file before loading

1. Confirm the target HeyReach campaign by name (the ICP Outreach campaign, already built). If you can't see it, stop and say so - don't load into the wrong campaign.
2. Check every lead has the columns the campaign's custom variables need (`connection_request` / `li_insight` / `li_engagement`, plus name, company, LinkedIn URL, email). **A blank message cell would send a blank message** - hold those rows back and list them, don't load them.

## Step B - load the leads into HeyReach (through the connector)

Add the leads to the campaign using the HeyReach connector, mapping each column to the matching custom variable. Work in chunks and show progress. Report: how many loaded, how many held and why.

## Step C - HOLD. Do not start yet.

Say this plainly to Ben, every time:

> The leads are in HeyReach but **nothing is sending**. Before I start the campaign you must put the emails into SmartLead, or the email steps will fire into an empty campaign.
>
> **Upload the SmartLead file now (Step 8 of your guide): open SmartLead, go to your ICP email campaign, add leads, upload the SmartLead file, and check the leads appear.** When that's done, tell me "SmartLead is loaded" and I'll start the campaign.

Then **wait**. Do not start. Do not assume it's done.

## Step D - start, only after Ben confirms

When Ben says SmartLead is loaded:
1. Ask one last plain check: "Confirmed: the emails are in your SmartLead campaign, and you want me to start sending now?"
2. On a clear yes, start the HeyReach campaign through the connector.
3. Confirm it is running, and remind Ben the sequence sends on weekdays only, so quiet days are normal.

## Hard rules (do not bend these)

- **Never start the campaign without (a) Ben's explicit go and (b) his confirmation that SmartLead is loaded.** This is the whole point of the skill.
- A blank message variable means a blank send. Hold those rows, never load them.
- Load into the named campaign only. If you can't confirm the campaign, stop.
- HeyReach through the connector; SmartLead by hand. Do not pretend you uploaded SmartLead - you can't, and saying you did would be a lie that breaks the campaign.
- No scripts, no other tools. HeyReach connector only.

## If something goes wrong

- **HeyReach connector silent / erroring** → start a fresh chat and try again; if it still fails, stop and tell Paul, don't half-load.
- **The campaign isn't in the connector's list** → stop. The campaign shell may not be built yet; flag to Paul.
- **Ben says "just start it" before SmartLead is loaded** → do not. Explain once more why, and wait. The emails would fail silently otherwise.
