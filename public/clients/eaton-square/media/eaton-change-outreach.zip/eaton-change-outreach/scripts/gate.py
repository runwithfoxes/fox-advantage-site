#!/usr/bin/env python3
"""Deterministic gate for Eaton change-outreach notes.
Reads one JSON object on stdin:
  {"message": "<full note>", "beat1": "<beat 1 only>", "dm_title": "<DM title>",
   "evidence": ["Name | Title | 2025-09", ...], "today": "2026-06"}
Hard-fails the mechanical rules; raises CHECK warnings for the judgment-adjacent ones.
A note is sendable only when there are zero FAILs and every CHECK has been resolved by a human.
"""
import sys, json, re

FIXED_B2 = "We've found the real work starts once the programme lands, making the change hold."
FIXED_B3 = "If that's useful, one of our programme directors would be glad to talk it through."
DASHES = [" - ", " - ", " - "]              # em dash, en dash, spaced hyphen
BANNED = ["most", "quiet", "quietly", "compare notes", "swap notes"]
HEDGES = ["looks like", "seems", "appears", "from the outside"]

def months_between(today, dt):
    ty, tm = map(int, today.split("-")[:2]); dy, dm = map(int, dt.split("-")[:2])
    return (ty - dy) * 12 + (tm - dm)

def check(d):
    msg = d["message"]
    b1 = d.get("beat1") or (msg.split(FIXED_B2)[0].strip() if FIXED_B2 in msg else msg)
    dm_title = d.get("dm_title", "")
    ev = d.get("evidence", [])
    today = d.get("today", "2026-06")
    fails, warns = [], []

    if len(msg) > 300: fails.append(f"length {len(msg)} > 300")
    for ch in DASHES:
        if ch in msg: fails.append(f"dash {ch!r}")
    low = " " + b1.lower() + " "
    for b in BANNED:
        if " " + b + " " in low or low.strip().endswith(" " + b): fails.append(f"banned word/phrase {b!r}")
    if "!" in msg: fails.append("exclamation mark")
    if not any(h in b1.lower() for h in HEDGES): fails.append("no hedge opener (use 'looks like')")
    if FIXED_B2 not in msg: fails.append("Beat 2 not present verbatim")
    if FIXED_B3 not in msg: fails.append("Beat 3 not present verbatim")
    if "programme director" not in msg.lower(): fails.append("named-role close missing")

    # CHECK: possible DM self-credit (DM title words appearing in Beat 1)
    # ignore generic rank words; only the DISTINCTIVE title words signal self-credit
    stop = {"of", "the", "and", "for", "to", "in", "at", "a", "&", "uk", "director",
            "head", "officer", "chief", "manager", "lead", "group", "senior", "deputy",
            "interim", "global", "national", "executive", "vice", "president", "business"}
    dmtok = [t for t in re.split(r"[^a-z]+", dm_title.lower()) if len(t) > 2 and t not in stop]
    hit = sorted({t for t in dmtok if t in b1.lower()})
    if hit:
        warns.append(f"possible DM self-credit: Beat 1 contains DM-title words {hit} - confirm you cited a DIFFERENT person, not the recipient's own role")
    # CHECK: cited evidence dates older than 24 months
    dates = re.findall(r"20\d\d-\d\d", " ".join(ev))
    old = [dt for dt in dates if months_between(today, dt) > 24]
    if old:
        warns.append(f"evidence dates older than 24 months {old} - do not imply recency for these")
    if not ev:
        warns.append("no evidence lines supplied - cannot confirm Beat 1 claims trace to Clay data")
    return fails, warns

if __name__ == "__main__":
    d = json.load(sys.stdin)
    fails, warns = check(d)
    print("GATE:", "FAIL" if fails else "PASS")
    for f in fails: print("  FAIL :", f)
    for w in warns: print("  CHECK:", w)
    print(f"  chars: {len(d['message'])}")
    sys.exit(1 if fails else 0)
