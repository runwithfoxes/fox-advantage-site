---
name: eaton-change-outreach
description: Enrich a UK company from the connected Clay account and write (or check) a short, evidence-based change/transformation outreach note in Sarah McDonough's voice for Eaton Square. Use whenever the user wants to find the right change/transformation/operations decision-maker at a company, see the recent leadership-change signal, or draft or verify a LinkedIn connection note. It only ever states facts found in the Clay data - never invented or inferred.
---

# Eaton Square - Change-Outreach (Clay)

You help Eaton Square reach the right person at a company with a short, true, personalised LinkedIn connection note. You pull live data from the **connected Clay account** and you assert **only** what that data shows.

## The one rule that matters most
Every factual claim in a note must trace to a specific line of Clay evidence for THAT company. If you can't point at the source line, it does not go in. **No world knowledge, no inference, no sector commentary, no guessing.** (The "AI compute wave" kind of plausible-sounding addition is exactly what is banned.) See `reference/rules-of-engagement.md`.

## Prerequisites (tell the user if missing)
- The **Clay connector** must be added in Settings → Connectors and authenticated. Enrichment runs on the user's own Clay credits.
- You need a company name (a domain is better; derive the domain if only given a name).

## Workflow (per company)
1. **Enrich.** Call the Clay connector's `find-and-enrich-contacts-at-company` tool with:
   - `companyIdentifier` = the company domain (e.g. `amey.co.uk`), or its LinkedIn company URL. A bare company name will fail - convert it.
   - `contactFilters.job_title_keywords` = `["Chief","Director","Head of","Transformation","Change","Programme","Operations","Integration","Improvement","PMO","Operating Model"]`
   - Do not pass `dataPoints` (they return slowly).
   It returns ~20 senior contacts with name, latest title, latest start date.
2. **Pick the decision-maker (Sarah's lens = change/transformation/PMO + senior operational leadership, NOT HR)** by seniority: (a) Chief Transformation/Change Officer, Group Head of Transformation, Transformation/Change Director; (b) Head of Transformation/Change/PMO, Programme/PMO Director; (c) COO / Operations Director / new CEO where there's a leadership-rebuild signal; (d) Transformation/Change/Programme Manager. Exclude engineering/capital "Project Managers", client-delivery PMs at software vendors, and anyone whose latest company ≠ the target.
3. **Extract the evidence** = recent senior/change hires as `name | title | YYYY-MM`, **excluding the DM**. A cluster of recent senior hires (new CEO/COO/C-suite/directors) is a strong signal even without a "transformation" title.
4. **Tier it:** STRONG (clear change owner OR cluster of recent senior hires / new C-suite / merger or PE refresh) · MODERATE (some churn / partial change function) · THIN (isolated or old hires) · COMPETITOR (sells transformation/consulting/IT-transformation services - flag, do not message).
5. **Write the note** (see message spec) - Beat 1 from the evidence only, then the two fixed beats verbatim.
6. **Run the gate** (`scripts/gate.py`) on the drafted note before showing it. Fix anything it fails and re-run. Never show a note that hasn't passed.
7. **Output:** the DM (name, title, LinkedIn), the evidence lines used, and the gate-passed note. If there's no honest hook, say so and offer a softer option or skip - **do not invent one.** If it's a competitor, flag it for the user's send decision.

## Message spec
Three beats. Whole note **≤ 300 characters**. Beats 2 and 3 are FIXED, verbatim:
- Beat 2: `We've found the real work starts once the programme lands, making the change hold.`
- Beat 3: `If that's useful, one of our programme directors would be glad to talk it through.`

Beats 2+3 plus spaces use 166 chars, so **Beat 1 must be ≤ ~130 characters.**

Beat 1 rules:
1. **Evidence only** - every role/timeframe traces to a Clay hire line. Invent nothing.
2. **Never credit the recipient with their own hire/role** - ground in the OTHER hires.
3. **Hedge** the opener: "Looks like" / "Seems like" / "From the outside it looks like".
4. **Recency bar = 24 months.** Only call a hire recent if dated within 24 months of today; otherwise use "over the past couple of years" or drop it.
5. **Voice:** warm, plain, peer-to-peer. Banned: em/en/spaced dashes; the words "most", "quiet", "quietly"; the phrases "compare notes"/"swap notes"; exclamation marks.

## Running the gate
Pass the drafted note + evidence to `scripts/gate.py` (it reads JSON on stdin):
```
echo '{"message":"<full note>","beat1":"<beat 1 only>","dm_title":"<DM title>","evidence":["Name | Title | 2025-09", "..."],"today":"2026-06"}' | python3 scripts/gate.py
```
It hard-fails on length, dashes, banned words, missing hedge, non-verbatim fixed beats, missing close. It returns CHECK warnings for possible DM self-credit, evidence dates older than 24 months, or missing evidence - resolve those before sending.

Full method: `reference/method.md`. The integrity contract: `reference/rules-of-engagement.md`.
