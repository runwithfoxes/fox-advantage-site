# Rules of engagement - what a note may and may not say

A wrong specific is worse than a generic line: it doesn't just fail to personalise, it signals carelessness to the prospect. So the bar is absolute.

## The principle
Every factual assertion in a note must trace to a specific line of Clay evidence for THAT company. If you cannot point at the source, it does not go in.

## Allowed sources (only these)
1. **Hire data from Clay** - a person's name, title, and start-date as returned by the connector. This is the spine of every note.
2. **The company's own stated facts** - only if they appear in the Clay company record (e.g. the description literally says "now part of Greencore" or "17 stores in the Midlands"). Restate them faithfully; add no spin. If it isn't in the captured record, treat it as not available.

## Banned outright
- Your own world knowledge about the company, its market, or its strategy.
- Plausible inference or extrapolation ("as it pushes into heat pumps", "scaling on the AI compute wave", "as law firms rethink how they run", "investing for net zero").
- Sector or market commentary that isn't a captured fact about this specific company.
- Adjectives that imply a fact you don't have ("rapidly growing", "ambitious", "struggling").

## Structural rules
- Never credit the recipient with their own hire or role.
- Recency: only call a hire recent if it's within 24 months of today.
- Always hedge the opener ("looks like").
- No dashes, no banned words, ≤300 characters, no exclamation marks.
- **Never fabricate to fill a gap.** If there is no honest hook, say so and flag it - "no honest signal" is an allowed outcome; a made-up one is not.

## When the data is thin
- If the only recent senior hire is the decision-maker themselves, there is no honest non-self-credit hook. Say so and offer a softer, still-true opener grounded in a captured company fact, or recommend skipping. Do not invent a signal.
- If Clay returns the wrong company (a different entity), re-run with the correct LinkedIn company URL before writing anything.
- If the company sells transformation/change/management-consulting or IT-transformation services, it's a competitor - flag it, don't message.
