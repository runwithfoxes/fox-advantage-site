# Method detail

## Why this works
Eaton Square helps organisations make change programmes actually land. The best moment to reach a company is when it has just built or refreshed the leadership that will run that change - a new C-suite, a transformation function stood up, a merger/PE refresh, a cluster of new operations/programme directors. The note names that real, recent signal and offers help with the part that's hard: making the change hold after the programme lands.

## The Clay call
- Tool: the Clay connector's `find-and-enrich-contacts-at-company`.
- `companyIdentifier`: domain (preferred) or LinkedIn company URL. Never a bare name.
- Fix obvious bad domains: a careers/jobs domain (`*.jobs`, `*careers*`) → the real corporate domain. A global giant resolving to its overseas parent → use the UK LinkedIn company URL to get UK contacts.
- `contactFilters.job_title_keywords`: `["Chief","Director","Head of","Transformation","Change","Programme","Operations","Integration","Improvement","PMO","Operating Model"]`

## Decision-maker selection (Sarah's lens)
Priority order:
1. Chief Transformation/Change Officer; Group Head of Transformation; Transformation/Change Director.
2. Head of Transformation/Change/PMO; Programme/PMO Director.
3. COO; Operations Director; a new CEO where there's a leadership-rebuild signal.
4. Transformation/Change/Programme Manager.
Exclude: engineering/capital/plant "Project Managers" (manufacturing noise); client-delivery PMs at software vendors; anyone whose latest experience company is not the target (wrong-entity).

## Churn as signal
A cluster of recent senior hires - new CEO, whole new C-suite, PE-backed refresh, several new operations/programme directors - is a strong change signal even with zero "transformation" job titles. Many mid-market firms run change through Operations, not a titled transformation team. Don't require a transformation title; read the leadership churn.

## Tiers
- **STRONG** - a clear change owner, or a cluster of recent senior-leadership hires / new C-suite / merger or PE refresh.
- **MODERATE** - some leadership churn or a partial change function.
- **THIN** - isolated or old hires, small or stable company, no clear owner.
- **COMPETITOR** - sells transformation/change/management-consulting or IT-transformation services. Flag, do not message.

## ICP notes
- Sweet spot is UK mid-market and mid-to-large organisations going through real change.
- Global mega-corps usually resolve to scattered overseas contacts and are a weak fit - flag as ICP-weak rather than forcing a note.

## Recency
Today is the reference point. A hire is "recent" only if within 24 months. For a cluster spanning into older dates, say "over the past couple of years"; never imply a 2023 hire is recent. Drop hires older than ~24 months from Beat 1.

## Message spec (repeat)
Three beats, ≤300 chars total. Beat 1 variable (≤~130 chars), Beats 2 and 3 fixed verbatim. See SKILL.md. Vary Beat 1's angle to the signal type (new-leadership / team build-out / merger-integration / transformation-function-stood-up) so notes don't read templated - while staying strictly inside the evidence.

## Worked examples (real, gate-passed)
- New C-suite: *"Looks like Arriva has brought in a new CEO, CIO and group technology director over the past year, plus a people director."*
- Merger: *"Looks like Bakkavor is integrating with Greencore, with a change and business readiness lead and a senior change manager now in role."* (Greencore fact is in the Clay company record - allowed.)
- Transformation function: *"Looks like Audley Travel has added a chief product and operations officer plus client and tech delivery heads over the past year."*
Each grounds in OTHER hires, hedges, and never cites the recipient's own role.
