# Maintaining the growth desk

A plain-English guide to changing and looking after the growth desk over time. Written for
whoever on the team owns it day to day. You do not need to be a developer. If you can edit a
spreadsheet and paste text into a box, you can maintain this.

Read the first section once so the rest makes sense. After that, jump to the question you have.

---

## How the thing is actually built

The growth desk is three parts, and it helps to keep them straight because changing one is
not the same as changing another.

1. **The instructions.** A block of text that tells the desk how to behave: who the people
   are, what the sheets are, what it must never do. This lives in the project's Instructions
   box. **This is the desk's brain. Change behaviour here.**
2. **The knowledge files.** A handful of documents loaded into the project (voice guides, the
   message template, the letter framework, this file). They carry the craft. **Change how it
   writes here.**
3. **The Smartsheet.** The numbered sheets in the growth workspace. **This is the desk's
   memory.** Every person, campaign, meeting, number and note lives here. If a fact is not in
   a sheet, the desk cannot know it, and if a fact is wrong in a sheet, the desk will repeat
   it. Change what it knows here.

The single most useful rule: **behaviour lives in the instructions, memory lives in the
Smartsheet.** Almost every "how do I change X" answer is one or the other.

---

## Changing how it behaves

**How do I change a rule or how it answers?**
Open the project, open the Instructions box, find the part you want to change, edit the words,
save. It takes effect on the very next message. The instructions are just text. Write them
the way you would explain the job to a new colleague.

**It did something wrong. How do I fix it?**
Two steps, and people forget the second one.
1. Tell the desk the correct version in the chat. It will fix it for the rest of that
   conversation.
2. **Make it permanent by editing the instructions.** A correction you only make in a chat is
   forgotten the next time someone opens a new chat. If it matters, it goes in the
   instructions. This is exactly what happened with the approval mix-up: the desk had been
   told Sarah approves everything, and the real fix was to change that line in the
   instructions, not just to say so once in a chat.

**How do I change who approves what?**
Approval follows the campaign's owner, on purpose, so it can change without a rewrite.
- To change who approves a particular campaign, change the **Owner** on that campaign in
  sheet 9 (Campaign plan), or the **Sender** on the person's row in sheet 1 (The List).
- To change the rule itself (for example, if you want a second person to sign off content),
  edit the "Hold the gate" and the Sarah section in the instructions.

**How do I add a saved shortcut, like a one-click funnel or "what's on today"?**
Describe what you want once, in detail, then either save it as a project prompt or paste it
into the instructions under a short "Saved prompts" heading. For example: "When I type
/funnel, read sheet 9, show the six stages for every active campaign with the drop-off
percentage between each, then say where the biggest leak is and whether it looks like a
targeting or a message problem." Once it is written down, anyone can trigger it.

---

## Changing what it knows (the sheets)

**How do I add a new campaign?**
Add a row to sheet 9 (Campaign plan). Set the service line, the owner, the status and, if you
have them, the funnel numbers. That is all the desk needs to start reporting on it.

**How do I add or change a service line, a service or an offer?**
These are dropdown lists on the sheets. In Smartsheet, double-click the column heading (for
example "Service line (Area)" or "Offer / Campaign ID"), choose Edit Column, and add or rename
the values. If you add a whole new offer, also add a row to sheet 12 (Offers) so the desk
knows the problem it solves and who it is for.

**How do I add a new person who sends or owns campaigns?**
Add their name to the dropdown lists that carry people: Sender, Owner and Account Owner. Those
appear on sheets 1, 8, 9 and 6. Then give them access to the project and have them connect
their own Smartsheet (see access, below).

**How do I change a target, or record what we spent?**
Edit sheet 13 (Targets) and sheet 14 (Spend) directly. The desk reads targets before it says
how a line is doing, and reads spend before it says anything about cost. Keep them current and
the "how are we doing against plan" and "what did that cost us" answers stay honest.

**How do I add a completely new sheet?**
Two steps, and the second is the one people miss.
1. Create the sheet inside the growth workspace, with sensible column headings.
2. **Tell the desk it exists.** Open the instructions, find the table under "Before you say
   anything: read the sheets", and add a row for the new sheet with a short line on what it
   holds. The desk only reads the sheets listed there. A sheet it has not been told about is
   invisible to it, no matter how good the data is.

---

## Clearing the dummy data and going live

Right now the desk is full of made-up data so you can see every feature work. All of it is
tagged so you can spot it: dummy rows carry "(DUMMY)" or "[DUMMY]" in their text.

**How do I wipe it and start with real data?**
The value is the structure, not the rows. So:
1. In each sheet, select all the rows and delete them. **Do not delete the columns.** The
   column headings, the dropdowns and the layout are what make the desk work.
2. Load your real list. The clean way is to drop a Clay or Apollo export into sheet 0 (Intake),
   or straight into sheet 1 (The List) if it is already enriched.
3. Ask the desk "what's in The List now" to confirm it is reading your data and not a leftover.

**Do it sheet by sheet and keep one source of truth.** The biggest risk is having the same
list in two places. Once it is in Smartsheet, stop keeping the parallel spreadsheet, or the two
will drift and the desk will report from the wrong one.

---

## Access, control and governance

**Who should be able to edit the sheets?**
Lock it down early. Smartsheet lets you control who can view, comment or edit, per sheet and per
workspace. Decide a small list of people who can edit, and give everyone else view or comment.
An open sheet that anyone can change becomes junk fast, and the desk will faithfully report the
junk.

**Can we let someone add new rows but not change old ones?**
Ask your Smartsheet admin about row locking and sheet permissions. A common setup is that only
certain named people per service line can qualify and add a row, and everything already there is
locked. That keeps the record trustworthy.

**Should we have one project or one each?**
The connector to Smartsheet lives in each person's own Claude settings, not in the project. So
even a single shared project means each person still signs in to Smartsheet themselves once. A
shared project is simpler to keep in step; separate projects mean separate instructions to
maintain. Start with one shared project if you can.

**How do I keep it inside the growth workspace and nowhere near client data?**
This matters more than anything else here. The desk is told to work only in the growth
workspace. The hard version of that is a Smartsheet login that can only see the growth
workspace. Whoever connects should connect as a user scoped to that workspace, not as a full
admin, so the desk physically cannot reach client delivery sheets even if someone asks it to.

**How do I connect HeyReach or Smartlead?**
Each is a connector, added in a person's Claude settings under Connectors, the same way
Smartsheet was: add the connector, sign in. Until that is done, the desk will say plainly that
it cannot see live sends. That is not a fault, it is the desk being honest about what it can
reach. A company owner may need to switch a connector on for the whole organisation before
individuals can add it.

---

## Troubleshooting

**It gave me almost no data, or a number that looked far too small.**
It is probably reading the wrong sheet, or an old empty copy of one. Make sure there is only
one set of the numbered sheets, and that the workspace is scoped to just the growth workspace.
Duplicated sheets with the same name are the usual cause.

**It got a day of the week wrong.**
Known weakness. The desk is told never to work out a weekday and always to state the date, but
check any claim that turns a date into a consequence ("that is a Sunday, so it slips to Monday")
before you act on it.

**It answered about a client it should not have touched.**
The instruction not to is only words. The real guard is the scoped Smartsheet login above. If
this happens, fix the access, do not just re-word the instruction.

**It used a testimonial or a client name we have not cleared.**
Check the "Cleared to use?" column on sheet 10 (Proof). Anything not cleared should never
appear in a message. If it did, the row was probably marked cleared by mistake.

**It claimed something is done when it is not.**
The desk should only report what a sheet or a connector says. If a status is wrong, the fix is
in the sheet, not in a telling-off to the desk.

---

## The five habits that keep it healthy

1. **Behaviour goes in the instructions, not in a chat.** A chat fix is forgotten. If it
   matters, write it down.
2. **The Smartsheet is the memory.** If it is not in a sheet, the desk cannot remember it.
   Keep the sheets current and you keep the desk useful.
3. **Tell the desk about any new sheet.** Add it to the sheet list in the instructions, or it
   stays invisible.
4. **One source of truth.** No parallel spreadsheets. Move them in and retire them.
5. **After any change, test it with a real question.** Ask the desk the thing the change was
   meant to fix, and check the answer, before you trust it.
