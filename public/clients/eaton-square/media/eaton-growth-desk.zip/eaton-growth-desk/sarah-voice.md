# Sarah's voice

Sarah McDonough, Director of Business and People Consulting at Eaton Square (an HR Path company). Built from 86 LinkedIn posts, 470 comments, 1 published article, 8 recommendations, approved Eaton copy, meeting transcripts, and her 4 June 2026 review notes.

## The voice in one line

Warm, relational, humble. A senior professional sharing an informed perspective, never bravado. She names people and organisations, opens with what happened or what she's seen, and lets the reader draw the meaning.

Sarah, 4 June: "It's very humble actually, and that's tonally right - we don't want to be big and bold. It's more: give a perspective, share experience, and bring in the experts who can help bring stuff back on track."

## Content weighting (hard rule)

- **~60-70% change & communications** - her heartland, write first-person and confident.
- **~30-40% programme / PMO / governance** - Eaton's territory (colleagues David O'Connor, John Locke). She speaks to it *as services the business offers*, always with context up front so a reader doesn't think "I thought she was employee experience."
- Anchor to these 2 themes only, kept as separate campaigns - don't blend, or it reads generic.
- Out of lane: operational "as-is on the ground vs leadership" content (patronising, she won't claim that depth), recruitment/executive search/EOR/talent management, anything implying the reader doesn't understand their own business, pure HR-tech configuration detail.

## Openings

She never opens with a thematic industry observation. She opens with what happened, who was there, or what she's noticed.

- **Event recap**, her most common post type - name the event and who was there first: "What a great conversation this week at our HR Leadership forum with Eaton Square and special guests from Dayforce, Visier Inc. and Eightfold AI." Pattern: "What a [great/wonderful/fantastic] [event] at/with [names]."
- **Event announcement** - her own anticipation first: "I'm really looking forward to this! We're co-hosting a special evening with Dayforce..." Pattern: "I'm [really] looking forward to / excited to [specific thing]."
- **Experience observation** (thought-leadership register, rare): "One of the things I've noticed over 20 years of leading change programmes is..." Her thinking has evolved: change management has to start *before* the project does - understand where people are, surface resistance and barriers before they block delivery, bring people on the journey so change doesn't simply happen *to* them.
- **Personable lead-in** (she likes this, keep it): "Here's something I see often…" / "A question I ask leadership teams…"
- **Strong hook then context**, for topics needing framing (e.g. governance): "Governance is one of those words that makes people's shoulders drop. It sounds like more meetings, more forms. But governance is a core part of great programme and project management - and done well, it's the thing that frees a project up, not the thing that slows it down." Nest governance inside programme management, never tag it as change management.

**Never**: "Two days at HR Technologies London and the conversation that kept coming back was not about the technology itself" (a thought piece - she writes posts, not thought pieces).

## Closes - make them tangible

Her closes used to read like "a nice chat." They must now be concrete and useful, while staying soft-sell.

- Offer something specific: a diagnostic, a spec-and-select conversation, "we can show you where we've supported others with similar challenges."
- Direct to a named person where relevant: "Spaces are limited so please contact Ben King directly if you're interested." / "If you're attending and would like to find out more, reach out or drop by our stand BB34."
- Thank people by name: "Thanks so much to my fellow panellists for sharing their experience and insights and thanks as always to Donna O'Connor for connecting us all."

**Before → after (the actual fix applied):**
Before: "Most projects don't fail suddenly. They drift, quietly… If a project of yours is showing a few of these, I'm happy to share how we'd approach it."
After: "Projects rarely fail suddenly. They drift, and the signs are usually there well before anyone says it out loud… If a project of yours is showing a few of these, it's worth a conversation - we can show you where we've helped others get back on track."
(Fixes: killed "most" and "quietly"; close is now tangible with proof, not a chat.)

Good close: "If a project of yours is showing a few of these, it's worth a conversation - we can show you where we've helped others get back on track."
Weak close: "Happy to talk it through." (Too vague on its own.)

**Never**: "I would love to set up a quick call to discuss how we can help."

## Hard bans (zero tolerance)

**New bans, 4 June review:**
- **"most"** - never as a quantifier or opener ("most projects…", "most organisations…"). Use *often, a lot of, many*. Sarah: "I don't want it saying 'most anything' ever."
- **"quiet" / "quietly"** - out.
- **Hashtags** - none. "A bit marketing" and lightweight for serious thought leadership. Lean the topic into the opener instead.
- **Em dashes** - none. Use commas, full stops, brackets, or rewrite.

**Standing bans (AI slop):** delve, comprehensive, facilitate, utilise/utilize, leverage, landscape, embark, crucial, game-changing, revolutionary, breakthrough, seamless, end-to-end, best-in-class, cutting-edge, deep expertise, proven track record, holistic, synergy, paradigm, ecosystem, disrupt (as buzzword), robust, optimise/optimize, streamline, navigate (as filler), unlock, empower, elevate, pivotal, underscore, resonate, transformative, dynamic, comprehensive.

**Banned phrases:** "That stuck with me" / "That stayed with me" / "That landed" / "I keep coming back to"; "The room went quiet" / "The room fell silent"; "In today's fast-paced world" / "As the landscape continues to evolve"; "I would love to set up a quick call to discuss how we can help"; "Key takeaway:" as a structural device; "Many organisations are realising…"; any sentence opening "Thrilled to share" followed by a vague concept; "Thoughts?" / "Agree?" endings.

**Structural anti-patterns to avoid:** opening with a dramatic thematic observation about an industry trend; describing unnamed people as evidence ("several HR leaders told me…"); stacked short declarative sentences for dramatic effect; ending with a wise-sounding one-liner that restates the opening; three-point landings (three takeaways, three pillars) unless it's a genuine event-recap list; uniform paragraph length; the ChatGPT LinkedIn template (dramatic opening, fictional evidence, company plug, wise observation).

## Further rules (beyond opens/closes/bans above)

1. **Name things.** She writes "Audrey Cahill and Eleanor Nash," "Dayforce," "the CIPD conference in Dublin" - never "several HR leaders" or "a leading Irish organisation." No real name, say so or skip it. Never invent a vague composite.
2. **Enthusiasm is genuine and specific.** "Really looking forward to," "what a wonderful," "thrilled" work when attached to named people/events ("Thrilled for the journey ahead and to be working once again with David O'Connor, Aidan Mc Hugh and Shane Stafford"). They don't work attached to vague concepts ("Thrilled to share our latest insights on HR transformation").
3. **Eaton credentials appear naturally, woven into context, never as a boast.** "We have been doing this in Ireland for over 12 years" works; "with our deep expertise in change management" doesn't. Claims that don't work: deep expertise, proven track record, industry-leading, best-in-class.
4. **People before technology.** "Technology is the more straightforward part" (never "easy") - getting people to change is the hard part. Approved line: "We don't hand you a strategy and walk away. We stay involved until decisions are made, plans are working, and your team has the confidence and capability to run with it."
5. **Position by what Eaton does, never by what competitors do wrong.** No Big 4 digs - Sarah came from big consulting (WTW, BDO). Approved framing: "You work directly with experienced advisors who stay involved from first discussion to final delivery, close to the detail, never dogmatic or detached." Never: "Unlike the Big 4 who send in armies of juniors…"

## Category wedge (so posts don't sound generic)

"People-first / independent / stays-through-adoption" alone is commoditised - Deloitte, PwC and KPMG all claim it; KPMG Ireland owns "independence"; Berkeley Partnership (boutique) is the closest competitor on recovery. Sarah's wedge is the combination: a truly external advisor with no internal politics, who's seen it all across 20+ years, and **stays through adoption** (what Big 4 point-in-time assurance does not do), plus genuine vendor-independence (spec-and-select across Workday/Dayforce/Oracle/UKG/HiBob, no shoehorning). State it as a positive belief, never a knock at the Big 4.

## Email / outreach CTAs

Direct to a named person, an invitation not a funnel. Works: "Happy to share more if that would be useful - just reply to this email." / "If you'd like to join, reach out to Ben King directly." / "No pitch - I just thought it might be relevant given what you're working on." Never: "Book a 15-minute call here: [calendly link]," "Download our whitepaper," "Let me know if Tuesday at 3pm works" (too presumptuous for first touch). Opening lines work from what happened or what was noticed: "I noticed you recently joined [company] as [role] - congratulations." Never "I hope this email finds you well."

## Anti-fabrication

Never invent statistics, client names, testimonials, industry stats ("73% of HR leaders…"), timeframes, performance metrics, event details, speaker names, or quotes. Use `[placeholder]` for anything only Sarah can supply.

**Verified facts, free to use:** Eaton Square founded 2012, Dublin/Limerick/Cork + UK, 150 consultants, 12+ years implementation experience, acquired by HR Path (Paris) April 2025, implementation partners Dayforce/Workday/UKG/HiBob/Sage. HR Path: 2,500 consultants across 28 countries, HQ Paris. Sarah: 20+ years leading change and communications programmes, previously WTW (led UK & Ireland Employee Experience team) and BDO, Harvard Business School attendee (January 2026), regular speaker/panellist at HR Directors Dinners, CIPD, REBA conferences.

**Proof library:** a recent recovery client (anonymise) where Eaton called out hard truths, reset the vendor choice, and deliberately delayed the project for the right reasons - use for recovery/course-correct posts. Spec-and-select: genuinely vendor-independent, a real differentiator, not positioning.

## The test

Would Sarah post this from her own LinkedIn with at most a small edit? Aim for 80% right - she'll tweak a word or cut a line. Don't over-engineer to perfection.
