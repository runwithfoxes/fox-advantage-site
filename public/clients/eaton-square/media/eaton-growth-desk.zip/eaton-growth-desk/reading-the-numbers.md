# Reading the numbers honestly

Eaton Square sends about fifty LinkedIn connection requests a week. Two hundred a month.
LinkedIn's own ceiling is around five hundred a month, so this will never become a big
number. Every rule below follows from that one fact.

## The hard truth about A/B testing at this volume

To prove a reply rate genuinely moved from 8% to 12%, you need roughly **1,800 sends**.
That is eight months of Eaton's outbound. To prove acceptance moved from 24% to 30%, about
the same. Only an enormous swing - acceptance going from 24% to 36% - can be settled in
about nine weeks.

One week of a 25/25 split produces one or two replies per arm. A single extra reply looks
like a 100% improvement and means nothing at all.

**So your job is not to declare winners. It is to stop people declaring winners.**

When someone says a message is working or failing after a week, tell them plainly: that is
one reply's difference, and one reply is noise. Nobody will thank you for it in the moment
and everybody will be better off in six months. Killing a good message on a bad week is the
most common way a small outbound programme dies.

## What you do instead

**Test big swings, never tweaks.** Do not test two versions of the same sentence, you will
never see the difference. Test a completely different angle. A different reason to make
contact, a different problem named, a different ask. If two messages are near-clones, the
test is dead before it starts and you should say so rather than run it.

**Watch acceptance, not replies, for early signal.** Acceptance is the bigger number: about
twelve a week rather than five. It moves out of the noise sooner. It also tells you
something precise, because acceptance is the connection note doing its job and replies are
the follow-up doing its job.

**Read the two rates together. This is the whole diagnostic:**

- Acceptance down, replies down: the connection note is wrong, or the list is wrong.
- Acceptance fine, replies down: the connection note works and **the follow-up is broken**.
  This is the most common failure and it is the one people misdiagnose, because they blame
  the opener that is working.
- Acceptance fine, replies fine, no meetings: the message is fine and the offer is not.

**Pool before you conclude.** Never compare one week to one week. Compare a month to a
month, and even then say out loud how thin it is.

**Fill in the "Enough data to call it?" column every time.** Three options, and use them
honestly: "No, keep running", "No, and it never will be at this volume", or "Yes, call it".
The middle one is the most useful thing in the sheet, because it tells Sean to stop asking.

## The two gotchas that make numbers lie

**Send schedule.** Campaigns run on weekdays. Zero activity on a Sunday is normal, not a
stall. Never report a weekend as a collapse.

**Runway.** HeyReach shows how many leads have not started yet. That number, not the reply
rate, tells you whether the campaign is about to die. When it approaches zero, the campaign
coasts to a stop no matter how well it is performing. Flag it *before* it hits zero, and
tell Ben to pull a fresh batch in the Clay app.

## The no-note test (Ben, from 20 July)

Connection requests are going out with no note, to see whether acceptance rises. Watch this
one closely.

**A higher acceptance rate is not a better campaign.** Removing the note will almost certainly
lift acceptance, because there is less to object to. It may also lower intent, because the
person accepted without knowing why. Acceptance is the cheap number and it is the one that
moves first. Replies and meetings are the numbers that pay, and they move last.

So: do not let anyone call this after a week. Do not compare its acceptance rate to the noted
version and declare a winner. **Read it all the way down the funnel, or do not read it at
all.** If acceptance rises and replies do not follow it, the test failed, no matter how good
the first number looked.

And say this out loud when the subject comes up. The acceptance number lands first and it
will look like a result before there is anything to read.
