# The message spec (locked)

Do not improvise on this. It was built by hand, broken in testing, and fixed. Every rule
below exists because a message failed without it.

## The LinkedIn connection note

**Hard limit: 300 characters.** Count them. If you are over, cut the first beat, never the tail.

Structure is one variable beat plus a fixed tail:

> Hi {First}, {grounded signal}. The operational day-to-day often steals time from strategic planning. We run a short, no-obligation 'HR Systems & Process Health Check'. Worth a chat?

Working example, 257 characters:

> Hi Aoife, looks like you've been adding to the HR team, including a Reward Manager who joined in May 2026. The operational day-to-day often steals time from strategic planning. We run a short, no-obligation 'HR Systems & Process Health Check'. Worth a chat?

## The first beat, the only part you write

Safe template:

> looks like you've been adding to the HR team, including {a/an} {real title} who joined in {Month Year}

Gates, all of which must pass before the message goes in the sheet:

- **The hedge is mandatory.** "looks like". Never state it as fact. We are inferring from
  public data and we might be wrong.
- **One hire. One.** Never a count, never a plural. "three new hires since March" was tried
  and produced contradictory nonsense.
- **The month and year must appear in the evidence.** If you cannot point at the source,
  you do not write it.
- **The hire is never the person you are writing to.** Exclude the addressee from the
  evidence before you choose a signal.
- **No invented titles.** Use the title as it appears, minus any dash.
- **No dashes** inside the first beat. Strip them from job titles ("HR Advisor Transitions",
  not "HR Advisor - Transitions").
- **Never say "you joined".**

If no hire in the evidence clears these gates, **write nothing**. Set the row to Dead and
say there is no honest reason to contact them yet. A blank is always better than a lie.

## The follow-up, message two

The follow-up is where campaigns die. If acceptance is healthy and replies are not, this
is the thing that is broken, not the connection note.

Open on the signal, not on the offer. This works:

> Thanks for connecting, {First}. The reason I reached out: when a team adds a {Signal Role}, the systems usually get asked to do something they weren't set up to do. That's normally where the time goes. Is that landing anywhere near the mark for you?

This does not, and it is what we replaced:

> Thanks for connecting, {First}. As mentioned, we run a short HR Systems & Process Health Check. It's no-obligation and takes about 45 minutes. Would you be open to one?

Restating the offer gives the reader nothing to react to. Open on their world.

## Who we write to

**Include:** Chief People Officer, CHRO, HR Director, Head of People, Head of HR,
Head of Reward, People Director.

**Exclude:** Talent Acquisition, Recruiter, Recruitment, Coordinator, Assistant.

Never lead a title search with the word "Talent". It floods the results with recruiters
and buries the senior HR leader underneath them.

## The voice

Plain. Peer to peer. The reader is a senior person who is busy, not stupid. No corporate
throat-clearing, no "I hope this finds you well", no exclamation marks, no flattery.
Short words. Say the thing.

## Banned, in every outbound message

- **Em dashes.** Anywhere. Strip them from job titles too.
- **"Compare notes."** Never offer to compare notes, swap notes, or share learnings. It is
  false modesty and it gives away the asymmetry. Eaton Square know something the reader does
  not, and the message should stand behind that. Make a real offer instead.
- **"Most."** As in "most organisations find". You do not know what most do, and neither
  does the reader, so it reads as invention.
- **"Quiet" and "quietly."** A tic, and a tell.
- **Exclamation marks, flattery, and any sentence about how impressed we are.**
- **Any number, name, date or fact that is not in the evidence column.** If it is not
  written down and sourced, it does not go in the message.
