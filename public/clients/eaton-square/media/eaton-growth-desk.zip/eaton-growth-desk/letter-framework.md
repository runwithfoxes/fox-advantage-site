# Writing a direct-mail letter

The method for a personalised Eaton Square direct-mail letter: one human being, one signed letter, built on Drayton Bird's sales-letter principles. Works for any recipient, any offer. Voice is separate - load the sender's own voice file (`sarah-voice.md` for Sarah McDonough, `sean-voice.md` for Sean Courtney, or the equivalent) for tone. This file carries the structure, hard rules, and gates, which apply regardless of who signs.

## Before you write

Get three things. Never guess or invent them.

1. **Who it goes to**: full name, role, organisation. Does the recipient already know the sender's firm? That decides the close.
2. **The close**: cold letters (recipient does not know the sender) always close on a conversation, never a free session or diagnostic. Nobody opens their business to an unknown supplier. An offer close (a named session with a concrete output) is used only when the campaign explicitly specifies a signed-off offer for a warm audience.
3. **The research hook**: what is actually happening at their organisation - a new building, a leadership change, an anniversary, an expansion, a new programme. This makes the letter feel written for them, not a mailshot. Never invent a hook; if none exists, ask for one real detail first.

## Bird's method in brief (the spine)

- **A salesman in an envelope.** Write to one human being. To whom, offering what benefit?
- **AIDCA.** Attention, Interest, Desire, Conviction, Action - all five must be present.
- **Emotion drives, logic justifies.** Find the emotional trigger first, then give the reasons.
- **You, not we.** Talking about yourself instead of the reader is deadly sin one. The reader's world comes first; the sender is held to paragraph three.
- **The opening is most of the job.** Cut the warm-up paragraphs of nearly every draft - the real opening is usually underneath them.
- **Quantify the promise.** Say how, how much, how fast: "a half-day, your senior team in the room, a written five-year description you keep" beats "we'd love to help."
- **Do a complete selling job.** Give every reason to act, answer every objection - the risk-removal line answers "what's the catch?" Proof beats adjectives; a named reference only where genuinely supplied.
- **The PS is the highest-leverage real estate.** Many readers skip straight to it.
- **Make response impossible to fumble.** Direct phone and email, never "visit our website."

## AIDCA mapping

| Part | What it does | AIDCA stage |
|---|---|---|
| 1. Their research hook | Attention, in their world | A |
| 2. Name the feeling | Interest and desire | I / D |
| 3. Sender's relevance | Desire, benefit not feature | D |
| 4. The close (conversation by default; offer only when specified) | Desire to conviction | D / C |
| 5. Remove the risk | Conviction | C |
| 6. Make it easy to respond | Action | A |
| 7. The PS | Conviction and action | C / A |

## The seven parts

**1. Their research hook (Attention).** Something actually happening at their organisation, not who the sender is. The reader should think "they've done their homework," never "this is a mailshot." **Reference the signal, do not recite it** - naming their own situation back to them at length reads as a machine showing its work. Touch it in one line ("I was interested to read about your new STEAM building"), then move to part 2.

**2. Name the feeling (Interest and desire).** Arrive fast, by the end of the opening. Put into words what the person is thinking but hasn't said aloud - an insight, not a recitation of facts they already know.

**3. One paragraph on relevance (Desire).** Now you've earned the right to say who is writing, only in terms of what it does for the reader. One paragraph, not a service list or company history. Benefit, not feature: not "strategic planning" but "everyone in your organisation can see where you're going." The riskiest place to slip into bravado.

**4. The close (Desire into conviction).** The most important paragraph.
- **Conversation close (default, every cold letter).** Offer to share where the sender has helped others through a similar change, and invite a conversation; the reader judges for themselves. No obligation, nothing to prepare. The named session is a follow-on, seeded at most in one light PS line, never asked for.
- **Offer close (only when explicitly signed off).** Specific and quantified: what they get, how long, who's in the room, what they walk away with. If a brief pairs a free offer with a cold audience, flag it and recommend the conversation close.

**5. Remove the risk (Conviction).** Answer "what's the catch?" before it's asked. Offer letter: no cost, no obligation, they keep the output either way. Conversation close: no obligation, nothing to prepare.

**6. Make it easy to respond (Action).** Direct phone and email, not "visit our website." Add a friction-removing line, e.g. "I am happy to work around your schedule."

**7. The PS (Conviction and action).** Always have one. Offer letter: make the session feel real, add light true proof. Conversation close: carry light proof, or seed the follow-on in one line without asking. No invented testimonials.

## What is NOT in the letter

No free session to a cold audience. No mind-reading the recipient - frame insight as "in our experience..." No reciting their own situation back to them. No wasted warm-up, service list, or company history. No jargon ("stakeholder engagement"). No vague, unquantified promise. No cleverness for its own sake. No em dashes.

## The seven deadly sins (run as a gate before handing back)

1. Talking about yourself, not the reader.
2. Failing to make the point fast.
3. Fancy language and jargon.
4. Failing to quantify the benefit.
5. Relying on logic over emotion (no trigger named in part 2).
6. Trying to be clever.
7. Not doing a complete selling job - a reason omitted, or an objection unanswered (usually the missing risk-removal line).

Also check: is the close visible fast and hard to ignore; does the PS carry proof or seed the follow-on; is replying easy; and on a cold letter, is the close a conversation, never a free session.

## Worked exemplar: offer close (signed-off offer, warm audience)

> Dear Barbara,
>
> I was really interested to read about the new STEAM building at Alexandra College, and the empathy education module you have brought into Transition Year. They signal where Alexandra College is heading for the next decade.
>
> We work with schools going through exactly this kind of moment, where there is real ambition and investment, and the leadership team wants to make sure it all connects to a clear direction for the next five years.
>
> I would love to offer you and your Board a half-day Ambition Workshop.
>
> In one session, you will leave with a clear, written description of where you see Alexandra College in the future. Achievable but ambitious. We will push and challenge to make sure it is both.
>
> There is no cost and no obligation. If it is useful, we talk about next steps. If not, you still have the output.
>
> If you are interested, please get in touch directly. I am happy to work around your schedule.
>
> Kind regards,
> [Sender name and title]
>
> P.S. Schools that have done this tell us the value is not just in the detailed Ambition output document. It is also the alignment it creates among the people in the room.

## Worked exemplar: conversation close (cold letter, default)

> Dear Ivan,
>
> I was interested to see that Cornmarket has taken on Marsh Ireland's personal insurance business. Two acquisitions in three years is a lot of growth for any organisation to absorb.
>
> In our experience, the question that follows a period like this is whether the business is set up to carry its new scale. Growth often moves faster than the structure built to support it, and the signs tend to be small at first. Decisions take longer. Lines of responsibility blur. Good people spend their time working around the structure rather than through it.
>
> This is the work we do. We help leadership teams look at how the business is organised and bring it back in line with where the business is going.
>
> If any of this sounds familiar, I would welcome a conversation. I would be glad to share how we have helped other organisations through a similar stage, and you can judge for yourself whether any of it would be useful. There is no obligation in that, and nothing to prepare.
>
> You can reach me directly by phone or email. I am happy to work around your schedule.
>
> Kind regards,
> [Sender name and title]
>
> P.S. If the conversation is useful and you want to take it further, that is when we would look at the structure properly with your senior team. The conversation comes first, and it stands on its own.

## Hard rules (apply to every sender, on top of the persona voice file)

- **PLAIN SIMPLE ENGLISH.** Write every line the way you would say it across a table to a busy senior person. Short, plain words, no metaphors, no adverbs for effect. Test: could you say this out loud without them thinking you're showing off? Example: BAD - "still fits the company it is now, or quietly belongs to the smaller one it used to be." PLAIN - "whether the business is set up to take it on, now that it is a good deal bigger than before."
- **No em dashes.** Zero. Use commas, full stops, or brackets.
- **No "most"** as a quantifier or opener ("most schools"). Use *often, a lot of, many*.
- **No "quiet" / "quietly."** Over-used AI filler.
- **No contractions.** Spell out "I would," "you will," "it is" - never "I'd," "you'll," "it's."
- **No AI-slop words**: delve, comprehensive, facilitate, utilise, leverage, landscape, embark, crucial, game-changing, revolutionary, seamless, end-to-end, best-in-class, cutting-edge, deep expertise, proven track record, holistic, synergy, robust, optimise, streamline, navigate (as filler), unlock, empower, elevate, pivotal, underscore, resonate, tapestry, testament.
- **No AI-slop phrases**: "in today's fast-paced world," "as the landscape evolves," "thrilled to share," "I would love to set up a quick call" (as filler), "it's not just X, it's Y," "thoughts?" or "agree?" endings.
- No hashtags. No bravado. No competitor digs.
- **~230 words.** If it runs over 280, cut.

## The two gates (run both, show the results - never stamp them)

**Gate 1: Fact-check.** List every factual claim - recipient name, role, organisation, the research hook, any other specific detail - as a checklist for the sender to confirm. Never assume a fact is right; if something wasn't supplied, flag a placeholder instead.
> **Verify before sending:** Recipient name spelled correctly · their current role and title · organisation name · research hook is accurate and current · phone/email in the sign-off are correct.

**Gate 2: Slop and voice.** Search the letter, don't assume, and show what you found.
> Slop and voice check (searched, not assumed): em dash / en dash: 0 found · quiet/quietly: 0 found · "most": 0 found · contractions: 0 found · other banned words: 0 found · one call to action: yes · cold-letter close is a conversation, no free session asked for: yes · tone matches the sender's voice file: yes · word count: 232.

Writing "gate passed" without running the search is the worst failure here - it claims a check that never happened. Run it, show it, then hand over the letter. If something couldn't be cleaned, say so plainly rather than hiding it.

## The one rule that matters most

Start in the reader's world, not the sender's. The biggest failure is paragraphs about who's writing before anything about the reader. But reciting the reader's own situation back to them is just as fatal - touch the signal in one line, then pivot fast to an insight they haven't framed themselves. If the first two paragraphs mostly tell the reader things they already know about themselves, the letter has failed.
