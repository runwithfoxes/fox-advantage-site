# The Eaton Square content playbook

Eaton Square (an HR Path company) runs LinkedIn content through three voices: **Sarah McDonough** (Director, Business & People Consulting), **Sean Courtney** (Managing Director), **Ben King** (Business Development Lead). Word-for-word tone, sentence patterns and phrasing for Sarah and Sean live in separate files - `sarah-voice.md` and `sean-voice.md` - not repeated here. This playbook covers the four jobs: pitch ideas, write the post, react fast, review before it ships.

## Universal rules (every post, every voice)

- **No em dashes.** Ever.
- **No "most"** as a quantifier or opener ("most projects…", "most organisations…"). Use *often, a lot of, many*.
- **No "quiet" / "quietly."** Over-indexed AI tell.
- **Hashtags: follow the voice file, do not apply one rule to everyone.** Sarah uses none. Sean's own posts do use them. If you are unsure, ask rather than deciding it for them, and never strip a person's habit out of their voice because another person does not share it.
- **No fabricated stats, client names, testimonials, timeframes, or performance metrics.** Ever. Use `[placeholder]` and say what's needed instead.
- **Closes must be tangible.** Never "happy to have a chat" alone - offer a diagnostic, a named next step, a named contact, or "we can show you where we've helped others." Soft-sell, never hard-sell, always with substance.
- **Positive positioning only.** Never a direct dig at the Big 4 or a named competitor. State what Eaton does; never "unlike Deloitte, who…"

## 1. Pitch ideas

### Territory per person

**Sarah - heartland is change & communications.** ~60 - 70% of her content: change management, change readiness, adoption, internal comms, stakeholder engagement, behaviour change - first-person, confident. ~30 - 40%: programme/PMO/governance/diagnostics, her senior colleagues' territory, spoken to *as a service Eaton offers*, always with context up front so a reader doesn't think "I thought she was employee experience." Anchor to 2 - 3 themes, keep the two campaigns separate. Angle types: change starts before the project does; don't let change happen *to* people; adoption is the hard part, not the technology ("more straightforward," never "easy"); communications as a proper workstream from day one; governance as an enabler (hook, then frame inside programme management); "the goal isn't to give you a PM, it's to get the programme delivered"; the outsider who stays through adoption (never a Big 4 dig); "spec and select" (vendor-neutral selection across Workday/Dayforce/Oracle); recovery / course-correct mid-flight. Out of lane: operational "as-is" detail, recruitment/EOR/talent, anything patronising about the reader's own business.

**Sean - authority-driven, first-person**, across five service lines (HRIS; Business Consulting; Talent Management; Finance Transformation; Transformation & Technology Advisory). Repeated thesis: **the system usually isn't the problem - undefined process, poor data quality and adoption failure are.** Deep topics he owns: the scapegoat pattern (blaming the platform); adoption is the transformation, not the go-live; "was your people function designed for the business you're running today?"; HRIS health checks (assess people, process and technology together - nobody else does both); EU Pay Transparency / UK Employment Rights Act readiness; Employee Ownership Trusts (near-uncontested niche - "ownership is a behaviour, not a structure"); change management in tech transformations ("the people you meet at the pitch are the people who work on your project"); the AI readiness gap ("most of my clients aren't ready for this yet" - sequence, not rejection, never anti-AI). His, not Sarah's: industry analysis, deep frameworks, compliance, the "why transformations fail" thesis. His, not Ben's: first-person authority and drawing the conclusion - Ben only shares the observation.

**Ben - opens the door, doesn't close the argument.** A practitioner sharing a pattern he's noticed in conversations, not an authority. No frameworks, no lists, no personal-authority claims ("I've seen it too many times" is Sean's line, never Ben's). His job is to make the first reply feel low-risk.

### Research the week

Golden rule: **sourced or it does not ship.** Every "why now" hook needs a real URL pulled that session, a named publisher, and a claim stated no stronger than the source states it. Never invent a hook, quote, stat or source - drop the idea instead.

Search three lanes: **competitors** (Deloitte, PwC/PwC Ireland, KPMG UK "Make It" / KPMG Ireland Independent Programme Assurance, Berkeley Partnership); **the category** (change management, adoption, programme governance, AI and change, HR tech trends); **news hooks** (recent, dated restructures, regulation, market moves, biased Ireland/UK). Vary wording run to run, keep only real dated on-lane results, hold each person's theme weighting across a batch. Attach a one-paragraph deep-research prompt to each idea, ending "return sourced, linked findings."

### The strategic gap

Bersin writes the vision. Gartner writes the frameworks. CIPD writes the standards. Vendors write capability. Big 4 write methodology. **Nobody writes from the consultant's seat about what it actually looks like when you're in the room and the adoption isn't working.** Test every angle against that gap - Sean explicitly, and a useful lens for Sarah and Ben too.

## 2. Write the post

### Structures

**Sarah** (pick one, vary across a batch):
- A - Hook → context → POV → tangible offer (default; use when the topic needs framing, e.g. governance).
- B - Experience observation: "One of the things I've noticed over 20 years of leading change programmes is…" → what she's seen → soft invitation.
- C - Single insight: one sharp, practical point, short.
- D - Event/announcement: what's happening + her angle + "reach out to [name]."

**Sean** - first-person authority: (1) personal observation, 1 - 2 sentences ("I've seen it too many times…" / "I ran an HRIS health check for a mid-market organisation last month…"); (2) what he's seen in practice, 2 - 3 sentences; (3) one-sentence invitation ("Come talk to us…"). 60 - 100 words, short paragraphs of 1 - 3 sentences, zero emojis. Signature line "Technology Transformation isn't just about the Tech" - once a month max, don't dilute it.

**Ben** - observation-led, prose only, zero bullets across his entire register: (1) what he's been noticing, 1 - 2 sentences ("We've been having a lot of conversations recently about…"); (2) the pattern in practice, concrete, 2 - 3 sentences; (3) soft door - "Happy to share more if useful" / "Curious if others are seeing the same." 80 - 120 words.

### Worked example - the calibration fixes (apply these by default)

Sarah's own review found almost every "revise" verdict came down to the same two things: a banned word, or a close that was too soft. Fixes, verbatim:
- **Close, before:** "Most projects don't fail suddenly. They drift, quietly… If a project of yours is showing a few of these, I'm happy to share how we'd approach it." **After:** "Projects rarely fail suddenly. They drift, and the signs are usually there well before anyone says it out loud… it's worth a conversation - we can show you where we've helped others get back on track." (Killed "most" and "quietly"; close made tangible with proof, not a vague offer.)
- **Opening, before:** straight into governance as a change-management topic. **After:** "Governance is one of those words that makes people's shoulders drop. It sounds like more meetings, more forms. But governance is a core part of great programme and project management - and done well, it's the thing that frees a project up, not the thing that slows it down." (Keeps the hook, adds context, nests governance inside programme management, not change.)

### Format and cadence

- 2 - 3 posts per person per week, never more than 3, spaced 24+ hours apart, staggered so two voices don't collide on the same day.
- Best days Tue - Thu, best times 7 - 8am and 12 - 1pm local. Sunday works for personal storytelling only.
- Format serves the goal, not the metric. Carousels and multi-image tend to outperform plain text and link posts, but never chase a format for its own sake.
- Carousel: 7 slides, 1080×1350px, <30 words/slide, high-contrast, 2 fonts max. Structure: Cover Hook → Problem → 3 Value Points → Summary → CTA.
- Case studies: Problem-Action-Result-Impact, lead with the metric. Anonymity is expected in HR consulting - compensate with extreme specificity. 1 per voice per week; full carousel teardown every 2 weeks.
- 4:1:1 weekly pacing: 4 educational/insight posts, 1 case study, 1 direct CTA. Rotate one service line per week to build topic authority.

## 3. React (fast take on news or a trend)

Read the source and identify: the core argument, the evidence behind it, the gap (what's missing or oversimplified), and where Eaton's real experience confirms or extends it.

Three angle types:
1. **Agree and extend** - the source is right, Eaton's experience adds depth: "We're seeing exactly this. What I'd add is…" Best for well-known experts making solid points (Bersin, CIPD research).
2. **Respectfully disagree** - the source oversimplifies or misses something seen in practice: "The data is right but the conclusion doesn't match what we're seeing." Best for vendor content, generic advice, oversimplified frameworks.
3. **Apply to a specific context** - the source makes a general point, apply it to a sector: "This is especially true in [sector]. What we're seeing there is…" Best for broad reports, regulatory change, macro trend pieces.

**Never:** attack the source, name a competitor negatively, or dismiss the source. Always respectful, additive.

Structure: name the person/publication (link if possible) → acknowledge the core point in one sentence → add Eaton's perspective, 2 - 3 sentences, grounded in real experience or bracketed `[placeholder]` → close in the assigned voice. 80 - 120 words total - punchy, not an essay.

Voice if unspecified: Sean for thought leadership/industry analysis/deep frameworks/compliance; Sarah for people-focused, talent, culture, relational angles; Ben for practical observations and sector commentary on what he's hearing from prospects.

## 4. Review - the quality gates (nothing ships without passing these)

### Banned words, verbatim

**Sarah's standing AI-slop bans:** delve, comprehensive, facilitate, utilise, leverage, landscape, embark, crucial, game-changing, revolutionary, seamless, end-to-end, best-in-class, cutting-edge, deep expertise, proven track record, holistic, synergy, robust, optimise, streamline, navigate (as filler), unlock, empower, elevate, pivotal, underscore, resonate. Plus: "in today's fast-paced world", "as the landscape evolves", "the room went quiet", "that stuck with me", "I would love to set up a quick call", "thrilled to share" + a vague concept, "Thoughts?"/"Agree?" endings.

**Sean never uses (zero instances across 7 years of real posts):** game-changing, world-class, cutting-edge, innovative, disruptive, leveraging, synergy, holistic, best-in-class, buzzword stacking. Never "I'm thrilled", "so excited", "honoured to", "humbled by". Never lead with methodology over outcomes.

**Ben's hard bans:** game-changing, world-class, cutting-edge, innovative, disruptive, leveraging, synergy, holistic, best-in-class, comprehensive, seamless, end-to-end, paradigm, ecosystem, reimagine, transformative, groundbreaking, excited to share, thrilled, honoured, humbled. Phrases: "In today's fast-paced world" / "As the landscape continues to evolve", "I've seen it too many times" (Sean's line, not Ben's), "The future of HR is…", "Key takeaways:", "That stuck with me" / "The room went quiet". Zero bullet points or numbered lists, zero emojis, ever.

### Anti-fabrication (absolute, all voices)

Never fabricate statistics or data points; never invent client names, company names or testimonials; never create industry statistics ("73% of HR leaders…"); never invent timeframes ("within 30 days"); never assume performance metrics not explicitly provided; never make up event details, speaker names or panel topics; never attribute a quote to someone who didn't say it. Before using any claim ask: did the user provide this exact fact? Is it in the source materials? Can you point to where it came from? Are you inventing it to make the copy sound better? If the first three are no, or the last is yes - don't use it. Use `[placeholder]` and say plainly what's needed: "this post needs a real client example - placeholder used."

**Verified facts, free to use:** Eaton Square founded 2012, Dublin/Cork/Limerick + UK, 150 consultants, 12+ years implementation experience, acquired by HR Path (Paris) April 2025. HR Path: 2,500 consultants, 28 countries. Sarah: 20+ years change & comms, previously WTW (led UK & Ireland Employee Experience) and BDO, Harvard Business School Jan 2026. Sean: Managing Director, 10+ years leading HRIS transformations, hosts Eaton Square HR Leaders Forums. Implementation partners: Dayforce, Workday, UKG, HiBob, Sage. Compliance topics live: EU Pay Transparency Directive, UK Employment Rights Act.

### Fact-check and voice-check

- Every claim traces to source material or is bracketed `[placeholder]` - no exceptions.
- Stated no stronger than the source states it - no inflating a hook or stat.
- On-theme for the assigned person, holding the weighting where relevant (Sarah's 60/40).
- Passes that voice's checklist. **Sarah:** would someone save this? On-theme? Strong personable opener? Humble, not "big and bold"? Tangible close? Zero banned words, no hashtags, no em dashes, no Big 4 digs? Would she post it with at most a small edit - aim for 80% right, not perfection. **Sean:** first-person and concrete, not a general trend claim? "Come talk to us"-style close, not a hard pitch? Under 100 words? Named colleagues, never "the team" unnamed? **Ben:** opens with observation not authority? Every claim concrete, no generalising to "most organisations"? CTA low-pressure? Zero bullets, zero emojis? Under 120 words?

### AI-slop detection pass (every piece)

Vary sentence length - no three consecutive sentences within 5 words of each other. Cut transitional scaffolding ("Furthermore", "Additionally", "Moreover"). Use concrete, surprising words over predictable ones. Let structure follow the argument, not a template. Include at least one thing per piece that couldn't have been predicted from the brief.

### Performance warning signals

Judge content the way you judge outbound: slowly, and against `reading-the-numbers.md`. At this volume a single post proves nothing. Watch for a pattern over weeks, not a spike. And never quote an engagement benchmark you cannot source, in a post or to Sean.
