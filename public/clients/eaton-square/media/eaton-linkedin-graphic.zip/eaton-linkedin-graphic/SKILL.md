---
name: eaton-linkedin-graphic
description: >
  Design ONE LinkedIn graphic in a quiet, unbranded type-and-colour system - portrait 4:5
  (1080x1350), no logos, names, photos or hashtags. Use when the user says "linkedin graphic",
  "make a LinkedIn image", "turn this into a graphic", "design a post image", or pastes a point /
  report / post to distil into a single shareable image. Built to run in the browser (claude.ai):
  the output is a self-contained HTML graphic the user screenshots - NO scripts, NO Python.
  This is the UNBRANDED system (no HR Path / Eaton branding by design) and is NOT hrpath-visual
  (that is the branded, Claude-Code-rendered carousel/diagram builder) and NOT a copywriting skill
  (it lays out words it is given, it does not invent claims).
---

# LinkedIn graphic (quiet system)

Make **one** portrait LinkedIn graphic from a single point. The whole job is restraint: one idea,
generous space, and accent colour used in only three places. You lay out the words you are given -
you do not invent statistics, names, or facts.

## The output

A **self-contained HTML graphic**, canvas exactly **1080 × 1350 px**, that the user screenshots
or exports for LinkedIn. Copy `templates/graphic.html`, fill in the three slots (kicker, headline,
body), and return the finished HTML as an artifact. Nothing else - no logos, no names, no photos,
no hashtags, no extra decoration.

→ Full visual spec, colours, type weights and margins: **`references/design-system.md`**
→ The checks you MUST run before showing the graphic: **`references/self-check.md`**

## How to run it (every time)

1. **Take the input.** The user pastes a point, a report, or a post. If it is long, distil it to
   the **single** idea worth one graphic. One graphic = one idea. If there are two ideas, say so
   and ask which one (or offer to make two graphics).
2. **Write the three slots in plain, tangible language:**
   - **Kicker** - 1-3 words, the label/topic (e.g. `PROGRAMME DELIVERY`). Rendered small,
     uppercase, letter-spaced, weight 600, with a short accent tick to its left.
   - **Headline** - the idea. **Aim 6-12 words, ideally under 10** (it's read at thumb size in the
     feed; ~30 is an absolute ceiling, never a target). Weight 800. At most **one** word may carry
     the accent colour, and only if it genuinely is the pivot of the sentence.
   - **Body** - **usually leave it off.** Optional single short line (≤ ~12 words) only if it truly
     adds something. The richer context belongs in the LinkedIn post text, not on the image.
3. **Build** by filling `templates/graphic.html`. Do not change colours, fonts, the left accent
   bar, or the margins.
4. **Run the self-check** in `references/self-check.md`. This is the loudest part of the job.
   If anything fails - headline too long, accent in the wrong place, a number you cannot source -
   FIX it or flag it in plain English. Never quietly ship a graphic that breaks the system.
5. **Return** the HTML as an artifact, then tell the user in one line how to export it (see below).

## Exporting (browser)

The graphic opens **scaled to fit the window** so the whole 4:5 card is visible at a glance - the
canvas underneath is still exactly 1080×1350. The caption underneath reads the true size and is a
toggle: **click it to switch to 100% (true pixels)** for the export, click again to fit.

To get the image for LinkedIn: click to **100%**, then screenshot the canvas (on Mac: Cmd+Shift+4,
drag the card's edges). LinkedIn accepts the 1080×1350 portrait directly. On a Retina screen the
screenshot is captured at 2× and downscales cleanly.

## Hard rules (the system, non-negotiable)

- **No** logos, brand names, person names, photos, or hashtags. Anywhere. Ever.
- Background `#F7F7F4`, primary text `#16181D`, secondary text `#6B6F76`.
- Accent `#B4541E` (burnt amber) appears in **only** three places: the thin full-height left bar,
  the short tick beside the kicker, and at most **one** highlighted keyword in the headline.
- Typeface **Schibsted Grotesk** throughout. Hierarchy comes from weight (600 / 800 / 400), not
  from colour or decoration.
- Generous margins. One idea. Headline under ~30 words. Plain tangible language.
- **No invented statistics or facts.** If the input has no number, the graphic has no number.

## Gotchas

- **This runs in the browser - no scripts.** Do not reach for Python, Playwright, or any render
  pipeline. The deliverable is HTML the user screenshots. (The branded sibling `hrpath-visual`
  renders to PNG via scripts in Claude Code; that path does not exist for this user.)
- **Accent creep is the #1 failure.** Every extra orange touch cheapens it. Three places, full
  stop. When in doubt, drop the highlighted keyword and let the bar + tick carry the accent.
- **Headline crowding.** Type sized edge-to-edge reads as cheap. The template caps the headline
  width well inside the margins on purpose - do not widen it to fit more words; cut words instead.
- **The user can't debug.** Sarah runs this in claude.ai with no console. The self-check is her
  only safety net - run it visibly and report what you checked, every time.

Add gotchas here as real failure points surface.
