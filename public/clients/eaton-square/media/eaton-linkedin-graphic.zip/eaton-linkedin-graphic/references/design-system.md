# Design system - the quiet LinkedIn graphic

This is the entire visual language. It is unbranded by design (the client cannot use her HR Path /
Eaton branding), so the restraint *is* the identity. Do not add anything that is not listed here.

## Canvas

- Portrait 4:5, **exactly 1080 × 1350 px**.
- One graphic carries **one idea**. If the input has two ideas, make two graphics or ask which one.

## Colour

| Role | Hex | Use |
|------|-----|-----|
| Background | `#F7F7F4` | The whole canvas. Light mode only. |
| Primary text | `#16181D` | Kicker and headline. |
| Secondary text | `#6B6F76` | Body / supporting line. |
| Accent | `#B4541E` (burnt amber) | Sparingly. See below. |

### The accent appears in exactly three places - never more

1. **A thin full-height bar down the left edge.** ~10px wide, runs the full 1350px height, flush left.
2. **A short tick beside the kicker label.** A small horizontal accent rule (~28px wide) immediately
   to the left of the kicker text, vertically centred on the kicker.
3. **At most ONE highlighted keyword** in the headline - and only if that word is genuinely the
   pivot of the sentence. If nothing truly pivots, use zero highlighted words. Never two.

That is the complete accent budget. No accent underlines, boxes, dots, borders, or backgrounds.

## Type - Schibsted Grotesk throughout

Load from Google Fonts (weights 400, 600, 800). Hierarchy comes from **weight**, not colour or size tricks.

| Element | Weight | Treatment |
|---------|--------|-----------|
| Kicker | 600 | Small, UPPERCASE, letter-spaced (~0.12em). Primary text colour. |
| Headline | 800 | The idea. Large. Tight line-height (~1.05). Under ~30 words. |
| Body | 400 | One or two short lines. Secondary grey. Comfortable line-height (~1.4). |

## Layout & spacing

- **Generous margins.** Content sits well inside the canvas - roughly 96px top/bottom/right, and
  left margin clears the accent bar (bar + ~80px breathing space before text starts).
- **Headline width is capped** at roughly 70-75% of the usable width. Do not stretch type
  edge-to-edge to fit more words - crowded type reads as cheap. Cut words, don't widen.
- Vertical rhythm, top to bottom: generous top margin → kicker (with tick) → space → headline →
  space → body. The block can sit slightly above centre or be top-weighted; keep it calm.
- Nothing touches the edges except the left accent bar.

## Language - and word count (read this twice)

This graphic is read on a **phone, in the feed, at thumb size**. A desktop preview flatters a wall
of text that is unreadable small. So the words have to be ruthless:

- **Headline: aim for 6-12 words, ideally under 10.** One line of thought, not a paragraph.
  ~30 words is the absolute ceiling from the brief - never a target. If you are near it, you have
  written a sentence that belongs in the post caption, not on the graphic.
- **Body: usually leave it OFF.** The headline should carry the idea alone. Use the body only for a
  single short line (≤ ~12 words) that genuinely adds something. Never two ideas on one card.
- The richer context goes in the **LinkedIn post text**, not on the image. The image is the hook.
- **Plain, tangible language.** Say it the way you'd say it across a table.
- **No invented statistics, percentages, or facts.** If the source has no number, the graphic has
  no number. A claim on the page must trace to the input the user gave you.
- No corporate filler, no em dashes, no hashtags, no calls to "follow / like / comment".

### Judge it at feed size, not preview size
Before approving, look at the graphic small (the preview opens fit-to-window for exactly this).
If you have to lean in to read the headline, it has too many words - cut, don't shrink the type.

## What is banned (so the system can't drift)

- Logos, brand marks, watermarks.
- Person names, company names, job titles as decoration.
- Photos, illustrations, icons, emoji.
- Hashtags.
- Any colour outside the four above.
- Any second accent touch beyond the three allowed.
- Gradients, shadows, rounded cards, borders, dividers (other than the kicker tick).
