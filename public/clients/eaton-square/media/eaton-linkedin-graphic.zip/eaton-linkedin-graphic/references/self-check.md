# Self-check - run this BEFORE showing any graphic

The person running this skill is working in claude.ai with no console and no way to debug. This
check is their only safety net, so it is the loudest part of the job. Run it visibly: show the
result of each line, then either confirm "all clear" or flag what's wrong in plain English.

If anything fails, do ONE of two things - never both, never neither:
- **Fix it** (e.g. trim the headline, drop the extra highlighted word) and re-run the check, or
- **Stop and flag it** in plain words and ask the user to decide (e.g. "Your point has a statistic -
  `42%` - I can only show it if you confirm it's real and from your source. Want me to keep it?").

## The checklist

1. **One idea?** The graphic carries a single point. If two ideas crept in, stop and ask which one.
2. **Headline length** - count the words. **6-12 is the target, under 10 is better.** Over ~14,
   you are almost certainly cramming the post caption onto the image - cut hard, don't shrink type.
   Body should usually be empty; if present, one short line only.
3. **Accent budget - exactly three places, no more:**
   - left full-height bar ✓
   - kicker tick ✓
   - at most one highlighted keyword (zero is fine) ✓
   - Scan for any *other* orange: underline, box, dot, second keyword, border. If found, remove it.
4. **Colours** - only `#F7F7F4`, `#16181D`, `#6B6F76`, `#B4541E`. No others. No dark background.
5. **Type** - Schibsted Grotesk only; kicker 600 uppercase letter-spaced, headline 800, body 400.
   Hierarchy is from weight, not colour.
6. **No banned elements** - no logo, no brand or person name, no photo, no icon/emoji, no hashtag.
7. **No invented facts** - every number or claim traces to the user's input. If a number appears
   that the user did not give you, remove it or ask them to confirm its source. Do not "fill in"
   plausible figures.
8. **Breathing room** - headline is not stretched edge-to-edge; margins are generous; nothing
   touches the canvas edges except the left bar.
9. **Size** - canvas is exactly 1080 × 1350.

## What to say back to the user

After building, report briefly, e.g.:

> Checked: 1 idea, headline 14 words, accent in 3 places (bar, tick, one keyword "deliver"),
> 4 colours only, Schibsted Grotesk, no logos/names/photos/hashtags, no invented numbers, 1080×1350.
> All clear. Screenshot the artifact at 100% to post.

If you had to flag something, lead with the flag, not the graphic.
