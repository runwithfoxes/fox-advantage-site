# Email Frameworks for Outreach

Proven B2B email structures adapted for Sean Courtney's outreach at Eaton Square. Sean's voice rules still apply -- practical, warm, no hard sell, "come talk to us" not "let me set up a call." These frameworks provide structure, not permission to sound like a sales machine.

---

## Core frameworks

### PAS (Problem - Agitate - Solution)
Best for: Cold outreach, first-touch emails

- **Problem:** State a specific pain point with authority
- **Agitate:** Show the cost or consequence, shared experience
- **Solution:** Present clear resolution with a soft next step

Example structure for Sean:
> **P:** "Processes that made sense when the team was smaller are now slowing things down."
> **A:** "Manual steps that nobody has time to fix but everyone works around."
> **S:** "We've been getting good results automating the ones that matter most -- measurable improvements in weeks rather than months. No agenda. Would be good to have a conversation if it's relevant."

### BAB (Before - After - Bridge)
Best for: Follow-up emails, warm leads

- **Before:** Current frustrating state with specific details
- **After:** Desired future state with tangible benefits
- **Bridge:** How to get from one to the other

### AIDA (Attention - Interest - Desire - Action)
Best for: Event invitations, content promotion

- **Attention:** Bold insight or surprising observation
- **Interest:** Why this matters now
- **Desire:** Specific benefit
- **Action:** Clear, low-friction next step

---

## Subject line principles

Sean's outreach is peer-to-peer, not sales. Subject lines should feel like a senior leader reaching out, not a vendor pitching.

**Works for Sean's voice:**
- Quick question on your [platform] setup
- Great to meet you at [event]
- Following up from [forum/event]
- [Their company] + [specific challenge]
- [Topic] -- something I've been seeing a lot recently

**Never use:**
- RE: or FWD: on first-touch emails (deceptive)
- Fake urgency ("urgent update," "last chance")
- Clickbait ("You won't believe...")
- Generic pitches ("Unlocking HR transformation")

**Rules:**
- Under 45 characters for mobile
- Lowercase is fine if it matches the tone
- No emojis in subject lines for B2B HR outreach

---

## Opening lines

Sean opens with warmth and gets straight to the point.

**Works:**
- "Thanks for your time [day]."
- "Great to meet you at [event] on [day]."
- "I hope you're keeping well."
- "I've been working with a few organisations your size recently and the same thing keeps coming up."

**Never:**
- "I hope this email finds you well" (AI filler -- Sean says "I hope you're keeping well" which is his natural version)
- "I'm reaching out because..." (skip the preamble)
- "I would love to set up a quick call to discuss how we can help" (banned phrase)

---

## CTA patterns

Sean's calls to action are invitations. He uses "come talk to us" and "would be good to catch up" -- never sales pipeline language.

**Works for Sean:**
- "Would be good to catch up properly. Happy to set up a call."
- "No agenda. Would be good to have a conversation if it's relevant to where you are right now."
- "Come talk to us. We assess people, process and technology together."
- "Happy to share how we approach it if that's useful."

**Never:**
- "Book a 15-minute call here: [calendly link]" (too transactional)
- "I'd love to discuss how Eaton Square can transform your HR technology strategy" (corporate pitch)
- "Let me know if Tuesday at 3pm works" (too presumptuous for first touch)

---

## Sequence structure

Sean's email sequences follow the same principle as his LinkedIn: authority first, value second, soft invitation third.

**Email 1 (Day 0):** Introduction + observation from his experience + soft offer
**Email 2 (Day 3-4):** Share something useful (forum invitation, insight, article Sean wrote) + no ask
**Email 3 (Day 7-8):** Light follow-up referencing Email 1 + one question
**Email 4 (Day 14):** Final touch + graceful close ("Completely understand if the timing isn't right")

**Rules:**
- Maximum 4 emails in a cold sequence
- Each email must stand alone (don't assume they read the previous ones)
- Every email must offer something, not just ask for something
- Unsubscribe/opt-out must be available
- Sean signs off as "Sean" (first name only)
- Sean does not hand off to colleagues in email outreach -- he owns the relationship

---

## Formatting rules

- Plain text preferred over HTML for cold outreach (higher deliverability, feels personal)
- Short paragraphs (1-3 sentences max)
- No bullet points in first-touch emails (feels templated)
- One CTA per email, never more
- Sign off as "Sean", not as "The Eaton Square Team"
- Include role and company in signature, not a full marketing footer

---

## Anti-fabrication reminder

All claims in emails must come from verified source materials. Never invent:
- Client results or case study details
- Statistics about the industry
- Quotes from people
- Event details that haven't been confirmed

Use [placeholder] brackets for anything that needs to be filled in with real data.
