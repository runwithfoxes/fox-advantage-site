---
name: reactive-take
description: Eaton Square reactive take writer. Takes influencer content, industry news or competitor announcements and writes Eaton's response in a specified voice. Use when someone says 'what's Sean's take on this', 'react to this', or drops external content and asks for an Eaton perspective.
---

# Eaton Reactive Take

Takes influencer content, industry news, or competitor announcements and writes Eaton Square's response in a specified voice. Sarah drops in a Josh Bersin article and says "what's Sean's take?" -- this skill writes the post.

Use when someone says "what's Sean's take on this", "write a response to", "here's what [person] said", "react to this", "comment on this article", or drops external content and asks for an Eaton perspective.

## Before writing anything

1. Read the voice spec for the requested voice (`references/sean-voice.md`, `references/sarah-voice.md`, or `references/ben-voice.md`)
2. Read `references/messaging-framework.md` -- where does Eaton's position intersect with this content?
3. Read `references/fox-framework.md` -- reactive posts are usually Authority Build or Get Talked About
4. Read `references/anti-fabrication.md` -- never fabricate Eaton's experience with the topic

## Step 1: Read and decode the source

Read the influencer content carefully. Identify:

- **The core argument** -- what is this person actually saying?
- **The evidence** -- what data or experience supports it?
- **The gap** -- what are they missing, oversimplifying, or getting wrong?
- **The overlap** -- where does Eaton's experience confirm or extend this?

## Step 2: Decide the angle

Three types of reactive take:

### Agree and extend
The influencer is right, and Eaton's experience adds depth. "We're seeing exactly this. What I'd add is..."
Best for: well-known experts making solid points (Josh Bersin, CIPD research)

### Respectfully disagree
The influencer oversimplifies or misses something Eaton sees in practice. "The data is right but the conclusion doesn't match what we're seeing."
Best for: vendor-driven content, generic advice, oversimplified frameworks

### Apply to a specific context
The influencer makes a general point. Eaton applies it to a specific sector or situation. "This is especially true in [sector]. What we're seeing there is..."
Best for: broad industry reports, regulatory changes, macro trend pieces

**Never:** attack the influencer, name competitors negatively, dismiss the source. Always respectful, always additive.

## Step 3: Decide whose voice

If the user hasn't specified:
- **Sean** for: thought leadership, industry analysis, deep frameworks, compliance, anything requiring authority
- **Sarah** for: people-focused takes, talent, culture, relational angles
- **Ben** for: practical observations, what he's hearing from prospects, sector-specific commentary

## Step 4: Write the post

### Structure
1. Reference the source (name the person or publication, link if appropriate)
2. Acknowledge the core point (1 sentence)
3. Add Eaton's perspective (2-3 sentences, grounded in real experience)
4. Close in the assigned voice

### Voice rules
Apply the full voice spec for the chosen person. Sean draws the lesson. Sarah connects it to people. Ben shares what he's seeing.

### Length
80-120 words. Reactive posts should be punchy, not essays.

## Step 5: Quality check

- [ ] Source is named and acknowledged respectfully?
- [ ] Eaton's perspective is additive, not dismissive?
- [ ] Grounded in real experience (or bracketed as [placeholder])?
- [ ] Stays in the assigned voice register?
- [ ] No banned words or structural anti-patterns?
- [ ] Under 120 words?
- [ ] Would this person post this without rewriting it?
- [ ] Never attacks the influencer or names competitors negatively?

## Step 6: Present

Show: the source summary, the angle (agree/disagree/apply), the voice, the Fox Framework score, and the ready-to-post content.
