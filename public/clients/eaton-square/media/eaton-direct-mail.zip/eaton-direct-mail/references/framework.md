# The letter framework (Drayton Bird's method, as Eaton uses it)

## Source of truth (read this first, do not write from vibes)

This framework is built on Drayton Bird's real sales-letter method. The canonical craft file is:

`~/paul-hub/intelligence/jo-knowledge/strategies/drayton-bird-sales-letters.md`

That file is the authority. Bird trained Paul directly, and David Ogilvy called him the man who "knows more about direct marketing than anyone in the world." Before you write your first letter, read the craft file. If anything here ever seems to drift from it, the craft file wins. This document exists to point Bird's method at Eaton's specific job: a short, signed, personalised letter from Sarah McDonough offering one concrete, low-risk session. It is not a substitute for the craft file and it does not invent anything beyond it.

## Bird's method in brief (the spine under the seven parts)

These are the principles from the craft file that every Eaton letter must execute. Keep them in mind as you write, not as a checklist to bolt on afterwards.

- **A salesman in an envelope.** You are writing to one human being, not a list. Answer Wunderman's question: to whom are you offering what ultimate benefit?
- **AIDCA.** Attention, Interest, Desire, Conviction, Action. The seven parts below are how a short Eaton letter delivers all five. It is not rigid, but if any of the five is missing the letter is incomplete.
- **Emotion drives, logic justifies.** People, including senior business people, decide for emotional reasons and then find logical excuses. Find the emotional trigger first (that is what part 2 does), then give the rational reasons.
- **You, not we.** Bird's first deadly sin is talking about yourself instead of the reader. Count the "you/your" against the "we/us". The reader's world comes first; Eaton is held back to part 3.
- **The opening is most of the job.** "Devote most of your thoughts to how you begin." The safest opening is the primary benefit plus the offer. Tricky or clever openings rarely work. The best first line is often buried a few paragraphs into a first draft, so cut the warm-up.
- **Quantify the promise.** "Don't tell me I'll get rich or lose weight. Tell me HOW rich or HOW slim, and how fast." Numbers and concrete outputs beat vague claims. "A half-day, your senior team in the room, a written five-year description you keep" beats "we'd love to help".
- **Do a complete selling job.** Every sensible reason to act is given, every reasonable objection is answered. The risk-removal line (part 5) exists because the unspoken objection is "what's the catch?".
- **Proof, not adjectives.** Bird insists on reason-why: examples, social proof, a named reference where one exists. "Why should anyone believe the word of an anonymous copywriter?" For Eaton, the proof is light and earned, never bravado: the PS carries the social proof.
- **The PS is the highest-leverage real estate in the letter.** Always have one. Use it to make the offer real and add proof.
- **Make response impossible to fumble.** A direct phone number and email, and a line that removes the last bit of friction.

Bird's seven deadly sins are the failure list. Run them as a gate before you hand any letter over (see "The deadly-sins gate" below).

## How Eaton's letter maps onto AIDCA

The letter runs about 230 words. Keep it short. A long letter does not get read. The structure stays the same every time. The personalisation lives in parts 1 and 2, which change for every recipient based on what is actually happening at their organisation. Parts 3 to 7 stay close to the proven template.

| Part | What it does | AIDCA stage |
|------|--------------|-------------|
| 1. Their research hook | Attention, in their world | A |
| 2. Name the feeling | Interest and desire, the emotional trigger | I / D |
| 3. Eaton's relevance | Desire, benefit not feature | D |
| 4. The close (conversation by default; offer only when specified) | Desire to conviction, concrete | D / C |
| 5. Remove the risk | Conviction, answer the objection | C |
| 6. Make it easy to respond | Action | A |
| 7. The PS | Conviction and action, proof and the offer restated | C / A |

## The seven parts

**1. Open with their specific research hook.** (Attention)
Open with something that is actually happening at their organisation. A new building, a leadership change, an anniversary, an expansion, a new programme. Not who Eaton is, not what Eaton does. The reader should think "they've done their homework," not "this is a mailshot." This is Bird's primary-benefit-first opening pointed at the reader's world, and it is unique to every recipient.

**Reference the signal, do not recite it.** This is the most common way the opener goes wrong, and it is Bird's first deadly sin in disguise (telling the reader about themselves instead of selling to them). The reader already knows their own situation, structure, and job title better than you do. Naming it back to them at length reads as a machine showing its homework, and they switch off. Touch the signal in one line as a way in ("I was interested to read about your new STEAM building"), then move immediately to part 2. One or two sentences of "what is happening," no more. Never describe their organisation chart, their operating model, or their own role back to them. If your first two paragraphs are mostly telling the reader things they already know, you have written it wrong. The hook earns attention by showing you noticed, not by informing them. Bird's rule: cut the first two or three paragraphs of nearly every draft, because the real opening is usually underneath them.

**2. Name the feeling behind it.** (Interest and desire: the emotional trigger)
This is where the letter earns its place, and it must arrive fast, by the end of the opening, not after two paragraphs of set-up. This is Bird's "emotion drives, logic justifies" in action. Before you talk about what Eaton offers, name what the person is actually thinking but has not said out loud. Someone who has just committed to a major investment is not thinking about consultants. They are wondering whether everything they are doing adds up to something coherent, or whether it will actually deliver. Put that unspoken thought into words. That is the insight, and it is the opposite of reciting facts: it tells them something about their situation they have not framed themselves. If it resonates, they keep reading. This part is also unique to every recipient.

**3. One paragraph on Eaton's relevance.** (Desire: benefit, not feature)
Now you have earned the right to say who Eaton is, but only in terms of what it does for people like them. One paragraph. Not a list of services, not a company history. Lead with the benefit, not the feature, exactly as Bird insists: the feature is "strategic planning," the benefit is "everyone in your organisation can see where you're going." This is also where the "you, not we" discipline matters most. The paragraph is about Eaton, so it is the riskiest place to slip into bravado. Keep it short and keep it pointed at the reader's gain.

**4. The close.** (Desire into conviction)
The most important paragraph. Bird: "the offer is usually decisive ... it should be impossible to ignore." Everything above exists to get them here. There are two types of close, and the audience decides which one the letter uses.

**The conversation close (default for every cold letter).** This is a hard rule from Sarah (12 June 2026). When the recipient does not know Eaton, never offer a free review, diagnostic or session in the first letter. Nobody will open up the inside of their business to an unknown supplier; the ask reads wrong and kills the letter. Sarah's words: "I don't think we'd immediately get a half day model review with their senior team if they have no idea who we are... the call to action needs to be less about a thing that we're going to do for free. It's more an opportunity to have a conversation, to share more about what we do, where we supported organisations on a similar journey, and take it from there." So the close is: Sarah would be glad to share where Eaton has helped other organisations through a similar change, and the reader can take their own view on whether it is useful. Keep it concrete in Bird's sense even without a session: a conversation, what she will share, and that the judgement stays with them. The named session (Programme Diagnostic, operating model review) becomes a follow-on for after a good conversation. It may be seeded in one light line in the PS, never asked for.

**The offer close (only when the campaign explicitly specifies a signed-off offer).** The proven example is the schools campaign with the half-day Ambition Workshop. Make it specific and quantified: a half-day session, your senior team in the room, you leave with a written five-year description, achievable but ambitious. A concrete thing with a concrete output and a concrete time commitment. Quantify the promise the way Bird demands: how long, who is in the room, exactly what they walk away with. If the brief pairs a free-session offer with a cold audience, flag the conflict and recommend the conversation close.

**5. Remove the risk.** (Conviction: answer the objection)
The reader is now thinking "what's the catch?" This is the complete-selling-job principle: answer the objection before they raise it. On an offer letter: no cost, no obligation, you keep the output either way. On a conversation close: no obligation, and nothing to prepare. This line does more selling than three paragraphs of credentials. It shifts the decision from "should I hire this consultancy?" to "is a short conversation worth my time?" That is a much easier yes.

**6. Make it easy to respond.** (Action)
Bird: make the response mechanism do the work for them, never make them fumble it. Direct phone number, direct email. Not "visit our website" or "fill in a form." Add a line that removes the last bit of friction, such as "I am happy to work around your schedule."

**7. The PS.** (Conviction and action: proof, and the close restated)
Bird calls the PS the highest-leverage real estate in any letter. Many people read the greeting, skip to the PS, then decide whether to read the middle. Always have one and make it carry weight. On an offer letter, do two things: make the session feel real and practical (for example, "the session works best with 4 to 6 of your senior team in the room"), and add social proof, which is Eaton's "reason-why" (other organisations have done this and found the real value was the alignment it created, not the document). On a conversation-close letter, the PS may do one of two things: carry light, true social proof, or seed the follow-on session in one line without asking for it (for example, "if the conversation is useful and you want to take it further, that is when we would look at the structure properly with your senior team; the conversation comes first, and it stands on its own"). If there is a named reference the sender can use with permission, the PS gets stronger. Keep the proof light and true. No invented testimonials, no fabricated names.

## What is NOT in the letter

- No free review, diagnostic or session offered in a cold first letter. The recipient does not know Eaton, and the ask reads wrong. The close is a conversation; the session is a follow-on. (Sarah, 12 June 2026.)
- No mind-reading the recipient. Never tell them what they are privately thinking, or what is and is not said at their board table. Frame the insight as pattern from experience ("in our experience...") and let them recognise themselves in it. Mind-reading a stranger is the familiarity failure in disguise.
- No reciting the reader's own situation back to them. No describing their structure, operating model, recent reorganisation, or their own job title as if informing them. They know it. Reference the signal in a line, then pivot to the insight. (Bird's deadly sin 1.)
- No wasted warm-up. Do not spend two or three paragraphs clearing your throat before the point. (Bird's deadly sin 2.)
- No list of services.
- No company history. No "we are a boutique strategic consultancy with extensive experience." That language is about Eaton, not the reader. If they want credentials, that is what a case-study insert in the envelope is for.
- No jargon, no fancy language. No "stakeholder engagement," no "organisational transformation." Plain, short words and short sentences. (Bird's deadly sin 3, and Orwell's rules.)
- No vague, unquantified promise. (Bird's deadly sin 4.)
- No cleverness for its own sake. Reeves: "Originality is the most dangerous word in the advertiser's lexicon." (Bird's deadly sin 6.)
- No em dashes. Clean punctuation.

## The deadly-sins gate (run before you hand any letter over)

From the craft file. If the letter commits any of these, fix it before it goes back:

1. Talking about yourself, not the reader.
2. Failing to make the point fast, wasting two or three paragraphs warming up.
3. Fancy language and jargon.
4. Failing to quantify the benefit.
5. Relying on logic over emotion (no emotional trigger named in part 2).
6. Trying to be clever.
7. Not doing a complete selling job: a reason omitted, or an objection left unanswered (usually the missing risk-removal line).

Also check: is the close visible quickly and impossible to ignore; does the PS carry proof or seed the follow-on; is it genuinely easy to reply; and on a cold letter, is the close a conversation and not a free session.

## Worked exemplars

The framework is the same for every campaign. The close and the opening change; parts 3 to 7 stay close to the same. Two exemplars follow, one per type of close. Both follow the seven parts exactly and hold Eaton Square back to the third paragraph. Match the exemplar to the close you are writing: the conversation-close letter is the model for every cold campaign; the schools letter is the model only when the campaign specifies a signed-off offer.

### Exemplar: schools / Ambition Workshop (offer close, signed off)

This is the letter Sarah and Sinead approved for Alexandra College.

> Dear Barbara,
>
> I was really interested to read about the new STEAM building at Alexandra College, and the empathy education module you have brought into Transition Year. They signal where Alexandra College is heading for the next decade.
>
> We work with schools going through exactly this kind of moment, where there is real ambition and investment, and the leadership team wants to make sure it all connects to a clear direction for the next five years. That is what Eaton Square does: we help schools create ambition and deliver a vivid detailed vision so your team, your board, and your community can see it and buy into it.
>
> I would love to offer you and your Board a half-day Ambition Workshop.
>
> In one session, you will leave with a clear, written description of where you see Alexandra College in the future. Achievable but ambitious. We will push and challenge to make sure it is both.
>
> There is no cost and no obligation. If it is useful, we talk about next steps. If not, you still have the output.
>
> If you are interested, please get in touch directly. I am happy to work around your schedule.
>
> Kind regards,
> Sarah McDonough
> Director, Eaton Square
> [email] | [phone]
>
> P.S. Schools that have done this tell us the value is not just in the detailed Ambition output document. It is also the alignment it creates among the people in the room. This is why it works best when in person.

### Exemplar: cold letter / conversation close (drafted to Sarah's 12 June 2026 feedback)

This letter was redrafted from Sarah's feedback on the first OD draft (too familiar, and she would not offer a free Operating Model Review to a stranger). It shows the conversation close, the pattern-from-experience framing instead of mind-reading, and the follow-on session seeded in the PS. Sarah and Sinead may still tweak the wording, but the shape is the one to copy for every cold letter.

> Dear Ivan,
>
> I was interested to see that Cornmarket has taken on Marsh Ireland's personal insurance business. Two acquisitions in three years is a lot of growth for any organisation to absorb.
>
> In our experience, the question that follows a period like this is whether the business is set up to carry its new scale. Growth often moves faster than the structure built to support it, and the signs tend to be small at first. Decisions take longer. Lines of responsibility blur. Good people spend their time working around the structure rather than through it.
>
> This is the work Eaton Square does. We help leadership teams look at how the business is organised and bring it back in line with where the business is going. A lot of our work in this area comes after acquisitions, in insurance and financial services among other sectors.
>
> If any of this sounds familiar, I would welcome a conversation. I would be glad to share how we have helped other organisations through a similar stage, and you can judge for yourself whether any of it would be useful to Cornmarket. There is no obligation in that, and nothing to prepare.
>
> You can reach me directly by phone or email. I am happy to work around your schedule.
>
> Kind regards,
> Sarah McDonough
> Director, Eaton Square
> [email] | [phone]
>
> P.S. If the conversation is useful and you want to take it further, that is when we would look at the structure properly with your senior team. The conversation comes first, and it stands on its own.

### Retargeting the seven parts to another campaign (structural note, not a letter)

The framework is campaign-agnostic. Keep all seven parts and every Bird principle. Only three things change, and all of them come from the facts the person supplies, never from invention:

- **Parts 1 and 2** (the research hook and the named feeling) are built from the real signal at that organisation. The benefit-opening states, in the reader's own world, the outcome they want.
- **Part 4** (the close) follows the rule above: a conversation close for a cold audience, an offer close only when the campaign explicitly specifies a signed-off offer as one specific, quantified thing: [what they get], [how long], [who is in the room], [what they walk away with]. Lead with the outcome the recipient wants, not the service name.
- **Part 7** (the PS) cites a real, supplied proof point (a named reference or a true example) once one is given, or on a conversation close seeds the follow-on session in one light line. If no proof is supplied, leave the proof out rather than inventing it.

Parts 3, 5 and 6 stay essentially the same. Do not fill any placeholder with an invented hook, name, statistic, or offer detail. Inventing offer specifics is exactly the failure that removed the old exemplar B.

## Quick structural summary

1. Open with their specific research hook (unique to them) [Attention]
2. Name the feeling behind it (unique to them) [Interest and desire]
3. One paragraph on Eaton's relevance, benefit not feature [Desire]
4. The close: a conversation for a cold audience, the campaign's signed-off offer only when specified [Desire to conviction]
5. Remove the risk [Conviction]
6. Make it easy to respond [Action]
7. PS with proof, or the follow-on session seeded in one light line [Conviction and action]

Paragraphs 3 to 7 stay close to the same across every letter. Paragraphs 1 and 2 are where the research hook makes each letter personal. The whole thing runs about 230 words and reads like one senior person writing to another.
