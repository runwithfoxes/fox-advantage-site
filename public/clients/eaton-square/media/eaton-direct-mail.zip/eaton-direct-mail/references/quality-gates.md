# The two gates (run both, every letter)

Run these before you hand any letter back, single or batch. Show the results so the person can see them.

## Gate 1: Fact-check

Direct mail fails when a real detail is wrong. On the school campaign this gate caught 11 wrong principal names and 4 other factual errors before anything was posted. It is the most important safety step in this skill.

What to do:

1. Pull out every factual claim in the letter. That means: the recipient's name, their role or title, the name of their organisation, the research hook (the new building, the leadership change, the anniversary, the programme), and any other specific detail.
2. List each one as a checklist item the sender must confirm.
3. Make clear you cannot verify these for them. You only know what they pasted in. They must confirm each item is correct before the letter goes out.

Present it like this:

> **Verify before sending:**
> - [ ] Recipient name spelled correctly: Barbara Ennis
> - [ ] Her current role and title
> - [ ] Organisation name: Alexandra College
> - [ ] Research hook is accurate and current: new STEAM building, empathy module in Transition Year
> - [ ] Phone and email in the sign-off are correct

Never quietly assume a fact is right. If something was not given to you, do not put it in the letter. Use a clear `[placeholder]` and flag it.

## Gate 2: Slop and voice

Clean the letter against Sarah's voice before handing it over. Check, in order:

1. **Em dashes.** Search the whole letter. Replace every em dash or en dash with a comma, full stop, or brackets. Zero allowed.
2. **Contractions.** Spell them out: "I would", "you will", "it is". The signed-off letters do not use contractions.
3. **Banned words.** Remove every word and phrase on the banned list in `references/voice.md`.
4. **"most" / "quiet" / hashtags.** None of these.
5. **No throat-clearing.** The first line is the research hook, in the reader's world. Not "I hope this finds you well", not "My name is Sarah and I work at Eaton Square."
6. **No list of services, no company history, no jargon.** If a sentence is about Eaton rather than the reader, cut it unless it is the single relevance paragraph (part 3 of the framework).
7. **One close, one call to action.** Not two asks. Not "call me or visit our website or fill in the form."
8. **Cold-letter close.** If the recipient does not know Eaton, the close must be a conversation. No free review, diagnostic or session offered in the letter; the session may only be seeded in one light line in the PS. (Sarah, 12 June 2026.)
9. **Tone: professional, not familiar.** No mind-reading the recipient, no phone-call register, nothing that relies on the reader being relaxed and matey. Insight framed as "in our experience". See the tone rule in `references/voice.md`.
10. **Length.** About 230 words. If it is over 280, cut.

Do not write "gate passed" as a claim. You must actually search the letter for each item and show what you searched and what you found, like this:

> Slop and voice check (searched, not assumed):
> - em dash / en dash: 0 found
> - quiet / quietly: 0 found
> - "most": 0 found
> - contractions: 0 found
> - other banned words: 0 found
> - clever phrases / metaphors / "say it straight" test: passed
> - one call to action: yes
> - cold-letter close is a conversation, no free session asked for: yes
> - tone is professional, not familiar (no mind-reading, no phone-call register): yes
> - word count: 232

If you did not perform the search, you are not allowed to write the line. A "passed" line with no real search behind it is the single worst failure in this skill: it is claiming a check ran when it did not. Run it, show it, then hand over the letter.

If anything could not be cleaned (for example the offer is genuinely two asks because the brief required it), say so plainly rather than hiding it.
