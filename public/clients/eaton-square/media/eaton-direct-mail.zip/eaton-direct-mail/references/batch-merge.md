# Batch merge (after one letter is approved)

Only offer this once the person is happy with a single letter. That approved letter becomes the template. The merge holds the proven parts the same and personalises the opening for every recipient.

## How the person gives you the data

They paste the spreadsheet straight into the chat as text. You cannot open files on their computer, so everything happens in the chat window. Tell them this plainly. They can copy the rows out of Excel or Google Sheets and paste them in, or type the list.

Ask them to include, for each recipient, at least:

- **First name** (for the greeting)
- **Role or title**
- **Organisation name**
- **The research hook** for that recipient (what is happening at their organisation right now)

If a column is missing for a row, do not invent it. Flag that row and ask for the detail, or leave a clear `[placeholder]`.

Tell them they can paste voice notes or special instructions in the same message. For example, "keep the offer as the Ambition Workshop for all of them" or "school three wants a different sign-off."

## How you build the batch

1. Take the approved single letter as the master template.
2. Keep paragraphs 3 to 7 (relevance, close, risk removal, call to action, PS) the same for every recipient, unless their instructions say otherwise.
3. Rewrite paragraphs 1 and 2 (the research hook and the feeling behind it) fresh for each recipient, from that row's hook. This is what makes each letter personal. Do not reuse the same opening across rows.
4. Use the correct first name in the greeting and the correct organisation name throughout.
5. Produce one complete letter per row, clearly separated and labelled with the recipient's name and organisation.

## Run the gates across the whole batch

After building all the letters, run both gates from `references/quality-gates.md` across every letter:

- **Fact-check:** produce one combined checklist, grouped by recipient, listing every name, title, organisation, and research hook to verify. This is where wrong names get caught, so do it for every row, not a sample.
- **Slop and voice:** clean every letter (em dashes, contractions, banned words, one call to action, length). Confirm the whole batch passed.

## Output

Hand back:

1. All the letters, one per recipient, ready to copy out.
2. The combined verify-before-sending checklist, grouped by recipient.
3. A one-line confirmation that the slop and voice gate passed across the batch, with the number of letters produced.

If any rows were missing data or could not be completed, list them at the end so nothing is missed.
