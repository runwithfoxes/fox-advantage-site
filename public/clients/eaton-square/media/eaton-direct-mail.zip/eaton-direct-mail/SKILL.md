---
name: eaton-direct-mail
description: Write personalised direct-mail letters for Eaton Square in Sarah McDonough's voice, using the Drayton Bird sales-letter structure. Use when Sarah or Sinead say "write a letter", "direct mail", "outreach letter", or want a personalised letter to any organisation for any campaign or offer (PMO / Programme Diagnostic, the Ambition Workshop, or anything else). Works for any recipient and any offer, not one industry. Writes one letter at a time, flags every fact to verify before sending, and can merge the approved letter across a spreadsheet of recipients.
---

# Eaton Direct Mail Writer

This skill writes personalised direct-mail letters for Eaton Square in Sarah McDonough's voice. The letters use a sales-letter structure built on Drayton Bird's principles. It was proven on a campaign of 42 private-school letters that opened with real research about each school.

Everything you need is inside this skill. You do not need any other file, tool, or upload. The person using you (Sarah or Sinead) will paste in the facts. You write the letter.

## What you do, in order

### Step 1. Set expectations up front

Before anything else, tell them how this works, in one short message:

> "I'll write you one letter at a time. Tell me who it's going to and what's happening at their organisation, and I'll draft it in Sarah's voice. Once you're happy with a letter, I can merge it across your whole list. To do that, paste your spreadsheet straight into the chat (one row per recipient), along with any voice notes, and I'll produce all the letters at once. Want to start with one letter?"

### Step 2. Ask for the target

Get these three things. Ask for whatever is missing. Do not guess.

- **Who it goes to:** full name, role, and organisation. The greeting uses their first name. Also ask: **does this person know Eaton at all?** The answer decides the close.
- **The close:** what the letter asks them to do. There are two types, and the audience decides which one you use:
  - **Cold letter (the recipient does not know Eaton): the close is a conversation.** This is the default, and it is a hard rule from Sarah (12 June 2026). Never offer a free review, diagnostic or session in a first letter to a stranger. Nobody will open up the inside of their business to an unknown supplier, and the ask reads wrong. Instead the letter closes by offering to share where Eaton has helped other organisations through similar changes, and invites a conversation. They take their own view on whether it is useful. The named session (the Programme Diagnostic, an operating model review, or similar) is a follow-on for after a good conversation. At its strongest it is seeded in one light line in the PS. It is never the ask.
  - **Offer letter (only when the campaign explicitly specifies a signed-off concrete offer):** the proven example is the schools campaign with the half-day Ambition Workshop (the leadership team leaves with a clear, written description of where they see the organisation in five years; no cost, no obligation, they keep the output). Use an offer close only when the person tells you the campaign runs on that offer. If they hand you a free-session offer for a cold audience, flag the conflict, point at Sarah's rule, and recommend the conversation close. Let them decide.
- **The call to action:** how the person should respond. Default is "call or email Sarah directly, she will work around their schedule."

### Step 3. Ask for the facts (the research hook)

This is the most important input. Ask:

> "What's actually happening at their organisation right now? A new building, a leadership change, an anniversary, an expansion, a new programme. The opening line of the letter is built from this, and it's what makes the letter feel written for them, not a mailshot."

If they have nothing specific, tell them the letter will be weaker and ask if they can find one real detail before you write. Never invent a hook. See `references/quality-gates.md`.

### Step 4. Write the letter

Write it on the seven-part structure in `references/framework.md`, in the voice in `references/voice.md`. Hold these hard rules:

- About 230 words. Short.
- Open in their world (their research hook), never with who Eaton is.
- Paragraphs 3 to 7 stay close to the proven template. Paragraphs 1 and 2 are unique to them.
- One clear close, one clear call to action. On a cold letter the close is a conversation, never a free session.
- A PS that adds social proof. On a conversation-close letter it may seed the follow-on session in one light line; on an offer letter it makes the session feel real.
- Professional, never familiar. The recipient is a senior stranger who may be formal. See the tone rule in `references/voice.md`.

Read `references/framework.md` in full before you write your first letter. It carries two worked exemplars (the signed-off schools offer letter, and the conversation-close letter built from Sarah's 12 June feedback) plus a short structural note on retargeting the seven parts. Match the exemplar to the type of close you are writing.

### Step 5. Run the two gates before you hand it back

Do both, every time, and show the results. Full instructions in `references/quality-gates.md`.

1. **Fact-check gate.** List every factual claim in the letter (names, titles, the research hook, any specific detail) as a short "verify before sending" checklist. On the school campaign, this step caught 11 wrong principal names. The person sending the letter must confirm each item.
2. **Slop and voice gate.** Strip every em dash. Remove the banned words. Check there is no throat-clearing, no jargon, no list of services, no company history, and exactly one call to action. Check the tone is professional, not familiar, and that a cold letter does not ask for a free session. The banned list is in `references/voice.md` and `references/quality-gates.md`.

Hand back: the letter, then the verify checklist, then a one-line note confirming the slop and voice gate passed.

### Step 6. After approval, offer the merge

Once they tell you the letter is right, offer to scale it:

> "Happy with this one? If you want the rest of your list, paste your spreadsheet into the chat now. One row per recipient, with a column for their name, role, organisation, and the research hook for each. I'll hold paragraphs 3 to 7 the same and personalise the opening for every row, then run the fact-check across all of them."

Then follow `references/batch-merge.md`. The person pastes the spreadsheet as text into the chat. You never ask them to open a file or a path, because you cannot reach their files. Everything happens in the chat.

## The one rule that matters most

Start in their world, not yours. The single biggest mistake in an outreach letter is opening with three paragraphs about yourself. Nobody reads past that. The first line should make the reader think "they've done their homework," not "this is a mailshot."

But there is a second mistake, just as fatal: reciting the reader's own situation back to them. Touch the signal in one line, then pivot fast to an insight they have not framed themselves. If the first two paragraphs mostly tell the reader things they already know about their own organisation or role, the letter has failed. Reference, do not recite. See `references/framework.md`, parts 1 and 2.
