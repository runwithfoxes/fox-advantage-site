# Message template - Eaton Square / Ben (HR Systems & Process Health Check)

The fixed parts. Only **Beat 1** (the opener) changes per person. Carry everything else verbatim.
Last locked: 3 June 2026 (matches `eaton-heyreach-messages-BKReviewPD.xlsx`, includes the "where" fix).

## Beat 1 - VARIABLE (written from Clay evidence only)
`Hi {First}, looks like {recent HR-hiring signal grounded in the evidence rows}.`

Example (only if the evidence supports it): `Hi Sarah, looks like the People team has grown, with a Head of Reward joining as recently as March 2026.`

## LinkedIn connection note (≤300 chars)
```
{Beat 1} The operational day-to-day often steals time from strategic planning. We run a short, no-obligation 'HR Systems & Process Health Check'. Worth a chat?
```

## InMail
**Subject:** `A quick idea for your HR team`
**Body:**
```
{Beat 1}

When the day-to-day takes over, the strategic side, your data, processes, people and systems, rarely gets a proper look as a whole.

We run a short 'HR Systems & Process Health Check', where one of our consultants does exactly that. No cost, no obligation, no pitch at the end.

If it's worth a conversation, I'll work around you. If not, no harm at all.

Ben
```

## Email
**Subject:** `Your HR systems at {Company}`
**Body:**
```
{Beat 1}

When the day-to-day takes over, the strategic side, your data, processes, people and systems, rarely gets a proper look as a whole.

We run a short 'HR Systems & Process Health Check', where one of our consultants does exactly that. No cost, no obligation, no pitch at the end.

If it's worth a conversation, I'll find a time that suits.

Ben
```

## Gates (checked for every message, by you, out loud)
≤300 chars (connection note) · zero dashes ( -  - or spaced - ) · mandatory "looks like"/"seems" hedge · no "looks like you joined" · every date and title in Beat 1 traceable to the evidence rows. Any fail → Review - don't send.
