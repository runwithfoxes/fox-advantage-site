---
name: eaton-enrich
description: "Turn a clean company + domain list into a ready-to-message outreach list. Use when Ben says 'enrich', 'enrich my list', 'find the HR contact', 'build my outreach list', or pastes/uploads a list of companies to research for the HR Systems & Process Health Check campaign. Finds the one HR decision-maker per company plus a recent-hire signal, and writes the connection note + InMail + email opener. NOT for finding email addresses (that is the separate email step) and NOT for loading into HeyReach (that is the load step)."
---

# Eaton Enrich

This skill takes your cleaned list of companies and, for each one, finds **the right HR person to contact** and **a real reason to contact them now**, then writes your opening messages. You run it yourself in Claude. It uses your Clay connection and nothing else - no downloads, no other tools.

It is deliberately careful. When it is not sure about something, it will **not guess** - it puts that company on a "Review - don't send" list and tells you why, in plain English. Trust that list. The whole point is that a message never goes out unless the fact behind it is real.

## What you give it

A list of companies, pasted in or uploaded as a CSV. Each row needs **at least a company name and a website domain** (e.g. `acme.com`). A company LinkedIn URL works too. That's it.

If a row has no domain and no LinkedIn URL, the skill can't research it - it will list those rows back to you rather than invent anything.

## Before it spends anything (it checks these first, and stops if they fail)

1. **Credits.** It checks your Clay credits. If `hasPlatformCredits` or `hasSalesRepCredits` is true, it's good to go (ignore `hasWorkspaceCredits: false` - that's a red herring).
2. **Exclusions.** It asks one question: "Have competitor-clients and any Dayforce-customer companies already been removed?" If you're not sure, it pauses - we never want to message a company we're not allowed to. (Normally the list-prep step has already done this.)
3. **The Clay connection is awake.** If the Clay tools don't respond, **start a fresh chat and run the skill again** - Clay sometimes goes quiet in a long conversation. A fresh chat fixes it.

## What it does, per company (one Clay call each)

It calls **Clay → find and enrich contacts at company**, using the domain, and asks for HR / People leaders:

```
find-and-enrich-contacts-at-company
  companyIdentifier: "<the domain>"
  contactFilters:
    job_title_keywords: ["Chief People","HR Director","Head of People","People Officer",
                         "Human Resources","Head of HR","Reward","HRIS","People Operations"]
```

That one call returns up to ~20 people, each with a name, job title, when they started, and a LinkedIn URL. **That single answer contains both the person to contact and the signal** - so it's one call per company, never two.

Do them **one company at a time**. For a long list, work in chunks of about 10 and show progress as you go (this is a browser, there's no bulk turbo - steady and visible beats fast and silent).

### Picking the one person (a fixed rule, not a judgement call)

Choose ONE addressee by seniority, top down:
1. Chief People Officer / CPO (including interim)
2. HR Director / People Director
3. Head of People / Head of HR / Head of Reward
4. Senior HR / People Operations Manager

**Never** pick a Talent Acquisition or Recruitment person as the addressee - they're a *signal*, not the contact. **Never** pick someone whose current company isn't the target company. If nobody qualifies, the company goes to **Review - don't send** ("no clear HR decision-maker found"), not a guess.

> Filter note: do **not** put "Talent" first in the title list - it floods the result with recruiters and buries the real HR leader.

### The signal (the real reason to reach out)

From the same list of people, collect the **recent HR/People/Reward/HRIS hires** - roughly the last 18 months. Each one is evidence: `name | title | start date`. Save these rows - every opener has to point back to them.

- **Strong:** two or more recent relevant hires, or a change/systems-flavoured hire (e.g. "HR Change Specialist", "HRIS / Reward").
- **Thin:** one older or generic hire → softer opener, or send to Review.
- **None:** no relevant recent hires → **Review - don't send** ("no signal"). No message written.

## Writing the messages

Only **Beat 1** (the opener) changes per person. Everything else is fixed and carried word for word. The full template is in `references/message-template.md` - read it and use it exactly.

Beat 1 rule: `Hi {First}, looks like {the recent hiring signal, taken straight from the evidence}.` It must:
- state only what's in the evidence (a real title, a real month/year),
- use the "looks like" / "seems" hedge,
- say "as recently as {month}" using the **latest** evidence date (never a later or made-up date),
- describe the team growing, not claim the person did the hiring,
- keep the connection note **≤300 characters**.

## The loud check (do this for every message - it is the most important step)

There is no separate checking tool here, so **you are the checker, and you check hard.** For each message, go claim by claim against that company's evidence rows and tick them off out loud:

- [ ] Every **year and month** in Beat 1 appears as a start date in the evidence.
- [ ] Any **job title** mentioned matches a real title in the evidence.
- [ ] "as recently as {month}" equals the **latest** evidence date.
- [ ] Connection note is **≤300 characters**.
- [ ] **No dashes** of any kind ( - , spaced - ).
- [ ] The **"looks like"/"seems" hedge** is present.
- [ ] It does **not** say "looks like you joined" (that hedges a fact - banned).

**If any box fails, or you're even slightly unsure a claim is real → that company moves to "Review - don't send" with the reason.** Default to Review when in doubt. A message you weren't sure about is worse than a company you didn't message.

Show the evidence next to each opener so it's obvious where the line came from.

## What it hands back

1. **Ready to send** - a table you can copy:
   `Company · Domain · Decision-maker · Title · LinkedIn URL · Signal · Connection note · Evidence`
2. **Review - don't send** - the held companies and the plain reason for each.
3. **A CSV block** to copy into your sheet / the next step, with these columns:
   `First, Last, Company, Title, LinkedIn URL, Email, connection_note, inmail_subject, inmail_body, email_subject, email_body, Verified, Evidence`
   (Leave **Email blank** - emails come from the separate email step.)
4. **A plain summary**, e.g. *"Did 40. 34 ready to send. 6 in Review because I couldn't confirm the hire behind the opener - check those before sending."*

## Hard rules (don't bend these)

- One Clay call per company. No dossiers, no work histories, no email lookups here.
- No message without evidence you can point to. No invented dates or titles. Unsure → Review, never a guess.
- Beats 2 and 3 are carried word for word. Only Beat 1 changes.
- Never lead the title filter with "Talent".
- This skill only uses the Clay connection and your own reading. No code, no file downloads, no other tools. If something seems to need a script, stop and say so - don't fake it.
- Email stays blank. Loading into HeyReach is a different step.

## If something goes wrong

- **Clay tools silent / erroring** → start a fresh chat, run again.
- **"No credits"** → check `hasPlatformCredits` / `hasSalesRepCredits`; if those are true you're fine. If genuinely empty, stop and tell Paul - don't keep trying.
- **A company returns nobody** → that's a real answer: Review - don't send, "no HR decision-maker found". Move on.
