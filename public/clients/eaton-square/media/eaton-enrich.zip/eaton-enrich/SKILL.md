---
name: eaton-enrich
description: "Add the contact details and the signal to a clean company list. Use when Ben says 'enrich', 'enrich my list', 'find the HR contact', or has a cleaned list of companies for the HR Systems & Process Health Check campaign. For each company it finds the one HR decision-maker to contact plus a recent-hire signal, and fills in the details: name, title, LinkedIn, company, location. It does NOT write any messages (that is eaton-message-coach) and does NOT find email addresses (that is eaton-email)."
---

# Eaton Enrich

This skill takes your **cleaned** list of companies and, for each one, finds **the right HR person to contact** and **a real reason to contact them** (a recent hire), then fills in their details. It writes no messages and finds no emails - those are later steps. You run it in Claude, in the browser. It uses your Clay connection and nothing else.

It is deliberately careful. When it is not sure about something, it will **not guess** - it puts that company on a "Review, don't send" list and tells you why, in plain English.

## What you give it

A cleaned list (the output of `eaton-clean`), pasted in or uploaded as a CSV. Each row needs **at least a company name and a website domain** (e.g. `acme.com`). A company LinkedIn URL works too.

If a row has no domain and no LinkedIn URL, the skill can't research it - it lists those rows back rather than invent anything.

## Before it spends anything (it checks these first)

1. **Credits.** It checks your Clay credits. If `hasPlatformCredits` or `hasSalesRepCredits` is true, it's good to go (ignore `hasWorkspaceCredits: false`).
2. **The list is already clean.** This step assumes `eaton-clean` has removed clients, do-not-contact and duplicate companies. If the list hasn't been cleaned, say so and tell Ben to run `eaton-clean` first - don't re-do the exclusions here.
3. **The Clay connection is awake.** If the Clay tools don't respond, **start a fresh chat and run the skill again** - Clay sometimes goes quiet in a long conversation.

## What it does, per company (one Clay call each)

It calls **Clay → find and enrich contacts at company**, using the domain, and asks for HR / People leaders:

```
find-and-enrich-contacts-at-company
  companyIdentifier: "<the domain>"
  contactFilters:
    job_title_keywords: ["Chief People","HR Director","Head of People","People Officer",
                         "Human Resources","Head of HR","Reward","HRIS","People Operations"]
```

That one call returns up to ~20 people with name, job title, start date and LinkedIn URL - **both the person to contact and the signal, in one answer**. One call per company, never two.

Do them **one company at a time**, in chunks of about 10, showing progress.

### Picking the one person (a fixed rule, not a judgement call)

Choose ONE addressee by seniority, top down:
1. Chief People Officer / CPO (including interim)
2. HR Director / People Director
3. Head of People / Head of HR / Head of Reward
4. Senior HR / People Operations Manager

**Never** pick a Talent Acquisition or Recruitment person as the addressee - they're a *signal*, not the contact. **Never** pick someone whose current company isn't the target company. If nobody qualifies, the company goes to **Review, don't send** ("no clear HR decision-maker found").

> Filter note: do **not** put "Talent" first in the title list - it floods the result with recruiters and buries the real HR leader.

### The signal (the real reason to reach out)

From the same list of people, collect the **recent HR/People/Reward/HRIS hires** - roughly the last 18 months, each as `name | title | start date`. Save these - the message step will write every opener from them.

- **Strong:** two or more recent relevant hires, or a change/systems-flavoured hire ("HR Change", "HRIS / Reward").
- **Thin:** one older or generic hire → note it, softer signal.
- **None:** no relevant recent hires → **Review, don't send** ("no signal").

## The loud check (before you hand back)

- [ ] The person picked is a real HR decision-maker at **that** company, chosen by the seniority rule.
- [ ] The signal is real hires with real start dates from the Clay result, not invented.
- [ ] Counts add up: **enriched + review = companies you started with.** Show the sum.

## What it hands back

1. **Enriched list** - a table you can copy, one row per company:
   `First, Last, Full name, Job title, Company, LinkedIn URL, Company domain, Location, Function, Signal`
   The **email is blank** (eaton-email fills it) and there are **no message columns yet** (eaton-message-coach and eaton-merge write those).
2. **Review, don't send** - the held companies and the plain reason for each.
3. **A plain summary**, e.g. *"Did 128. 120 enriched with a contact and a signal. 8 in review, no clear HR decision-maker. 128 = 120 + 8."*

## Hard rules

- One Clay call per company. No dossiers, no work histories, no email lookups.
- Details and signal only. **No messages** - that is eaton-message-coach.
- No person without a real signal. Unsure → Review, never a guess.
- Never lead the title filter with "Talent".
- Clay connection only. No scripts, no downloads. If something seems to need a script, stop and say so.

## If something goes wrong

- **Clay tools silent / erroring** → start a fresh chat, run again.
- **"No credits"** → check `hasPlatformCredits` / `hasSalesRepCredits`; if those are true you're fine. If genuinely empty, stop and tell Paul.
- **A company returns nobody** → that's a real answer: Review, don't send, "no HR decision-maker found".
