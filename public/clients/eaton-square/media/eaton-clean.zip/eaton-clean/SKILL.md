---
name: eaton-clean
description: "Clean and dedupe a new company list before any outreach. Use when Ben says 'clean', 'clean my list', 'dedupe', 'check my list', or uploads a new list of companies to prepare for the HR Systems & Process Health Check campaign. Removes any company that appears on the reference lists (existing clients, do-not-contact, already contacted) so we never message someone we shouldn't. NOT for finding the HR contact (that is eaton-enrich) and NOT for finding emails (that is eaton-email)."
---

# Eaton Clean

This skill takes a **new list of companies** and removes any company we should not contact, by checking it against your **reference lists** (existing clients, a do-not-contact list, anyone already in a campaign). You run it yourself in Claude, in the browser. It uses your own reading - no scripts, no downloads, no other tools.

It is deliberately careful. It matches on the **website domain**, not the company name, because names are messy ("Tesco", "Tesco Ireland", "Tesco PLC" are the same company but read as three). When it cannot be sure two rows are the same company, it does **not** guess - it puts that row on an "unsure, your call" list and tells you why. The whole point is that a clean list is actually clean.

## What you give it

A **new list**, pasted in or uploaded as a CSV. Each row needs at least a **company name and a website domain** (e.g. `acme.com`). This is the list you want to message.

## The reference lists it checks against

These are the lists of companies we must **not** contact: existing clients, a do-not-contact list, anyone already in a campaign.

1. **Look in this project's files first.** If the reference lists are saved here as files, use them. (This is the normal set-up - the lists live in the project so you never have to find them.)
2. **If there are no reference lists in the project, ask Ben to upload them.** Say plainly: "I can't see any do-not-contact or client lists to check against. Upload them and I'll clean against those, or tell me to clean the new list for internal duplicates only."
3. **Never pretend.** If there is nothing to check against, do not say the list is "clean". Say exactly what you did and did not check.

## Before it does anything (it checks these first, and stops if they fail)

1. **The new list has domains.** If rows have no website domain, matching is unreliable - list those rows back and ask Ben to add domains, or treat them as "unsure".
2. **It can see the reference lists in full.** If a reference list is very large and you are not confident you have read all of it, **say so and stop** rather than half-checking. A partial dedupe is worse than none, because it feels done. (Tell Ben: "This list is too big for me to check end to end in one go. Send it in two halves, or split the new list into smaller batches.")

## How it cleans (one pass, in plain steps)

1. **Match on domain.** For each company in the new list, look for the same **domain** on any reference list. Same domain = same company = **remove**.
2. **Then sanity-check names.** For rows where the domains don't match but the **company names look like the same business**, do not remove and do not keep silently - put them on the **"unsure, your call"** list with both rows shown side by side.
3. **Remove internal duplicates.** If the same domain appears twice inside the new list itself, keep one and note the duplicate.

Work through the list in chunks of about 20 and show progress as you go. Steady and visible beats fast and silent.

## The loud check (do this before you hand anything back)

- [ ] Every **removed** company has a matching domain on a named reference list - say which list.
- [ ] Nothing was removed on a **name-only** guess. Name-only matches go to "unsure", never to "removed".
- [ ] The counts add up: **kept + removed + unsure = the number of rows you started with.** Show this sum. If it doesn't add up, something was dropped - find it.
- [ ] You actually read each reference list in full. If you didn't, you stopped and said so.

## What it hands back

1. **Cleaned list** - the new list with the removed and duplicate rows taken out, same columns as you started with, ready for Step 3 (enrich).
2. **Removed, and why** - each company taken out, with the reference list it matched and the matching domain.
3. **Unsure, your call** - the name-only near-matches, both rows shown, for Ben to decide. Nothing here is removed until Ben says so.
4. **A plain summary with the sum**, e.g. *"Started with 150. Removed 18 (12 already clients, 6 already in a campaign). 4 unsure, listed for you. 128 clean and ready. 150 = 128 + 18 + 4."*

## Hard rules (don't bend these)

- Match on **domain**, not company name. Name matches are flagged as "unsure", never removed automatically.
- Never say a list is clean if there was nothing to check it against. Say what you checked.
- Never half-check a list and call it done. If you can't read a reference list in full, stop and say so.
- The three numbers (kept, removed, unsure) must add up to the starting count, shown every time.
- This skill only uses your own reading of the lists. No scripts, no downloads, no other tools. If something seems to need a script, stop and say so - don't fake it.

## If something goes wrong

- **No reference lists anywhere** → say so plainly, offer to dedupe the new list against itself only, and tell Ben the client/do-not-contact check did not happen.
- **A reference list is huge** → stop, explain, ask for it in halves or for smaller new-list batches.
- **Lots of rows have no domain** → list them, ask Ben to add domains; don't match those on name alone.
