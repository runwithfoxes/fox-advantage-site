---
name: eaton-branded-page
description: Convert any document into a scrolling single-page HTML website in HR Path branding for Eaton Square. Use when anyone says "eaton branded page", "hr path page", "brand this for eaton", or gives a document to convert into Eaton/HR Path web format.
agent: general-purpose
---

# Eaton Branded Page Skill

You are converting a document (PowerPoint, PDF, Word doc, Google Slides export, or bullet points) into a single scrolling HTML page in HR Path branding for Eaton Square.

Eaton Square is merging fully into HR Path. All output uses HR Path branding.

## MANDATORY PRE-FLIGHT (before writing any HTML)

### 1. Choose the voice

Ask: **"Sean or Sarah?"** - the two Eaton authors have different voices.

- **Sean Courtney** - thought leadership, HRIS, technology strategy. Direct, authoritative, experienced. Read `~/paul-hub/clients/eaton/sean-materials-2026-05-05/Sean_Style_Writing_Guide.docx` before writing.
- **Sarah McDonough** - change management, communications, people consulting. Warm, relational, names people. Run the `/sarah-voice` skill before writing.

If the source material makes the author obvious (e.g. Sarah's name is on it), confirm rather than asking.

### 2. Voice lint rules (both authors)

All visible text must pass these checks:
- No corporate jargon: future-proof, over-index, activation, ecosystem, leverage, unlock, synergy, reimagine, holistic, paradigm, disrupt, best-in-class, industry-leading, cutting-edge, scalable
- No AI language: delve, comprehensive, facilitate, utilize, landscape, embark, crucial, game-changing, revolutionary, breakthrough
- No em dashes anywhere. Use comma or full stop
- No staccato (three short sentences/fragments in a row)
- No hype or overselling
- Position by what Eaton does, never by what competitors do wrong

---

## Step 1: Read the Source Material

- **PowerPoint (.pptx)**: Use python3 with `python-pptx` to extract all slide content (text, structure, data)
- **PDF**: Read directly with the Read tool
- **Word (.docx)**: Use python3 with `python-docx` to extract content
- **Screenshots/images**: Read them visually
- If charts contain data embedded in images, look for a companion PDF or ask for the data

Extract everything: headings, body text, data tables, chart values, sources, attributions.

## Step 2: Plan the Page Structure

Map the source content into scrolling sections. Typical structure:

1. **Hero section** (gradient background) with title, subtitle, author name, HR Path logo
2. **Alternating sections**: light grey and navy backgrounds
3. **Data sections** with Chart.js charts or styled tables
4. **Conclusion/contact** section with author details

### Interactivity: only what serves the content

The page should feel considered, not animated for the sake of it.

**What to use:**
- **Chart.js charts**: Bar, line, bubble, doughnut for actual data. Scroll-triggered is fine.
- **Timelines**: If the content has a real progression of dates or steps.
- **Visual comparisons**: Side-by-side layouts or split-screen for contrasts.
- **Click/tap expand cards**: Additional detail appears on click or tap, never hover-only.
- **Pull quotes**: Purple left border, text appears. Simple.

**What not to use:**
- Animated counters (numbers counting up from zero)
- Typewriter effects
- Parallax text
- Word-by-word or line-by-line reveals
- Background colour sweep animations on scroll
- Any animation that exists because AI tools default to it

The test: if you removed the animation and the content still made sense, the animation was decoration. Leave it out.

## Step 3: Build the HTML

Create a single `index.html` file. Everything inline, no external files except Google Fonts and Chart.js CDN.

### Brand Spec (complete, authoritative)

Source: HR Path brand templates extracted from `~/paul-hub/clients/eaton/sean-materials-2026-05-05/hr-path-templates/`

---

#### Colours

| Token | Hex | Usage |
|-------|-----|-------|
| `--bg` | `#F5F5F7` | Page background. Light grey, clean. |
| `--bg-white` | `#FFFFFF` | Card backgrounds, content panels |
| `--text` | `#1D1D1F` | Primary body text |
| `--text-light` | `#6E6E73` | Secondary text, labels, captions |
| `--navy` | `#141A3A` | Primary brand colour. Dark sections, headings on light bg. |
| `--purple` | `#4609BB` | Gradient anchor, accent links |
| `--violet` | `#8E18D1` | Gradient mid-point |
| `--magenta` | `#B63EBD` | Gradient mid-point |
| `--blue` | `#154BC0` | Gradient, chart secondary |
| `--light-blue` | `#2486E5` | Gradient, links, interactive states |
| `--cyan` | `#33B8F3` | Gradient highlight |
| `--orange` | `#E8731A` | Logo dot accent. Use sparingly. |
| `--border` | `#D2D2D7` | Dividers, card borders |
| `--card-hover` | `#ECECF0` | Card background on hover |

**Gradient (the signature visual):**
```css
--gradient: linear-gradient(135deg, #4609BB 0%, #154BC0 20%, #33B8F3 40%, #B63EBD 65%, #E8731A 100%);
```
Use for: hero backgrounds, section accent bars, decorative strips. The gradient replaces any flat-colour hero. Never stretch it vertically beyond 500px without overlaying content.

**Banned colours:** No `#000`, `#000000`, `black` as text or backgrounds. Use `--navy` or `--text` instead.

---

#### Typography

**Font (Google Fonts):**
- `Urbanist` - used for everything. The weight carries the hierarchy.

**Full type scale:**

| Element | Size | Weight | Letter-spacing | Notes |
|---------|------|--------|---------------|-------|
| Hero heading | `clamp(42px, 7vw, 80px)` | 900 (Black) | `-1.5px` | White on gradient |
| Section titles | `clamp(32px, 4.5vw, 52px)` | 900 (Black) | `-0.8px` | Navy on light, white on dark |
| Subsection titles | `22px` | 700 (Bold) | `-0.3px` | |
| Card titles | `18px` | 700 (Bold) | `-0.2px` | |
| Body prose | `1rem` (16px) | 500 (Medium) | `0` | `line-height: 1.7` |
| Descriptions | `0.9375rem` (15px) | 400 (Regular) | `0` | |
| Labels/tags | `12px` | 600 (SemiBold) | `1.5px` | uppercase |
| `<strong>` | inherit | 700 | inherit | |

**Rules:**
- Heading weights are 900 (Black) for h1/h2, 700 (Bold) for h3/h4.
- Sentence case only. Never Title Case except proper nouns (HR Path, Eaton Square, Dayforce, Workday).
- No em dashes anywhere. Use comma or full stop.

---

#### Logo

The HR Path logo is an image, not text. Copy the logo PNG into the project folder.

**Nav logo** (without tagline):
```bash
cp ~/paul-hub/clients/eaton/sean-materials-2026-05-05/hr-path-templates/extracted-brand-assets/ppt/media/image4.png ~/projects/[project-name]/hr-path-logo.png
```

**Footer logo** (with tagline):
```bash
cp ~/paul-hub/clients/eaton/sean-materials-2026-05-05/hr-path-templates/extracted-brand-assets/ppt/media/image3.png ~/projects/[project-name]/hr-path-logo-tagline.png
```

**CSS:**
```css
.nav-logo img {
    height: 32px;
    width: auto;
}
.footer-logo img {
    height: 48px;
    width: auto;
}
```

**Over gradient/dark backgrounds:** Use a white version of the logo, or apply `filter: brightness(0) invert(1)` to make the navy logo white.

---

#### Layout

- Container: `max-width: 1100px`, `padding: 0 48px`
- Sections: `padding: 100px 0` (desktop), `padding: 64px 0` (mobile max 768px)
- Mobile container: `padding: 0 24px` (max 768px), `padding: 0 16px` (max 380px)
- Border radius: `8px` on cards and interactive elements. `0` on sections and full-width elements.
- No heavy shadows. Subtle only: `box-shadow: 0 1px 3px rgba(0,0,0,0.08)`

---

#### Gradient Stripe

The gradient is the brand signature, used as a visual accent:

**Hero background:**
```css
.hero {
    background: var(--gradient);
    color: #FFFFFF;
    position: relative;
    overflow: hidden;
    padding: 140px 0 100px;
}
```

**Section accent bar** (top of light sections):
```css
.section--accent-bar::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: var(--gradient);
}
```

**Decorative strip** (used sparingly between sections):
```css
.gradient-strip {
    height: 6px;
    background: var(--gradient);
    width: 100%;
}
```

---

#### Navigation

- Fixed top, `z-index: 100`
- Background: `rgba(245, 245, 247, 0.92)`, `backdrop-filter: blur(16px)`
- No border-bottom by default. Subtle border on scroll: `border-bottom: 1px solid var(--border)`
- Logo on left, section links on right
- Links: Urbanist `13px`, weight `600`, letter-spacing `0.5px`, uppercase, `--text-light` colour, `--navy` on hover
- Mobile (max 768px): logo only, nav links hidden

---

#### Cards

- Background: `var(--bg-white)` (#FFFFFF)
- Border: `1px solid var(--border)`
- Border-radius: `8px`
- Hover: `box-shadow: 0 4px 12px rgba(0,0,0,0.08)`, `border-color: var(--light-blue)`
- Transition: `0.3s ease`

---

#### Buttons

- Primary: `var(--navy)` bg, `#FFFFFF` text, hover darkens slightly
- Accent: `var(--purple)` bg, `#FFFFFF` text, hover `var(--violet)`
- Outline: transparent bg, `1px solid var(--navy)` border, `var(--navy)` text
- All buttons: Urbanist, `14px`, weight `600`, letter-spacing `0.5px`, `border-radius: 8px`, `padding: 12px 28px`

---

#### Charts (Chart.js 4.x via CDN)

- Primary data colour: `#154BC0`
- Colour sequence: `#154BC0`, `#4609BB`, `#8E18D1`, `#33B8F3`, `#B63EBD`, `#E8731A`
- Font family: `'Urbanist'` for all chart text
- Grid lines: `#D2D2D7` at `0.3` opacity

---

#### Tables

- Header: `background: var(--navy)`, `color: #FFFFFF`, `border-radius: 8px 8px 0 0` on first/last cells
- Rows: alternating `var(--bg-white)` and `var(--bg)`
- Border: `1px solid var(--border)`
- Font: Urbanist `14px`, weight `500`

---

#### Animations

- Global default transition: `0.3s ease`
- Fade-ins: scroll-triggered, `translateY(20px)` to `0`, `opacity: 0` to `1`. Subtle and sparse.
- No animated counters. No typewriter effects. No parallax text. No word-by-word reveals.
- Only animate `transform` and `opacity`.
- **Always respect `prefers-reduced-motion`**:
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

---

#### Hard Bans (never use these)

- Gradients other than the brand gradient (no custom gradients, no greyscale gradients)
- Heavy shadows (`box-shadow` with spread > 12px)
- Decorative icons (no icon fonts, no emoji as decoration)
- Pure black (`#000`) backgrounds or text
- Stock photos (use solid colours and the brand gradient instead)
- Title Case headings (sentence case only, except proper nouns)
- Em dashes (` - `)
- Corporate jargon (see voice lint rules)
- Dot grids (that's the RWF brand, not HR Path)
- Fox imagery (that's the RWF brand)

### Page Template Structure

```
- Skip link (accessibility, hidden)
- Nav (fixed, logo + section links)
- Hero section (gradient background, white text)
- Gradient strip
- Content sections (alternating light grey / navy)
- Contact/author section
- Footer (navy background, logo with tagline)
- Scripts (scroll observer, Chart.js bindings, nav scroll behaviour)
```

## Step 4: Verify Data

After building, systematically verify every number, percentage, and data point in the HTML against the source material. Check every table cell, every chart data point, every stat.

## Step 5: Brand Compliance Audit (EVIDENCE REQUIRED)

For every item below, grep or read the built HTML file and cite the actual value found. Present results as a table before opening the page.

Format each check as: `CHECK | EXPECTED | FOUND (with line number) | PASS/FAIL`

Fix all failures before opening the page.

### The checks

**Logo & nav**
| Check | What to grep for | Expected value |
|-------|-----------------|----------------|
| Logo image present | `hr-path-logo` in img src | `hr-path-logo.png` in nav |
| Logo height | `nav-logo.*height` | `32px` |
| Nav z-index | `z-index` on nav | `100` |
| Nav backdrop | `backdrop-filter` | `blur(16px)` |
| Footer logo | `footer-logo\|hr-path-logo-tagline` | Present, with tagline version |

**Colours**
| Check | What to grep for | Expected value |
|-------|-----------------|----------------|
| No pure black | `#000\|#000000\|color: black` | Zero matches |
| Navy colour | `--navy\|#141A3A` | `#141A3A` |
| Background | `--bg\|#F5F5F7` | `#F5F5F7` |
| Gradient present | `linear-gradient.*4609BB` | Present |
| Orange used sparingly | `#E8731A\|--orange` | Fewer than 5 uses (logo dot, small accents only) |

**Typography**
| Check | What to grep for | Expected value |
|-------|-----------------|----------------|
| Urbanist font | `Urbanist` | Present in Google Fonts link and font-family |
| No other brand fonts | `Space Grotesk\|JetBrains` | Zero matches (those are RWF) |
| Heading weight | `font-weight.*900\|font-weight.*Black` on h1/h2 | Present |
| Sentence case | Read every h1, h2, h3 | Correct (except proper nouns) |
| Em dashes | ` - ` | Zero matches |

**Components**
| Check | What to grep for | Expected value |
|-------|-----------------|----------------|
| Card border-radius | `border-radius.*8px` | Present on cards |
| No dot grids | `radial-gradient.*0\.8px` | Zero matches |
| No fox images | `fox.*\.png\|fox.*\.jpg` | Zero matches |
| Gradient strip | `gradient-strip\|height.*6px.*gradient` | Present between sections |

**Accessibility & motion**
| Check | What to grep for | Expected value |
|-------|-----------------|----------------|
| Reduced motion | `prefers-reduced-motion` | Present |
| No hover-only content | `hover` in CSS | No content hidden behind hover-only |
| No layout-triggering animation | `transition.*padding\|transition.*letter-spacing\|transition.*width\|transition.*height` | Zero matches |
| Focus states | `:focus-visible\|:focus` | Present on interactive elements |
| Skip link | `skip.*main\|skip.*content` | Present |

**Voice lint**
| Check | How to verify | Expected |
|-------|--------------|----------|
| No corporate jargon | Read all text | None of the banned words |
| No AI language | Read all text | None of the banned words |
| No staccato | Read all text | No three short fragments in a row |
| No competitor digs | Read all text | No negative positioning against other firms |
| No em dashes in copy | Read all text | Zero |
| Author voice consistent | Read all text | Matches Sean or Sarah's voice patterns |

### Output format

Present the audit as a markdown table:

```
## Brand audit: [project-name]

| # | Check | Expected | Found | Line | Status |
|---|-------|----------|-------|------|--------|
| 1 | Logo image | hr-path-logo.png | hr-path-logo.png | L42 | PASS |
| 2 | No pure black | 0 matches | 0 matches | - | PASS |
...
```

Fix all FAILs. Re-run the audit. Only open the page when every row is PASS.

## Step 6: Open for Review

Open the file in the browser with `open ~/projects/[project-name]/index.html` and describe each section.

## What Never to Do

- No dot grids (RWF brand, not HR Path)
- No fox imagery (RWF brand)
- No Space Grotesk or JetBrains Mono fonts (RWF brand)
- No heavy shadows
- No pure black backgrounds or text
- No stock photos
- No Title Case headings (sentence case only)
- No em dashes
- No corporate jargon
- No competitor comparisons or negative positioning
- No invented data - if you can't read a value from the source, ask
- No generic "contact us" - always name the specific person (Sean or Sarah, plus Ben King for outreach)

## Output Location

Save to `~/projects/clients/eaton/[project-name]/index.html` where `[project-name]` is a kebab-case slug based on the content title.

Copy logo files into the same folder:
```bash
cp ~/paul-hub/clients/eaton/sean-materials-2026-05-05/hr-path-templates/extracted-brand-assets/ppt/media/image4.png ~/projects/clients/eaton/[project-name]/hr-path-logo.png
cp ~/paul-hub/clients/eaton/sean-materials-2026-05-05/hr-path-templates/extracted-brand-assets/ppt/media/image3.png ~/projects/clients/eaton/[project-name]/hr-path-logo-tagline.png
```

## Deployment (optional)

If asked to deploy, push to Vercel:
```bash
cd ~/projects/clients/eaton/[project-name]
npx vercel --prod
```
