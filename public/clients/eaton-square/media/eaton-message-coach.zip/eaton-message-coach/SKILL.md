---
name: eaton-message-coach
description: "Co-write the outreach message sequence, one message at a time. Use when Ben says 'coach me through my messages', 'write my message sequence', 'message coach', 'help me write the messages', or is ready to write the LinkedIn notes and emails for the HR Systems & Process Health Check campaign. It shows the whole journey, then drafts each message with you in your chosen voice, reworks it until you sign it off, and hands back the approved sequence for the merge step. NOT for building the upload file across the whole list (that is eaton-merge) and NOT for finding people or details (that is eaton-enrich)."
---

# Eaton Message Coach

This skill helps you write the **sequence of messages and emails** for a campaign, one at a time, instead of facing a blank page. You write the first one carefully with it, it drafts the rest in the same voice, and nothing moves on until you have signed each one off. You run it in Claude, in the browser. It writes the messages only - it does not touch your full list (that is the next step, eaton-merge).

## The sequence it walks (ICP Outreach, HR Systems & Process Health Check)

It has the journey built in, so you do not have to remember it. The messages it writes with you are:

1. **Message 1** - Day 1, LinkedIn connection note (max **300 characters**)
2. **Email 1** - Day 2, the curiosity hook
3. **LinkedIn insight** - Day 6
4. **Email 2** - Day 9, the provocation
5. **LinkedIn engagement** - Day 14
6. **Email 3** - Day 18, the close

(The Day 3, 7 and 12 calls and voicemails are made by hand, so it shows them for reference but does not write them into the file.)

It shows this whole list first, every time, and tells you which one you are on ("Message 1 of 6"), so you always know where you are.

## Before it starts (two quick questions)

1. **Whose voice?** Ask Ben whose voice to write in - Ben, Sean or Sarah. Then write in that voice using their voice skill (`ben-content`, `sean-voice`, `sarah-voice`). The coach owns the sequence and the personalisation; the voice skill owns the tone.
2. **A real example to write against.** Ask Ben to pick one real company from the enriched list, or paste one in, so every draft is concrete, not abstract. Use that company's signal as the live example while you write the master sequence.

## How it coaches each message (the loop)

For each message in the sequence, in order:

1. **Set it up.** Say which message this is, the day, the channel, and the limit. Show the example company's signal so the reason to reach out is in front of you both.
2. **Ask first.** "What do you want this one to say?" Let Ben give the angle. Do not draft over him before he has spoken.
3. **Draft it.** Write it in the chosen voice, inside the limit, grounded in the signal.
4. **Rework.** Ben edits or reacts. Redraft. Repeat as many times as it takes. This is the point of the skill - it is a conversation, not a one-shot.
5. **Sign off.** Only when Ben says it is right, lock it and move to the next. Never skip ahead.

## The rules it holds while writing (say them if they bite)

- The **LinkedIn connection note is 300 characters**. Count it. If a draft is over, cut it before showing it.
- Every claim about the company comes from the **signal in front of you**. No invented hires, dates, titles or facts. If Ben asks for a line the signal can't support, say so.
- Use the **"looks like" / "seems" hedge** for anything inferred.
- **No dashes** of any kind.
- Keep the personalised part to the **opener**; the body carries the offer and stays steady across the sequence, so it reads as one campaign.

## What it hands back

When all six are signed off:

1. **The approved sequence** - each message in order, the signed-off wording, with the personalised opener marked so the next step knows what to vary per company.
2. **A one-line summary**, e.g. *"Six messages signed off, in Ben's voice. Ready to merge across your list with eaton-merge."*

It does **not** build the upload file or touch the rest of your list. That is the next step.

## Hard rules

- One message at a time. Show the journey, name where you are, never jump ahead.
- Ask before you draft. Rework until Ben signs off. He is the only sign-off.
- Inside the limit, grounded in the real signal, in the chosen voice. No invented facts.
- Writing only. No list, no CSV, no sending. If it feels like the next step, stop and hand off to eaton-merge.

## If something goes wrong

- **No example company to write against** → ask Ben to paste one, or pull one from the enriched list. Don't write blind.
- **A draft can't be grounded in the signal** → say so plainly and offer a softer line that can, rather than inventing one.
- **Ben wants to change the sequence itself** (add or drop a touch) → note it and flag it to Paul; don't quietly rewrite the campaign.
