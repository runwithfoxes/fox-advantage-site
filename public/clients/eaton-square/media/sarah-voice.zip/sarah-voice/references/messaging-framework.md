# Eaton Square Messaging Framework (Sarah's Track)

## One-line value proposition

**General change and communications:**
The consulting partner that connects you directly with senior, experienced change and communications specialists who cut through complexity to deliver change that lasts.

**Technology implementation (specific):**
The consulting partner that makes HR technology actually work, from selection through adoption, so your people strategy delivers, not just your platform.

## Category

HR people consulting: technology implementation, general change implementation, people strategy, change adoption.

## Target audience

HR Directors and CPOs at mid-market and enterprise organisations (500-5,000 employees) responsible for driving enterprise-wide change. This change could result from post org-design change, embedding a new strategy, post M&A activity, implementation of a new technology, etc.

## What makes us different

Traditional consulting can feel distant: armies of juniors, long reports, endless PowerPoints, but not much real change. At Eaton Square (an HR Path company), you work directly with experienced advisors who stay involved from first discussion to final delivery, close to the detail, never dogmatic or detached. Our people know what it takes to make change happen, and to keep organisations moving forward.

## Four messaging pillars

### Pillar 1: Implementation that sticks
Most HR tech implementations fail not because of the technology, but because nobody planned for adoption. We build change management into the project from day one.

**Proof:** 12 years of Dayforce, Workday, UKG implementations across Ireland and UK. Post-go-live adoption rates. Client examples where previous implementations failed before Eaton rebuilt them.

### Pillar 2: The mid-market sweet spot
You're too big for a freelancer, too practical for a Big 4 engagement. You need a partner who knows your scale and won't over-engineer the solution.

**Proof:** 150 consultants. Named project leads, not rotating graduates. Client portfolio of mid-market organisations who chose Eaton over bigger firms and got better outcomes.

### Pillar 3: Global reach, local knowledge
Irish roots, international capability. Part of HR Path's 28-country network since 2025, so your multi-country rollout doesn't need five different partners.

**Proof:** Offices in Dublin, Cork, Limerick, UK. HR Path brings 2,500 consultants across 28 countries.

### Pillar 4: People strategy, not just platforms
Technology is the easy part. The hard part is getting your organisation to change how it works. That's where most investments fail, and where we start.

**Proof:** Business consulting and people consulting divisions working alongside technology. Organisational design, change management, and leadership development integrated into every implementation.

## Competitive contrast

- Big 4 firms configure the system and hand you a manual. Boutiques lack the scale for enterprise rollouts. Eaton Square stays through adoption.
- Big 4 sell methodology and brand. They staff with juniors and rotate them. Eaton's team knows your platform and stays on your project.
- Local boutiques can't scale internationally. Global firms don't understand the local market. Eaton Square bridges both.

## Positioning statement

For HR leaders choosing an implementation partner for their next platform investment, Eaton Square is the mid-market alternative to Big 4 consulting, combining deep platform expertise with hands-on change management, so your technology investment translates into people outcomes, not just a configured system.

## Voice summary

Knowledgeable peer, not corporate consultancy. Direct, practical, confident without being arrogant. The tone of someone who's done this dozens of times and knows where the problems actually are.

## Writing principles

- Practical over theoretical
- Evidence over claims
- Client outcomes over firm credentials
- Straightforward language, no consulting jargon
- Show the work, not the methodology diagram

## Never use

Buzzwords: synergy, leverage, holistic, ecosystem, disrupt. Jargon without explanation. Overpromising timelines. Talking about technology without mentioning people.

## Never do

Lead with methodology over outcomes. Hide behind the HR Path brand instead of earning trust as Eaton. Promise transformation without specifics.

## Tone guidance on competitors

Position strongly but do not take shots at Big 4 firms. Sarah was explicit: entirely positive about what is helpful for Eaton. No negative space. Sarah's background is big consulting (WTW/BDO). David O'Connor (partner) also cautious about this.

## Brand transition

Eaton Square is being absorbed into HR Path branding mid-2026. Currently "Eaton Square, an HR Path Company." Materials need to accommodate this transition.
