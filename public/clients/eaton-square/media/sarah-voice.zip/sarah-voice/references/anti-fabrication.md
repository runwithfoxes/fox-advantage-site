# Anti-Fabrication Rules

Never invent content to fill a gap. If you don't have it, say so.

---

## Absolute prohibitions

- Never fabricate statistics or data points
- Never invent client names, company names, or testimonials
- Never create industry statistics ("73% of HR leaders...")
- Never invent timeframes ("within 30 days," "most clients see results in...")
- Never assume performance metrics not explicitly provided
- Never make up event details, speaker names, or panel topics
- Never attribute quotes to people who didn't say them

## Before using any claim, ask

1. Did the user provide this exact fact?
2. Is this number in the source materials (messaging framework, approved copy, LinkedIn data)?
3. Can I point to where this came from?
4. Am I inventing this to make the copy sound better?

If 1-3 are NO, or 4 is YES - you cannot use the claim.

## What to do instead

- Use Eaton's verified facts: 12 years, 150 consultants, Ireland/UK, HR Path's 28 countries and 2,500 consultants, Dayforce/Workday/UKG/HiBob partnerships
- Use Sarah's real experience: 20+ years in change and communications, WTW, BDO, Harvard Business School
- Use the messaging framework pillars - they are approved positioning, not invented claims
- Use [placeholder] brackets for anything the writer would need to fill in: [client name], [specific result], [event date]
- If a post needs a case study or metric you don't have, say: "This post needs a real client example - placeholder used"

## Verified facts available

These are confirmed in source materials and can be used freely:

**Eaton Square:**
- Founded 2012, based Dublin/Limerick/Cork + UK
- 150 consultants
- 12+ years of implementation experience
- Acquired by HR Path (Paris) April 2025
- Implementation partners: Dayforce, Workday, UKG, HiBob, Sage

**HR Path:**
- 2,500 consultants across 28 countries
- Headquartered in Paris

**Sarah McDonough:**
- Director of Business and People Consulting at Eaton Square
- 20+ years leading change and communications programmes
- Previously at WTW (led UK & Ireland Employee Experience team) and BDO
- Harvard Business School attendee (January 2026)
- Regular speaker/panellist at HR Directors Dinners, CIPD, REBA conferences

**Approved positioning lines (from approved copy):**
- "We don't hand you a strategy and walk away"
- "The people you meet at the pitch are the people who work with you"
- "Technology is the easy part. Getting people to change is hard"
- "Traditional consulting can feel distant: armies of juniors, long reports, endless PowerPoints, but not much real change"
