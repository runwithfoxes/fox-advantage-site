# AI Slop Detection Guide

Words, phrases, formatting patterns, and structural tells that signal AI-generated content. Use this to audit all Moloco marketing copy.

---

## Words and phrases to avoid (100+)

### Extreme overuse (10x+ more frequent in AI text)

| Avoid | Use instead |
|-------|-------------|
| Delve into | Explore, examine, look at |
| Harness the power | Use, apply, take advantage of |
| Unlock potential | Enable, help achieve |
| At its core | Essentially, basically |
| Leverage | Use, apply, build on |
| Seamless / seamlessly | Smooth, easy, works well with |
| Revolutionary | New, different, advanced |
| Game-changing | Important, significant |
| Cutting-edge | Advanced, modern, latest |
| Unprecedented | Unique, first-of-its-kind |
| In today's fast-paced world | (Delete. Start with your actual point.) |
| In the ever-evolving landscape | (Delete. Start with your actual point.) |
| It is important to note that | (Delete. Just state the point.) |
| In order to | To |
| Captivate | Engage, interest |
| Elevate | Improve, raise, strengthen |
| Empower | Give, enable, help |
| Transformative | Effective, significant |
| Dynamic | Active, changing, flexible |
| Holistic | Comprehensive, complete, full |
| Tapestry | (Don't use in business writing) |
| Realm | Area, field, space |
| Symphony | (Don't use in business writing) |
| Alchemy | (Don't use in business writing) |
| Odyssey | (Don't use in business writing) |

### High overuse (5-10x more frequent in AI text)

| Avoid | Use instead |
|-------|-------------|
| Underscore | Highlight, emphasize, show |
| Pivotal | Important, crucial, key |
| Navigate | Handle, manage, deal with |
| Illuminate | Explain, clarify, reveal |
| Facilitate | Help, enable, make easier |
| Optimize | Improve, enhance, make better |
| Comprehensive | Complete, full, thorough |
| Robust | Strong, solid, reliable |
| Streamline | Simplify, make efficient |
| Resonate | Connect, land, click with |

### Transition phrase red flags

| Avoid | Use instead |
|-------|-------------|
| Moreover / Furthermore | Also, plus, and |
| That being said | However, but, still |
| It's worth noting | (Delete. Just note it.) |
| In light of this | Because of this, so |
| At the end of the day | Ultimately, in the end |
| Moving forward | Next, from now on, going ahead |
| By the same token | Similarly, likewise |
| To put it simply | Simply put, in short |
| From a broader perspective | Overall, big picture |
| In conclusion | Finally, to sum up, (or just conclude) |
| Firstly / Secondly / Thirdly | First / Second / Third (or drop them) |
| Without further ado | (Delete entirely) |

### Business buzzwords that destroy credibility

| Avoid | Use instead |
|-------|-------------|
| Synergy | Collaboration, working together, combined |
| Paradigm shift | A change in approach, a new model |
| Disruptive | (Show why it's new instead of labeling it) |
| Best-in-class | (Provide proof or omit) |
| Thought leader | (Demonstrate it, don't declare it) |
| Growth hacking | Fast growth strategies |
| Low-hanging fruit | Quick wins, easy opportunities |
| Guru / Ninja / Rockstar | Expert, specialist |
| Move the needle | Make a measurable impact |
| Circle back | Follow up |
| Touch base | Connect, reach out |
| Bandwidth (for capacity) | Capacity, time, ability |
| Secret sauce | Unique advantage, differentiator |
| Future-proof | Prepare for, built to last |
| Scalable solution | (Specify how it scales or omit) |
| Value proposition | Value, benefit, what you get |
| Ecosystem (vague use) | Network, environment, market |
| Solutioning | Problem solving, developing solutions |
| Think outside the box | Think creatively |
| Hit the ground running | Start quickly |
| Take it to the next level | Improve further, step up |
| Now more than ever | (Specify why now or delete) |
| For all your needs | (Be specific about which needs) |

### AI opener cliches (never use these to start copy)

- "In today's fast-paced digital world..."
- "In the ever-evolving landscape of..."
- "In a world where..."
- "It could be argued that..."
- "Some experts say..." (name them or don't cite them)
- "Have you ever wondered..."
- "Let's face it..."
- "The fact of the matter is..."

### AI closer cliches (never use these to end copy)

- "Remember: [platitude]"
- "In conclusion..."
- "At the end of the day..."
- "The future belongs to those who..."
- "The question isn't whether X will happen, but when."
- "Thoughts?"
- "Agree?"

---

## Punctuation and formatting tells

### Always flag

- **Em dashes ( - ):** AI uses them 3-5x more than humans. Zero tolerance in Moloco copy. Use periods, commas, parentheses, colons, or rewrite.
- **Excessive colons and semicolons:** Break up complex sentences instead.
- **Bullet point overload:** Only use lists when truly appropriate (3+ related items). Each bullet must have substance.
- **Title Case In Headlines:** Use sentence case. Title Case signals engagement bait.
- **Emojis as formatting:** No emojis at sentence beginnings (especially not rocket, brain, lightbulb, lightning).
- **Excessive bold:** Don't bold every other sentence. Use sparingly for one key phrase.
- **Quotation marks for "emphasis":** Use italics instead, or choose a more precise word.
- **Single-sentence paragraphs as default:** Mix paragraph lengths naturally. One-liners for genuine emphasis only.

---

## Structural patterns to eliminate

- **Uniform paragraph length:** Vary between 1-5 sentences. Don't make every paragraph the same size.
- **Identical article structure:** Don't use the same intro-list-conclusion template for everything.
- **First / Second / Finally enumeration:** Don't start every paragraph with a numbered transition.
- **Rigid hook-points-CTA formula:** Especially on LinkedIn. Vary post structure.
- **Predictable topic progression:** "What is X? Why is X important? How to do X?" every time signals template writing.
- **Repetitive sentence structures:** "X is important because Y. Z is critical because W." Mix short, long, simple, complex.
- **No narrative flow:** Content reads as a checklist of points rather than a cohesive argument.

---

## Tone and voice tells

- **Overly neutral:** No strong opinion or angle. Hedges everything. "There are merits on both sides."
- **Excessive hedging:** "It appears that..." "In many cases..." "Some might say..." repeatedly.
- **Fake enthusiasm:** "Amazing results!" "Absolutely revolutionary!" without evidence.
- **Generic empathy:** "We understand your challenges" without specifics.
- **Corporate-speak:** Passive voice, jargon, self-important phrasing.
- **No emotional resonance:** Discussing customer pain points in a detached way.
- **Forced conversational tics:** "Why, you ask? Well, let me tell you..." or "Guess what?"

---

## LinkedIn engagement bait (avoid all)

- Hook formulas: "I've been thinking about X lately..." / "Unpopular opinion:" / "Here's what nobody talks about"
- Fake vulnerability: "I'll be honest..." / "I learned this the hard way" (without real specifics)
- One-sentence paragraphs as default structure
- Emoji openers on every line
- "Agree?" or "Thoughts?" endings
- "Comment YES if..." engagement fishing
- Manufactured controversy for hot takes without substance
- Performative storytelling with tidy morals

---

## Quick audit checklist

**30-second visual scan:**
- [ ] Uniform paragraph lengths?
- [ ] Excessive bullet points?
- [ ] Em dashes?
- [ ] Generic opening/closing?
- [ ] Title Case in headlines?

**2-minute phrase search:**
- [ ] Search for "delve," "leverage," "moreover," "furthermore"
- [ ] Search for "it is important to note," "in today's"
- [ ] Count em dashes (target: zero)
- [ ] Check transition patterns

**5-minute authenticity test:**
- [ ] Specific examples present?
- [ ] Claims backed by sources or flagged?
- [ ] Natural language variation?
- [ ] Does this sound like it was written by a specific person with knowledge, or could anyone have written it?
