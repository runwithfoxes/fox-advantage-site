# Email Frameworks for Outreach

Proven B2B email structures adapted for Eaton Square's outreach. Sarah's voice rules still apply - warm, relational, names people, no hard sell. These frameworks provide structure, not permission to sound like a sales machine.

---

## Core frameworks

### PAS (Problem - Agitate - Solution)
Best for: Cold outreach, first-touch emails

- **Problem:** State a specific pain point with authority
- **Agitate:** Show the cost or consequence, shared experience
- **Solution:** Present clear resolution with a soft next step

Example structure for Eaton:
> **P:** "Most HR technology implementations are planned around the platform, not the people who have to use it."
> **A:** "Six months after go-live, adoption is low, teams are frustrated, and the investment hasn't delivered what the board expected."
> **S:** "At Eaton Square, we build change management and communications into the project from day one. Happy to share how we approach it if that's useful."

### BAB (Before - After - Bridge)
Best for: Follow-up emails, warm leads

- **Before:** Current frustrating state with specific details
- **After:** Desired future state with tangible benefits
- **Bridge:** How to get from one to the other

### AIDA (Attention - Interest - Desire - Action)
Best for: Event invitations, content promotion

- **Attention:** Bold insight or surprising observation
- **Interest:** Why this matters now
- **Desire:** Specific benefit
- **Action:** Clear, low-friction next step

---

## Subject line principles

Sarah's outreach is networking, not hard sell. Subject lines should feel like a peer reaching out, not a vendor pitching.

**Works for Sarah's voice:**
- Quick question about [specific thing they're working on]
- [Mutual connection] suggested I reach out
- Following up from [event/forum]
- Thought this might be useful - [specific topic]
- [Their company] + [specific challenge you can help with]

**Never use:**
- RE: or FWD: on first-touch emails (deceptive)
- Fake urgency ("urgent update," "last chance")
- Clickbait ("You won't believe...")
- Generic pitches ("Unlocking HR transformation")

**Rules:**
- Under 45 characters for mobile
- Lowercase is fine if it matches the tone
- No emojis in subject lines for B2B HR outreach

---

## Opening lines

Sarah opens with what happened or what she noticed, not with a pitch.

**Works:**
- "I noticed you recently joined [company] as [role] - congratulations."
- "I saw your post about [specific topic] and it really resonated with some of the work we're doing at Eaton Square."
- "[Mutual connection] mentioned you're looking at [specific challenge]."
- "We're hosting a small HR leaders forum in Dublin on [topic] and I thought you might find it valuable."

**Never:**
- "I hope this email finds you well" (AI filler)
- "I'm reaching out because..." (skip the preamble, just reach out)
- "I'd love to set up a quick call to discuss how we can help" (banned phrase from Sarah's voice rules)

---

## CTA patterns

Sarah's calls to action direct to a named person and feel like an invitation, not a conversion funnel.

**Works for Sarah:**
- "Happy to share more if that would be useful - just reply to this email."
- "If you'd like to join, reach out to Ben King directly."
- "No pitch - I just thought it might be relevant given what you're working on."
- "Would it be useful to have a quick conversation about this? No pressure either way."

**Never:**
- "Book a 15-minute call here: [calendly link]" (too transactional for Sarah's voice)
- "Download our whitepaper" (not how Eaton operates yet)
- "Let me know if Tuesday at 3pm works" (too presumptuous for first touch)

---

## Sequence structure (for Smartlead)

Eaton's email sequences should follow the same principle as Sarah's LinkedIn: networking first, value second, ask third.

**Email 1 (Day 0):** Introduction + one specific observation about them + soft offer
**Email 2 (Day 3-4):** Share something useful (article, insight, forum invitation) + no ask
**Email 3 (Day 7-8):** Light follow-up referencing Email 1 + one question
**Email 4 (Day 14):** Final touch + graceful close ("Completely understand if the timing isn't right")

**Rules:**
- Maximum 4 emails in a cold sequence
- Each email must stand alone (don't assume they read the previous ones)
- Every email must offer something, not just ask for something
- Unsubscribe/opt-out must be available
- Ireland contacts: LinkedIn only, no cold email (legal requirement)

---

## Formatting rules

- Plain text preferred over HTML for cold outreach (higher deliverability, feels personal)
- Short paragraphs (1-3 sentences max)
- No bullet points in first-touch emails (feels templated)
- One CTA per email, never more
- Sign off as Sarah, not as "The Eaton Square Team"
- Include role and company in signature, not a full marketing footer

---

## Anti-fabrication reminder

All claims in emails must come from verified source materials. Never invent:
- Client results or case study details
- Statistics about the industry
- Quotes from people
- Event details that haven't been confirmed

Use [placeholder] brackets for anything that needs to be filled in with real data.
