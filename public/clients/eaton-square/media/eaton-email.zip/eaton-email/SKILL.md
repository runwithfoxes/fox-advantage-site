---
name: eaton-email
description: "Find verified work email addresses for the contacts you just enriched. Use when Ben says 'get emails', 'find their emails', 'add emails', or runs the email step after eaton-enrich. Fills the blank Email column on the enriched list. NOT for finding the HR contact or writing messages (that is eaton-enrich) and NOT for sending (that is the load/send step)."
---

# Eaton Email

This skill adds **verified work email addresses** to the list you just built with `eaton-enrich`. It uses your Clay connection - the same one - and nothing else.

It never makes an email up. If Clay can't find a real, verified address for someone, that person goes on a **"No email - don't add"** list and you move on. A guessed email (firstname.lastname@company.com) bounces and burns the domain, so we never do it.

## Run it in the SAME chat, right after eaton-enrich

Emails attach to the **same Clay search** the enrich step already ran. So the cheapest, cleanest way is:

> Run `eaton-enrich` → when its table is ready, in the **same chat** say "now get the emails".

That reuses the existing search, so you don't pay to find the people twice.

**If the search isn't there any more** (you started a new chat, or Clay was restarted): the skill will say so and re-find the contacts first. That costs a little more, but it's honest about it rather than failing silently.

## Before it spends anything

1. **Credits** - checks Clay credits (`hasPlatformCredits` or `hasSalesRepCredits` true = go; ignore `hasWorkspaceCredits: false`).
2. **Which engine is available** - it checks `list_subroutines` for a published email/waterfall function (see the setup guide):
   - **If the waterfall subroutine is published** → it uses that on the existing search. This is the good one (~9 in 10).
   - **If not** → it falls back to Clay's plain `Email` data point. **Warn Ben plainly** that the plain finder is weaker and many rows may come back empty - the waterfall subroutine is what gets the hit-rate up.

## How it gets the emails

- **Best path (subroutine):** `run_subroutine` with the published email function's id, the enrich step's `taskId`, and a field mapping (e.g. `{ "name": "full_name", "domain": "company_domain" }`).
- **Fallback path (plain datapoint):** `add-contact-data-points` with `{ type: "Email" }` on the same `taskId`.

Then **always read the result with `get-task-context`** using that taskId. Do NOT say an email "wasn't found" until you've called `get-task-context` - the first response only carries base fields; the enriched email lands in the task context.

Work through the list in chunks of ~10 and show progress. One step at a time, visible.

## The loud check (every email, no exceptions)

For each address that comes back:

- [ ] It's a **real, complete email** (has a name part, an @, a real domain) - not blank, not "None Found".
- [ ] The **domain matches the company** (or a sensible parent). A gmail/outlook/personal domain on a corporate contact → flag "personal address - check".
- [ ] It's **not a generic inbox** (info@, hr@, careers@, hello@). Those go on the review list as "generic inbox - not a person".
- [ ] Clay marks it **found/verified**, not guessed or "pattern".

**Pass all four → fill the Email column. Any fail, or no address → "No email - don't add" with the reason.** Never write a guessed or pattern address. Ever.

## What it hands back

1. **The same list, with Email now filled** where it passed - ready for the load step.
2. **"No email - don't add"** - the contacts with no verified address, and why (no result / generic inbox / personal domain / wrong company).
3. **The CSV block again**, now with the Email column populated for the verified rows.
4. **A plain summary with the real hit-rate**, e.g. *"Got verified emails for 31 of 40 (78%). 9 had none - listed below. The LinkedIn legs still work for those; the email legs won't."*

That last line matters: a contact with no email can still run the **LinkedIn** part of the sequence - they just skip the email steps. Don't drop them, just note them.

## Hard rules

- Never invent, guess, or pattern-build an email. No address unless Clay actually returned a verified one.
- Always read results with `get-task-context` before saying anything is missing.
- Report the true hit-rate every time. If it's low, say so plainly - that usually means the waterfall subroutine isn't published yet, not that the people have no emails.
- Generic inboxes and personal-domain addresses are flagged for review, never silently used.
- This skill only uses the Clay connection. No scripts, no downloads, no sending.

## If something goes wrong

- **Clay tools silent** → start a fresh chat. But remember: a fresh chat loses the enrich search, so re-run `eaton-enrich` there first, then the emails.
- **Everything comes back empty** → the waterfall subroutine probably isn't published (or its field mapping is off). Tell Paul; don't keep spending credits on a path that's returning nothing.
- **`list_subroutines` is empty** → only the weak plain finder is available. Warn Ben, and flag to Paul that the waterfall subroutine still needs publishing.
