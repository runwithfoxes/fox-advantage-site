# Research protocol - how to find this week's material

You are doing the finding so Sarah does not have to. Run this protocol with Claude's web search every time the skill runs. Fresh each week.

## The golden rule: sourced or it does not ship

Every hook you put in front of Sarah must come from a page your web search actually returned **this run**. If you cannot attach a real, working URL to a hook, it does not go in the list. Never guess, never reconstruct from memory, never invent a competitor quote, a stat, or a report. When in doubt, drop it.

## The lanes (search across all three)

Run several searches. Spread them across these lanes so the ten ideas are not all from one place. Vary the wording run to run so you do not surface the same pages every week.

**Lane 1 - Competitor watchlist (what the firms in her space are saying now)**
Search the change / transformation / PMO / programme-recovery content of:
- Deloitte ("human-centric change", change management)
- PwC and PwC Ireland ("NextGen change", programme recovery, "PMO not fit for purpose")
- KPMG UK ("Make It") and KPMG Ireland (Independent Programme Assurance)
- Berkeley Partnership (Programme Recovery - her closest boutique competitor)
Example queries: `PwC Ireland programme recovery 2026`, `Deloitte change management adoption`, `KPMG independent programme assurance`, `Berkeley Partnership programme recovery`.

**Lane 2 - The category (the wider conversation)**
Change management, change readiness, adoption, internal comms during transformation, programme governance, project/programme recovery, spec-and-select / vendor-independent system selection, AI and change management.
Example queries: `change management adoption statistics 2026`, `programme governance failure rate`, `AI adoption change management 2026`, `HR transformation Ireland 2026`.

**Lane 3 - News hooks (something current she can react to)**
Recent, datable events she could take a point of view on: big organisational transformations, restructures, regulation affecting HR/operations, market moves. Bias toward Ireland and the UK.
Example queries: `Irish company transformation restructure 2026`, `UK HR transformation news 2026`.

## Reading what comes back

- Keep hooks that are **real, recent, and on one of her two themes** (see themes-and-territory.md). Discard thin, undated, or off-lane results.
- For each kept hook, capture: the **claim as the source actually states it**, the **publisher name**, and the **URL**.
- Do not inflate. If a source "mentions adoption as a risk", that is what it says - not "the industry now agrees adoption is the number one risk".
- Prefer primary sources (the firm's own page, a named report) over aggregators.

## Weighting and spread (before you pitch)

- Map every candidate angle to **Theme 1 (change & comms)** or **Theme 2 (programme/PMO/governance)**.
- Hold the **60 - 70% change / 30 - 40% programme** weighting across the ten. If you have too many programme ideas, cut some and search Lane 2 harder for change angles (her heartland is less crowded there).
- No two ideas should be the same angle. Spread across angle types from themes-and-territory.md.
- Never frame a competitor hook as a dig. State Sarah's view as a positive belief (voice rule).

## Self-check pass (run before showing Sarah anything)

For each of the ten:
1. Is the "why now" hook backed by a URL I actually pulled this run? If not, replace it or drop the idea.
2. Is the claim stated no stronger than the source states it?
3. Is it on one of her two themes, and does the set hold the 60/40 weighting?
4. Is the source named and the link present and clickable?

If any idea fails, fix it before showing the list.

## The deep-research prompt (attach one to every idea)

Each idea gets a ready-to-paste prompt for Claude's Research mode. Build it from this template, filled for that specific angle:

> "Investigate [the specific angle]. Find how the Big 4 (Deloitte, PwC, KPMG) and boutiques like Berkeley Partnership currently frame [topic] in Ireland and the UK in 2026. Surface named frameworks, recent client-facing claims, and any statistics on [the relevant outcome, e.g. programme failure, adoption rates]. Return sourced, linked findings I can quote, and note anything that contradicts the common 'people-first' positioning."

Keep it one short paragraph, specific to the idea, and always ending with the instruction to return **sourced, linked** findings.
