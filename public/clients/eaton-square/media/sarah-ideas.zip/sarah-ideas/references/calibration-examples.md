# Calibration examples (taste and boundaries)

These are the first 15 drafts with Sarah's own verdicts from her 4 June review. **They are NOT a menu to output** - they exist so you learn what she likes, what she rejects, and why. Write fresh posts; use these to stay inside her taste.

## What she liked overall

"I really like how the content's been written. It's accessible, not jargon, and it stands out relative to the Big 4." "It does feel like it's been written by me, and by humans." "It's very humble, and that's tonally right - we don't want to be big and bold. It's a perspective and shared experience." So the voice is right. The fixes are structural, thematic, and a few word-level bans.

## Per-post verdicts

| # | Draft | Verdict + why |
|---|-------|---------------|
| 1 | Governance gets a bad name | **Revise.** Loves the hook ("makes people's shoulders drop"). But governance must be framed as part of programme/project management, with context up front so readers don't wonder why she (change/EX) is talking about it. Not a #ChangeManagement post. |
| 2 | The outsider who's seen it all | **Keep.** The differentiator. On board. |
| 3 | Not just a PM, deliver the outcome | **Keep - strong.** "Really like that - we're getting the programme delivered, it's the outcomes." Programme mgmt theme. |
| 4 | Most projects aren't projects | **Revise.** Kill "most". "Definition of done" felt clunky → "completion/finished". Keep the personable "here's something I see often" lead-in (she likes it). |
| 5 | Few leaders have a true picture | **Revise.** "Few leaders…" is borderline patronising. Sharpen the close to offer the **programme diagnostic** specifically, not a chat. |
| 6 | 5 quiet signs | **Revise.** Kill "quiet". Kill "most"/"don't fail suddenly" → "often projects…". Tangible close ("we can show you where we've supported others"). |
| 7 | Course-correct mid-flight | **Keep - strengthen.** She loves it; has a real recent client (called out hard truths, reset vendors, delayed for the right reasons). Add as anonymised proof. |
| 8 | Transformations fail before delivery | **Revise.** De-system-ify - applies to process/org change too, not just systems. "Solution" not "system". Strip "most"/"quite". |
| 9 | Spec & select | **Keep - adopt her term "spec and select".** Real strength: vendor-independent across Workday/Dayforce/Oracle. Video candidate. |
| 10 | Run a competition | **Merge into 9** - she sees them "running together". |
| 11 | As-is leadership vs ground | **Drop.** Patronising AND outside her lane ("we won't have that operational depth"). |
| 12 | Technology is the easy part | **Keep - heartland.** Soften "easy" → "more straightforward". Sharpen the close to change-mgmt/comms/adoption. |
| 13 | Briefing note afterthought | **Rewrite.** Her thinking evolved: not "tell staff late" but **change management starts before the project does** - change readiness, surfacing resistance early, bringing people along so change doesn't happen *to* them. |
| 14 | Event anchor | Keep as-is. |
| 15 | Team reflection | Keep - she writes these herself. |

## Before → after (shows the fixes applied)

### Post 6 close - weak vs fixed
**Before:** "Most projects don't fail suddenly. They drift, quietly… If a project of yours is showing a few of these, I'm happy to share how we'd approach it."
**After:** "Projects rarely fail suddenly. They drift, and the signs are usually there well before anyone says it out loud… If a project of yours is showing a few of these, it's worth a conversation - we can show you where we've helped others get back on track."
*(Fixes: killed "most" and "quietly"; close is now tangible with proof, not a chat.)*

### Post 1 opening - flat vs contextualised
**Before:** opens straight into governance as a change-management topic.
**After:** "Governance is one of those words that makes people's shoulders drop. It sounds like more meetings, more forms. But governance is a core part of great programme and project management - and done well, it's the thing that frees a project up, not the thing that slows it down."
*(Fix: keeps the hook, then sets context so the reader knows why she's talking about it, and nests it in programme management, not change.)*

### Post 13 - out of date vs evolved
**Before:** "The staff briefing note is always an afterthought" (her 15-year-old article angle, brand/marketing comms).
**After (direction):** change management has to start before the project does - understand where people are, surface resistance and barriers before they block delivery, bring people on the journey so the change doesn't simply happen to them. Engagement early, not training bolted on at the end.

## The recurring lesson

Almost every "revise" was the same two things: **a banned word** (most / quiet) or **a close that was too soft** ("happy to talk it through" → make it tangible). Fix those by default in everything you write.
