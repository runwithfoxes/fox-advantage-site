# Eaton Square Messaging Framework (Sarah's track)

## One-line value proposition

**General change and communications:** The consulting partner that connects you directly with senior, experienced change and communications specialists who cut through complexity to deliver change that lasts.

**Technology implementation (specific):** The consulting partner that makes HR technology actually work, from selection through adoption, so your people strategy delivers, not just your platform.

## Category

HR people consulting: technology implementation, general change implementation, people strategy, change adoption. (For Sarah's content, lead with the change & communications side - see themes-and-territory.md weighting.)

## Target audience

HR Directors and CPOs at mid-market and enterprise organisations (500 - 5,000 employees) responsible for driving enterprise-wide change. The change could result from org-design change, embedding a new strategy, post-M&A activity, or implementing new technology.

## What makes us different

Traditional consulting can feel distant: armies of juniors, long reports, endless PowerPoints, but not much real change. At Eaton Square (an HR Path company), you work directly with experienced advisors who stay involved from first discussion to final delivery, close to the detail, never dogmatic or detached. Our people know what it takes to make change happen, and to keep organisations moving forward.

## Four pillars

1. **Implementation that sticks** - most HR tech fails not on the technology but because nobody planned for adoption. We build change management in from day one.
2. **The mid-market sweet spot** - too big for a freelancer, too practical for a Big 4 engagement. A partner who knows your scale and won't over-engineer.
3. **Global reach, local knowledge** - Irish roots, HR Path's 28-country network, so a multi-country rollout doesn't need five partners.
4. **People strategy, not just platforms** - technology is the more straightforward part; getting the organisation to change how it works is the hard part, and where we start.

## Voice summary

Knowledgeable peer, not corporate consultancy. Direct, practical, confident without being arrogant. Someone who's done this many times and knows where the problems actually are.

## Writing principles

Practical over theoretical. Evidence over claims. Client outcomes over firm credentials. Straightforward language, no jargon. Show the work, not the methodology diagram.

## Tone on competitors

Position strongly but never take shots at the Big 4. Entirely positive about what's helpful for Eaton. Sarah's background is big consulting (WTW/BDO); David O'Connor is cautious here too.

## Brand transition

Currently "Eaton Square, an HR Path company." Being absorbed into HR Path branding through mid-2026.
