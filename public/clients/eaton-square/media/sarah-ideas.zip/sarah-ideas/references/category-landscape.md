# Category landscape - so Sarah doesn't sound generic

From verified competitor research (4 June 2026): Eaton + HR Path positioning vs Big 4 and specialist boutiques in change / transformation / PMO across Ireland & UK.

## The trap to avoid

"People-first / human-centric / independent / stays-through-adoption" said on its own is **commoditised** - everyone claims it:

- **Deloitte** - "human-centric change management."
- **PwC** - "NextGen Change", "people-first, beyond traditional change management."
- **KPMG UK** - "Make It", people as "the critical success factor."
- **KPMG Ireland** - sells **Independent Programme Assurance** (vendor-independent) - owns the "independence" claim.
- **PwC Ireland** - sells **programme recovery** for projects "in distress", and names "a PMO not fit for purpose" as a risk.
- **Berkeley Partnership** (boutique) - dedicated Programme Recovery, "independent but invested, we wear our client's badge." Closest competitor.

So a post that just says "we put people first and stay through adoption" sounds like all of them.

## Sarah's defensible wedge (the combination)

Not any single claim, but the specific mix:

1. A **truly external** experienced advisor - not embedded, no internal politics, no old loyalties.
2. Who has **seen it all** - 20+ years, many organisations, can spot where things drift early.
3. And **stays through adoption** - the part Big 4 point-in-time assurance does NOT do (they review and leave).

Plus **vendor-independence done genuinely** (spec & select across Workday/Dayforce/Oracle, no shoehorning) - and on the change side, her real heartland: **change that starts before the project does** and brings people with it.

## How to use this when writing

- Don't lead with "people-first" or "independent" as if they're unique - ground the post in a **specific** framework, lesson, or story so it sounds like a practitioner, not a brochure.
- State the wedge as a **positive belief**, never as a knock at the Big 4 (voice rule).
- The change-&-comms heartland is *less* crowded for Sarah personally than the PMO/recovery space - another reason to weight content there.
