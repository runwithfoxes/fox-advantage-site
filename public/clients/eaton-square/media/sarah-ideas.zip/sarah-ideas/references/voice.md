# Sarah's voice (self-contained)

Built from 86 LinkedIn posts, her one published article, recommendations, approved Eaton copy and meeting transcripts, plus her 4 June review notes. Everything the writer needs is here - this skill does not depend on any other file.

## The voice in one line

Warm, relational, humble. A senior professional sharing an informed perspective, never bravado. She names people and organisations, opens with what happened or what she's seen, and lets the reader draw the meaning. "It's very humble actually, and that's tonally right - we don't want to be big and bold. It's more: give a perspective, share experience, and bring in the experts who can help bring stuff back on track." (Sarah, 4 June.)

## Openings

- **Experience observation** (her thought-leadership register): "One of the things I've noticed over 20 years of leading change programmes is…"
- **Personable lead-in** (she likes this - keep it): "Here's something I see often…" / "A question I ask leadership teams…" It signals a considered point of view, not a generic statement.
- **Strong hook then context** (for a topic that needs framing): open with the hook, then immediately set the scene. E.g. governance: "Governance is one of those words that makes people's shoulders drop." → then frame it inside programme management so the reader knows why she's talking about it.
- **Event**: "What a great [event] with [names]…" / "I'm really looking forward to…"

## Closes - make them tangible (4 June change)

Her closes used to read like "a nice chat." She wants them **concrete and useful**, while staying soft-sell:

- Offer something specific: a diagnostic, a spec-&-select conversation, "we can show you where we've supported others with similar challenges."
- Direct to a named person where relevant ("contact Ben King directly").
- Still no hard sell. Soft, but with substance and a reason to act.

Good: "If a project of yours is showing a few of these, it's worth a conversation - we can show you where we've helped others get back on track." 
Weak: "Happy to talk it through." (Too vague on its own.)

## Hard bans (zero tolerance)

**New bans from 4 June:**
- **"most"** - never as a quantifier or opener ("most projects…", "most organisations…"). Use *often, a lot of, many*. Sarah: "I don't want it saying 'most anything' ever."
- **"quiet" / "quietly"** - over-indexed by AI. Out.
- **Hashtags** - none. They feel "a bit marketing" and lightweight for serious thought leadership. Lean the topic into the opener instead.
- **Em dashes** - none (use commas, full stops, brackets).

**Standing bans (AI slop):** delve, comprehensive, facilitate, utilise, leverage, landscape, embark, crucial, game-changing, revolutionary, seamless, end-to-end, best-in-class, cutting-edge, deep expertise, proven track record, holistic, synergy, robust, optimise, streamline, navigate (as filler), unlock, empower, elevate, pivotal, underscore, resonate. Plus: "in today's fast-paced world", "as the landscape evolves", "the room went quiet", "that stuck with me", "I would love to set up a quick call", "thrilled to share" + a vague concept, "Thoughts?" / "Agree?" endings.

## Structural rules

- **No bravado.** Imparts an informed point of view; never bigs it up. No "we see this and here's what's wrong about you."
- **Positive positioning only - no Big 4 digs.** Sarah came from big consulting (WTW, BDO). State what Eaton does, never knock competitors. The differentiator (outsider who stays) is always a positive belief, never "unlike the Big 4 who leave." Sanctioned contrast line (approved): "Traditional consulting can feel distant: armies of juniors, long reports, endless PowerPoints, but not much real change."
- **Soften absolutes.** "Technology is the more straightforward part", not "the easy part."
- Vary paragraph length. No uniform blocks, no one-line-paragraph-as-default engagement bait.
- Bullet lists are fine for genuine "signs to watch / lessons" content (she uses them), but each bullet must carry substance.

## Anti-fabrication

Never invent stats, client names, outcomes, dates, or event details. Use `[placeholder]` for anything only Sarah can supply ([client example], [event date], [guest name]). Real facts available: Eaton 2012 / 150 consultants / Dublin-Cork-Limerick + UK; HR Path 2,500 consultants / 28 countries / since April 2025; Sarah 20+ years change & comms, WTW, BDO, Harvard Business School Jan 2026. Proof points: the recovery client (anonymise) and vendor-independent spec-&-select.

## The test

Would Sarah post this from her own LinkedIn with at most a small edit? Aim for 80% right - she'll tweak a word or cut a line. Don't over-engineer to perfection; that wastes her time.
