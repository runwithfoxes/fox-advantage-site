# Sarah's themes and territory (the spine)

This is what the engine always "knows." It lists **angle types, not finished posts** - generative seeds. Built from Sarah's own material and her 4 June review of the first batch.

## The weighting (hard rule)

- **~60 - 70% CHANGE & COMMUNICATIONS** - Sarah's heartland. This is what she's known for and comfortable putting her name to.
- **~30 - 40% PROGRAMME / PMO / GOVERNANCE** - Eaton's territory (her senior colleagues David O'Connor, John Locke). Sarah speaks to it *as services the business offers*, in her voice, always with context so a reader doesn't think "I thought she was employee experience."
- Anchor to these **2 themes only**. Consistency beats range. Keep the two as **separate campaigns** - don't blend, or it reads generic.

## Theme 1 - Change & communications (PRIMARY, her heartland)

Her actual expertise. Posts here can be confident and first-person.

Angle types:
- **Change starts before the project does.** Her evolved view: change management and change readiness must begin before kickoff, not as a Q4 training afterthought. Understand where stakeholders are, surface resistance and barriers early before they block delivery.
- **Don't let change happen *to* people.** Engage people early - "here's the journey, here's why, we'll keep you informed" - so they feel part of it. Even without sharing everything, you can bring people along.
- **Your biggest ambassadors are the people in front of you.** (Her old line, updated.) Tap internal teams before spending on external noise.
- **Adoption is the hard part, not the technology.** Tech is the more straightforward part (never "easy"). The behaviour change, comms and adoption work is what makes an investment land. This is her core.
- **Communications as a proper workstream**, built into the plan from day one, not a tidy-up job a week before go-live.
- **Change readiness / barriers / resistance** - identifying and managing them early.
- **Stakeholder engagement and internal comms** during transformation.

## Theme 2 - Programme management, PMO & governance (SECONDARY, Eaton services in her voice)

Real Eaton strength; Sarah lends her voice. Always contextualise why she's talking about it.

Angle types:
- **Governance as an enabler.** Open with the hook ("governance is one of those words that makes people's shoulders drop"), then immediately frame it as a core part of great programme/project management - necessary, and freeing when done right. Nest governance INSIDE programme management; never tag it as change management.
- **The goal isn't to give you a PM - it's to get the programme delivered.** Outcomes over a pair of hands. (She rates this highly.)
- **The outsider who's with you.** The experienced external who has seen it before, carries no internal politics, and stays alongside you. The differentiator (see category-landscape) - always positive, never a dig.
- **What's really a project?** Half of an org's "projects" are BAU with a deadline; the critical ones get lost. Separate them.
- **Programme/project diagnostics.** Few leaders have a true picture of where every project sits, how it's tracking, the risks, when it finishes. A diagnostic gives that visibility. (Close by offering the diagnostic specifically.)
- **Recovery / course-correct mid-flight.** You don't have to restart or plough on - you can step in, call the hard truths, reset, and get back on track. PROOF AVAILABLE (see proof library).
- **Spec & select.** Independent, vendor-neutral support to choose the right system/partner - Eaton works across Workday, Dayforce, Oracle etc., so no shoehorning. A genuine strength; strong video candidate. (Use her term "spec and select".)
- **Set transformations up to succeed before delivery starts** - business case grounded in what the solution can really do, requirements written before the vendor is chosen, a real competition. Frame for process/org change too, not just systems.

## Proof library (real, usable - anonymise)

- **Recovery:** a recent client where Eaton called out hard truths, reset the vendor choice, and deliberately delayed the project for the right reasons. Use for recovery/course-correct posts.
- **Spec & select:** genuinely vendor-independent across Workday / Dayforce / Oracle / UKG / HiBob - not positioning, a real differentiator.
- **Verified facts (free to use):** Eaton Square founded 2012, 150 consultants, Dublin/Cork/Limerick + UK; part of HR Path (2,500 consultants, 28 countries) since April 2025. Sarah: 20+ years leading change & communications; previously WTW (led UK & Ireland Employee Experience) and BDO; Harvard Business School Jan 2026.

## Out of lane (do NOT write these)

- Operational "as-is on the ground vs leadership level" / getting into the operational weeds - Sarah explicitly won't claim this depth. It also reads as patronising.
- Recruitment, executive search, EOR, talent management - NOT her territory (the old skill had this wrong).
- Anything patronising about the reader not understanding their own business.
- Pure HR-tech configuration detail.
