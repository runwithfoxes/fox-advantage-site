---
name: eaton-merge
description: "Roll the approved message sequence across the whole list and build the HeyReach upload file. Use when Ben says 'merge this across my list', 'build the upload file', 'make the HeyReach CSV', or has signed off his sequence with the message coach and wants it applied to every lead. It personalises each message per company from its own signal and writes the merge CSV in the exact shape HeyReach needs. NOT for writing the messages (that is eaton-message-coach) and NOT for loading into HeyReach (that is the load step)."
---

# Eaton Merge

This skill takes the **approved message sequence** (signed off with `eaton-message-coach`) and the **enriched, emailed list**, and writes the personalised messages for **every** lead, then builds the upload file HeyReach expects. You run it in Claude, in the browser, in the **same chat** where you signed off the sequence, so the approved wording is right there.

It does not write new copy from scratch. It carries the approved sequence across the list and personalises the **opener** of each message from each company's own signal. The body stays as signed off.

## Before it builds (it checks these first)

1. **The approved sequence is here.** If you are not in the same chat as the message coach, ask Ben to paste the signed-off sequence first. Don't guess the wording.
2. **The list has what it needs.** Each lead needs the enrich details (name, company, signal) and, for the email legs, an email address. Rows missing a signal can't be personalised - they go to the spot-check list, not silently out.

## How it builds (per lead)

For each person on the list:

1. Take each message in the approved sequence in turn.
2. **Personalise the opener** from that company's signal, using the same rule the coach signed off (real title, real month, "looks like" hedge, no invented facts).
3. Keep the body exactly as approved.
4. Hold the limits - the **connection note stays under 300 characters** after personalising, not just before.

Work in chunks of about 20 and show progress. Steady and visible.

## The two upload files it writes

The LinkedIn messages live in HeyReach and the emails live in SmartLead, so they load into different tools. The skill writes **two files**, one per tool, both keyed on email so the HeyReach to SmartLead handoff can match the same person.

**HeyReach file** (the LinkedIn content):
```
firstName, lastName, linkedInUrl, email, companyName, position,
connection_request, li_insight, li_engagement
```

**SmartLead file** (the email content):
```
email, firstName, lastName, companyName,
email1_subject, email1_body, email2_subject, email2_body, email3_subject, email3_body
```

The column names must **match the custom variables in the HeyReach and SmartLead campaigns** (those campaigns are already set up). If you are unsure a column name matches a campaign variable, say so - a mismatch means the campaign sends a blank.

## The loud check (before you hand back the file)

- [ ] Every personalised opener traces to a real signal on that lead's row. No invented facts.
- [ ] Every **connection_note is 300 characters or fewer** after personalising.
- [ ] No empty message cells on a row that is meant to send. An empty cell sends a blank, so that row goes to spot-check.
- [ ] **No dashes** anywhere in the copy.
- [ ] The counts add up: **rows in the file + rows held for spot-check = leads you started with.** Show the sum.

## What it hands back

1. **Two files** - the HeyReach file and the SmartLead file, both ready for the load step.
2. **Spot-check these** - a short list of leads where the personalisation was thin or a cell came back empty, with the reason. Ben checks these few, not all of them.
3. **A plain summary**, e.g. *"Built 128 rows in two files (HeyReach + SmartLead). 124 ready, 4 to spot-check (thin signal). 128 = 124 + 4."*

Note: contacts with no email stay in the HeyReach file (LinkedIn only) and are left out of the SmartLead file.

## Hard rules

- Carry the approved sequence; only the opener varies per lead. Never rewrite the signed-off body.
- No invented facts. Thin or missing signal goes to spot-check, never a guessed line.
- Column names must match the campaign's custom variables, or the send goes blank. Flag any doubt.
- The three numbers (ready, spot-check, started) must add up, shown every time.
- Builds the file only. No sending, no loading into HeyReach. That is the next step.

## If something goes wrong

- **No approved sequence in the chat** → ask Ben to run `eaton-message-coach` first, or paste the signed-off sequence.
- **Lots of empty cells** → stop and check the column names match the campaign variables before handing over a file full of blanks.
- **A row has no signal** → spot-check, with the reason. Don't drop it and don't invent a hook.
