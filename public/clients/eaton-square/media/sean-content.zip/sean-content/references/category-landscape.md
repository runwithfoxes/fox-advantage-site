# Category Landscape: HR Technology Consulting (UK & Ireland)

What the industry is saying, who's saying it, and where the gaps are. Use this to position every content angle against the category conversation.

## Thought leaders (what the category listens to)

### Josh Bersin
The dominant HR analyst. Sets the vocabulary CHROs use. Current themes: "Systemic HR" (integrated, AI-enabled HR operating model), "Superworker" (AI-augmented individual productivity), "Agentic HR" (autonomous AI agents managing HR functions by 2030), frontline worker strategy, enterprise AI economics. Aspirational, framework-driven, vendor-adjacent. His audience buys the platforms Eaton implements.

**Gap:** Bersin writes the vision. He does not write about what happens when the organisation isn't ready for the vision. Implementation reality, adoption failure, the gap between the keynote and the Tuesday morning standup. That's Eaton's space.

### Red Thread Research (Stacia Garr, Dani Johnson)
Independent, vendor-skeptical. Founded explicitly against vendor-funded research. Current themes: AI shifting from experimentation to infrastructure, skills data architecture (governance, not just skills taxonomies), L&D restructuring, erosion of institutional trust. More rigorous, more structural, harder questions than Bersin.

**Gap:** Red Thread asks the hard structural questions but doesn't advise on what to do about them operationally. Eaton can bridge their diagnostic rigour with practitioner answers.

### CIPD
Professional body for HR in UK and Ireland. 160,000 members. Practitioner-first, evidence-based, ethical. Current priorities: AI adoption (67% of Irish HR pros say it's their top development priority, but only 7% using it in data analysis), Employment Rights Act 2025 (biggest UK employment law overhaul in years), skills shortages (91% of organisations report gaps), manager capability, wellbeing, culture (40% of Irish orgs named it top 2026 priority).

**Gap:** CIPD sets standards and publishes research but doesn't implement anything. They tell HR professionals what matters; Eaton helps them do it.

### Gartner HR
Sells advisory to CHROs. 2025-2026 priorities: (1) Harness AI to revolutionise HR, (2) Shape work in the human-machine era, (3) Mobilise leaders for growth in uncertainty (64% of CHROs say leaders lack the mindset), (4) Address culture atrophy (only 47% say culture drives performance). Data-heavy, prescriptive, C-suite register.

**Gap:** Gartner writes "CHROs must..." but doesn't get its hands dirty. The gap between a Gartner recommendation and an organisation actually doing it is exactly where Eaton operates.

### HR Grapevine
UK HR media. 290,000+ HR professionals. Practical, forward-looking, not academic. Covers HR tech, talent, DE&I, compliance, L&D. Launched an editorial advisory board in 2025 (Aviva, HelloFresh). Commercially, an advertising platform for HR tech vendors.

**Useful for:** Monitoring what topics are gaining traction with HR buyers. Potential distribution channel.

## Competitors

### Phase 3
Independent HR/payroll tech consulting. "Digital Transformation Experts." Services: managed payroll, HRIS selection, implementation (Sage, HiBob, iTrent, PeopleXD), optimisation. Clients: Virgin Hotels, Argos, NHS, Selfridges. Content: blog, "The HR Green Room" podcast. Strong on payroll and mid-market implementation. Less depth on people strategy or leadership advisory than Eaton.

### Silver Cloud HR
Pure-play HRIS selection, implementation, optimisation. Four-stage model: Review, Select, Deliver, Maximise. Has a Digital HR Maturity Model assessment tool. Partners: Dayforce, PayCaptain, HiBob. Clients: Specsavers, Gatwick Airport, Hotel Chocolat. Narrower scope than Eaton: technology selection and implementation, not broader people strategy or change leadership.

### Lavasource
Full-service HR/payroll tech consulting plus talent marketplace. Founded 2021, UK-based. Vendor-agnostic (Dayforce, SAP, Oracle, Workday, Cornerstone). Also does people strategy, operating model design, C-suite advisory, programme delivery. Differentiator: talent marketplace (70+ countries) blending consulting with resource augmentation. More globally ambitious than Phase 3 or Silver Cloud.

### PwC (HR practice)
"Human-led, tech-powered." HR operating model design, workforce analytics, GenAI in HR. Workday is their flagship alliance. Targets CHROs and CFOs jointly, framing HR as a financial efficiency argument. Scale, platform relationships, brand authority. Weakness: cost, perceived vendor bias, less agility on mid-market.

### Deloitte (Human Capital)
Claims "global leader in HR transformation." 400+ human capital professionals in UK alone. Flagship: annual Global Human Capital Trends report (widely cited). Skills-based org design, GenAI adoption, M&A people transitions. Proprietary "Programme Aerodynamics" framework. "Capital H" blog and podcast. Weakness: same as PwC. Scale over intimacy.

### What competitors publish
Phase 3 and Silver Cloud: practical implementation content, buyer tools, podcasts. Lavasource: blogs and LinkedIn. Big 4: flagship research reports, methodology marketing, brand authority content. **None of them write from the consultant's seat about what it actually looks like when adoption isn't working.** That content gap is Eaton's territory.

## Partners (what the vendors publish)

### HiBob
Positions as strategic people-management partner, not software vendor. Tone: consultative, HBR-adjacent. 60% thought leadership, 25% product, 15% how-to. Current themes: AI transformation (but "starts with managers, not technology"), HR-Finance alignment, EU Pay Transparency, gender equity.

**Gap for Eaton:** HiBob publishes strategy but never implementation reality. "What it actually looks like in the room when you try to align HR and Finance" is wide open for a practitioner.

### Dayforce
Authoritative, enterprise-focused. Uses proprietary "Pulse of Talent" survey. Current themes: AI workforce planning, AI agents, hybrid work, payroll compliance, skills shortages. Notable data: 87% executives have AI access vs 27% frontline workers. C-suite register, polished, data-heavy.

**Gap for Eaton:** Dayforce writes about workforce complexity at scale but never from the consultant's seat. Implementation challenges, change fatigue, project governance, what actually goes wrong: none of it appears. A practitioner voice is genuinely differentiated.

## The strategic gap (Eaton's territory)

Bersin writes the vision. Gartner writes the frameworks. CIPD writes the standards. Vendors write capability. Big 4 write methodology. Boutique competitors write implementation credentials.

**Nobody writes from the consultant's seat about what it actually looks like when you're in the room and the adoption isn't working.** That is Sean's territory. The messy middle. The pattern recognition. The "I've seen this before and here's what's really going on." Every content angle should be tested against this gap.
