# Sean's Content Territory

Sean's deep topics, what the category says about each one, and where Sean's angle is differentiated. Use this to match raw material to angles and to confirm a topic is in Sean's territory (not Sarah's or Ben's).

## Deep topics (original content exists, Sean has authority)

### 1. The scapegoat pattern: blaming the system
**What it is:** Organisations say "we need to replace the system" when the real problem is undefined processes, poor data quality, and adoption failure.
**Category says:** Vendors publish platform upgrade paths. Competitors talk implementation methodology. Gartner talks about technology strategy.
**Sean's angle:** Nobody says "the system isn't the problem." Sean does. His line: "A new system on top of broken processes just gives you the same problems in a different interface."
**Service line:** HRIS, Pillar 1 (Platform health and advisory)
**Best goals:** Get Talked About, Authority Build

### 2. Adoption is the transformation, not the go-live
**What it is:** Technology transformations fail because adoption is treated as training, not change management. The system goes live but people don't use it.
**Category says:** Bersin talks about "Systemic HR" as a future state. Vendors publish go-live success stories. Big 4 talk methodology.
**Sean's angle:** "Technology transformations fail when nobody plans for adoption." The gap between configuration and actual use is where projects die. Sean has seen it across Dayforce, Workday, UKG, HiBob.
**Service line:** HRIS, Pillar 2 (Implementation that delivers)
**Best goals:** Authority Build, Value Add

### 3. The people function that hasn't kept pace
**What it is:** Company has grown, acquired, expanded. The HR function was designed for a different organisation. Now it's held together with workarounds.
**Category says:** Gartner says CHROs need to redesign operating models. CIPD says manager capability is a weak point. Bersin says "Superworker" will change everything.
**Sean's angle:** "Was your people function designed for the business you're running today?" Practical diagnostic, not future-state aspiration. Sean works with the organisation as it is, not as Gartner says it should be.
**Service line:** Business Consulting, Pillar 1 (Strategy that keeps pace)
**Best goals:** Authority Build, Get Talked About

### 4. HRIS health checks (the diagnostic)
**What it is:** Structured assessment of people, process, and technology together. Root-cause analysis, not just system audit.
**Category says:** Silver Cloud has a "Digital HR Maturity Model." Vendors run health checks on their own platform only. Big 4 audit the function but won't touch the technology.
**Sean's angle:** "We assess both, because the problem is almost always in the gap between them." The health check bridges function and system. Nobody else does both.
**Service line:** HRIS, Pillar 1 (Platform health and advisory)
**Best goals:** Value Add, Strategic CTA

### 5. EU Pay Transparency and compliance readiness
**What it is:** The EU Pay Transparency Directive and UK Employment Rights Act require reporting that most current systems can't produce. The gap isn't understanding the law; it's data quality, job architecture, and system configuration.
**Category says:** CIPD publishes guidance. Law firms advise on legislation. Vendors build compliance features. Gartner lists it as a priority.
**Sean's angle:** "Law firms can advise on the legislation but can't configure your system. Vendors will build compliance features but won't redesign your processes. We bridge both." Sean connects legislation to operational and system changes.
**Service line:** HRIS, Pillar 4 (Compliance readiness)
**Best goals:** Value Add, Authority Build

### 6. Employee Ownership Trusts (EOT)
**What it is:** EOTs create employee-owned businesses. The people function challenge: reward design (qualifying bonus vs senior remuneration), engagement (ownership culture vs ownership structure), governance (trustee boards, employee councils), multi-site complexity.
**Category says:** Almost nobody in the HR tech consulting space talks about this. EOA publishes research. It's a niche Sean owns.
**Sean's angle:** "Ownership is a behaviour, not a structure." Sean has a full blueprint (4,500 words, cites Riverford, Go Ape, Aardman, Curtins, EOA research). This is differentiated by default because no competitor covers it.
**Service line:** Business Consulting
**Best goals:** Authority Build, Salience

### 7. Change management in technology transformations
**What it is:** Implementation without change management is installation. Communications, stakeholder engagement, adoption planning need to start at project initiation, not bolted on at go-live.
**Category says:** Everyone says change management matters. Deloitte has "Programme Aerodynamics." Bersin says AI requires organisational redesign.
**Sean's angle:** "The people you meet at the pitch are the people who work on your project." Senior delivery, embedded change, not armies of juniors. The proof is in who shows up, not the methodology deck.
**Service line:** Business Consulting, Pillar 2 (Programme delivery that lands)
**Best goals:** Authority Build, Get Talked About

### 8. AI in HR: the readiness gap
**What it is:** The industry is racing toward AI (Bersin's agentic HR, Gartner's #1 CHRO priority). Most organisations haven't got basic HRIS processes working. You can't automate a process that doesn't exist.
**Category says:** Everyone is pushing AI. CIPD data: only 7% of Irish HR pros using AI in data analysis. Bersin: "Superworker." Gartner: "revolutionise HR."
**Sean's angle:** Sequence, not rejection. Get the foundation right first. This isn't anti-AI; it's pro-readiness. Sean can say what vendors and analysts can't: "Most of my clients aren't ready for this yet, and here's what they need to fix first."
**Service line:** HRIS, Pillar 1 / Business Consulting, Pillar 3
**Best goals:** Authority Build, Get Talked About

## Credible topics (framework exists, less original writing)

### Finance transformation
Sean has the full messaging framework (Service Line 4) but limited original content. "Finance-led, not IT-led" is the angle. Targeting CFOs facing PE scrutiny, IPO prep, audit pressure.

### Talent management and EOR
Service Line 3. "The right people, in the right way, at the right time." Global hiring, secondments, flexible workforce. Sarah shares this territory, so coordinate.

### Process automation and Microsoft
Service Line 5. "Business-led technology. Measurable results." Microsoft Power Platform, Power BI. More operational than thought leadership.

## Territory boundaries

**Sean's, not Sarah's:** Industry analysis, deep frameworks, compliance, authority-driven thought leadership, EOT, the "why transformations fail" thesis.

**Sarah's, not Sean's:** Talent management strategy, event recaps, client relationships, team celebrations, education sector.

**Sean's, not Ben's:** First-person authority ("I've seen it too many times"), drawing the lesson, thesis-driven posts. Ben shares observations; Sean draws conclusions.

**Shared (coordinate):** Case studies (Sean owns the lesson, Sarah names the people), HRIS adoption (Sean = strategy, Ben = what prospects are asking about).
