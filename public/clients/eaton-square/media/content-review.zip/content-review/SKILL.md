---
name: content-review
description: Eaton Square content reviewer. Takes feedback on what was posted and what performed, identifies patterns, and adjusts recommendations for the next cycle. Use when someone says 'we posted these', 'this worked', 'review our content', or provides performance data on recent posts.
---

# Eaton Content Reviewer

Takes feedback on what was posted, what performed, and what didn't happen. Identifies patterns and adjusts recommendations for the next content cycle.

Use when someone says "we posted these", "this worked", "update the calendar", "how did we do this week", "review our content", or provides performance data on recent posts.

## Before reviewing

1. Read `references/content-strategy.md` -- benchmarks to compare against
2. Read `references/fox-framework.md` -- scoring framework

## Step 1: Collect the data

Ask what was posted and how it performed. The user might provide:

- Which posts went live (and which didn't)
- Impressions, likes, comments, shares, saves
- Profile views
- DMs received
- Posts that got unexpected engagement
- Posts that underperformed
- Any qualitative feedback ("someone mentioned this at a meeting")

If the user doesn't have detailed metrics, work with what they have. Even "the carousel did well and the text post didn't land" is useful signal.

## Step 2: Analyse against benchmarks

Compare performance against these baselines (from `references/content-strategy.md`):

- Professional services engagement: ~3.2% average, 5-8% for small focused profiles
- Saves: target >0.5% of impressions
- Profile visits: target 3-5% of impressions
- Carousels should outperform text posts on saves
- Text posts should drive more comments

### Patterns to look for

**Format patterns:**
- Which formats consistently outperform? Lean into them.
- Which formats consistently underperform? Reduce or rethink.

**Topic patterns:**
- Which service lines get the most engagement?
- Which topics fall flat?

**Voice patterns:**
- Which person's posts perform best?
- Is there a format-voice combination that works particularly well?

**Goal patterns:**
- Are Authority Build posts landing? (Comments, follows)
- Are Value Add posts getting saved?
- Are case studies driving DMs?

## Step 3: Identify what to change

Based on the analysis, recommend adjustments:

- **Format mix:** "Carousels are outperforming text posts 2:1. Increase from 2 to 3 carousels per week."
- **Topic rotation:** "Finance Transformation posts are getting no engagement. Either change the angle or reduce frequency."
- **Voice assignment:** "Ben's observation posts are performing better than expected. Give him one more slot per week."
- **Goal balance:** "Too many Value Add posts. Add an Authority Build post for Sean this week."
- **Timing:** "Thursday morning posts consistently outperform Tuesday. Shift Sean to Thu."

## Step 4: Flag warning signals

Alert on these early indicators (from the research):

- **Engagement below 3% for 4+ weeks** → audit hooks, format mix, ICP fit
- **Saves below 0.5% consistently** → content not perceived as useful. More frameworks/carousels.
- **Zero DMs from ICP after 3 months** → content isn't generating consideration. Sharpen POV.
- **Follower growth but no DMs** → wrong audience growing. Tighten topics.
- **Any voice slipping below 2 posts/week for 4 weeks** → cadence unsustainable. Reduce target.

## Step 5: Recommend next cycle

Output a specific recommendation for next week:

- Which posts to create (voice, topic, format, goal)
- What to do differently based on the data
- Any content to repurpose from high performers
- Any gaps in pillar or service line coverage

## Step 6: Log the learning

Summarise in a simple format the user can paste back next time:

```
## Content Review: [date]
Posts published: X/Y planned
Top performer: [post] -- [why]
Underperformer: [post] -- [why]
Format winner: [format]
Adjustment: [what to change next week]
```

This becomes the running record that improves recommendations over time.
