# Content Strategy Rules

Distilled from primary research (Socialinsider 2026, Hinge 2025, Edelman-LinkedIn 2024, Metricool 2026) and practitioner evidence. These rules govern what to create, when, and in what format.

## Cadence

- 2-3 posts per person per week. Do not exceed 3.
- Space posts 24+ hours apart.
- Stagger voices across the week to avoid same-day collisions.
- Best days: Tue-Thu. Best times: 7-8am and 12-1pm local.
- Sunday works specifically for personal storytelling content.

## Format hierarchy (engagement rates, Socialinsider 2026, 1.3M posts)

| Format | Engagement | Best for |
|---|---|---|
| Native document/carousel | 7.00% | Frameworks, case study teardowns, step-by-step, data comparisons |
| Multi-image | 6.80% | Before/after, visual evidence, team photos |
| Video | 5.90% | Top-of-funnel personality, talking head, culture (but saturated -- views down 36% YoY) |
| Single image | 5.20% | Data charts, infographics, quote graphics |
| Text post | 4.30% | Observations, contrarian POV, personal stories, engagement |
| Polls | Low quality | Audience research only. Poll voters 60% less likely to visit profile |
| Link posts | 3.70% | Avoid. Outbound links penalised ~40% in distribution |

## Format selection by goal

| Goal | Best format |
|---|---|
| Maximum saves and bookmarks | 7-slide PDF carousel |
| Top-of-funnel reach | Short video (<60s) or text post |
| Comment velocity and dialogue | Text post with contrarian POV |
| Lead nurture and retention | LinkedIn Newsletter |
| Authority and SEO | LinkedIn Article (low engagement but indexed by Google) |

## Pillar model (4 pillars)

1. **Authority** -- Industry POV, contrarian insight, original thinking. Sean's primary territory.
2. **Proof** -- Case studies, client wins, before/after, diagnostic results. Sarah and Sean share this.
3. **Personality** -- Behind the scenes, lessons learned, personal stories, what went wrong. All voices.
4. **Engagement** -- Reactive sector commentary on news/regulation, questions, polls. Ben's primary territory.

## Pillar rotation

- Rotate one service line per week (not multiple in one week) to build algorithmic topic authority.
- Map pillars to buyer problems, not service descriptions. "Hiring isn't working" not "Talent Management."
- 4:1:1 pacing: 4 educational/insight pieces, 1 case study, 1 direct CTA.

## Case study rules

- Case studies are non-negotiable. 43% of B2B buyers want them (Edelman/LinkedIn 2024).
- Structure: Problem, Action, Result, Impact (P-A-R-I). Lead with the metric.
- Naming hierarchy: named with quote > named with role > industry-descriptor anonymous > fully anonymous.
- For HR consulting (sensitive sector), anonymity is expected. Use extreme specificity to compensate.
- 1 case-study post per voice per week. Full carousel teardown every 2 weeks; mini-cases in between.

## Carousel spec

- Sweet spot: 7 slides.
- Dimensions: 1080x1350px (4:5 portrait).
- Typography: minimum 80pt headlines, 40pt body.
- Text density: under 30 words per slide.
- Design: high-contrast, 2 fonts max, 3 brand colours max.
- Structure: Cover Hook > Problem > 3 Value Points > Summary > CTA.
- Three templates for pro services: Myth vs Reality, 5-Step Framework, Case Study Teardown.

## Repurposing chain

One anchor piece (blueprint, article, case study) atomises into 5-15 posts over 4-6 weeks:
1. Anchor: newsletter/article (deep thought leadership)
2. Carousel: 3 key takeaways as 7-slide PDF
3. Text posts: individual claims or stats extracted into 3 standalone posts
4. Video: most-engaged text post becomes a 60s talking-head script
5. Poll: core contrarian point reframed as an opinion poll

## Performance benchmarks

- Professional services engagement: ~3.2% average, 5-8% achievable for small focused profiles.
- Personal profiles: 2.6% average (vs 1.7% company pages).
- Content programmes take 6-12 months for pipeline impact. 3-4 months for early traction signals.
- Leading indicators: post saves (>0.5% of impressions), profile visits (3-5% of impressions), DMs from ICP, "how did you hear about us?" responses.

## Thought leadership quality bar

- 73% of B2B decision-makers trust thought leadership more than marketing materials.
- 75% say thought leadership led them to research something they weren't considering.
- Only 15% rate current thought leadership quality as "very good or excellent."
- What buyers want: strong data (55%), understanding their challenges (44%), concrete case studies (43%).
- What kills it: corporate platitudes, unoriginal advice, thinly veiled press releases.
- LinkedIn is actively deprioritising formulaic hook-insight-CTA content in 2025-2026.

## The 95:5 lens

~95% of any B2B audience is out-of-market in any quarter. For professional services, purchase cycles are ~5 years. Content builds mental availability for the 2030 buyer, not pipeline this week. Never judge content by immediate lead generation. Track mental availability metrics: saves, profile visits, DMs, "how did you hear about us?"
