# Sarah McDonough Voice Patterns

Extracted from 86 LinkedIn posts, 1 article, 8 recommendations, meeting transcripts, and approved Eaton copy.

## How Sarah opens posts

### Event recaps (her most common post type)
She names the event and who was there first, then shares her take:
- "What a great conversation this week at our HR Leadership forum with Eaton Square and special guests from Dayforce, Visier Inc. and Eightfold AI on how AI is transforming HR."
- "Another fantastic night at the HR Director's Dinner last night where I was joined on the panel by Audrey Cahill and Eleanor Nash."
- "We had a great day yesterday at the CIPD conference in Dublin."
- "What a wonderful evening at the HR Champions Awards in Dublin."
- "What a wonderful first day Harvard Business School."

Pattern: "What a [great/wonderful/fantastic] [event] at/with [names]."

### Event announcements
She leads with her own anticipation, then describes what will happen:
- "I'm really looking forward to this! We're co-hosting a special evening with Dayforce..."
- "Really looking forward to our next HR leaders forum where we'll discuss..."
- "I'm excited to explore the latest in HR Technologies in London on 29-30 April."

Pattern: "I'm [really] looking forward to / excited to [specific thing]."

### Career and team updates
She leads with the emotion, then the detail:
- "I'm excited to share that I've joined Eaton Square, An HR Path company, as Director of Business and People Consulting."
- "Feeling energised and excited after a fantastic week with the WTW EX team in London."
- "After more than 5 years, it's time for me to take on a new exciting opportunity."

### Thought leadership (rarest post type)
She opens with an observation from her experience:
- "One of the things I have noticed over 20 years of leading change programmes is that the briefing note to staff is almost always an afterthought." (from her article)
- "'Change is inevitable but how you react is under your control'. Just one of the key messages from last night's HR Directors Dinner."

## How Sarah closes posts

### Warm invitations (never hard sells)
- "If you're attending and would like to find out more, reach out or drop by our stand BB34."
- "Spaces are limited so please contact Ben King directly if you're interested."
- "please reach out if you'd like to find out more."
- "please get in touch to find out how we can support."
- "It would be great to catch up with some familiar faces, and meet a few new ones too :)"

Pattern: "reach out" / "get in touch" / "contact [name] directly" / "happy to [chat/share/send details]"

### Gratitude and name-dropping
She almost always closes by thanking people by full name:
- "Thanks so much to my fellow panellists for sharing their experience and insights and thanks as always to Donna O'Connor for connecting us all."
- "Thank you to Donna O'Connor for a wonderful event yesterday..."
- "Great to be joined by April McDonnell Anne Phelan Jonathan Kerr Simon Langley"

## Sarah's signature words and phrases

### Words she reaches for
- "really" (used naturally and frequently)
- "great" / "wonderful" / "fantastic" / "amazing"
- "looking forward to"
- "delighted to"
- "pleasure" (as in "had the pleasure of")
- "thrilled" (for genuine big moments like new jobs)
- "energised" / "energising"
- "collaborative" / "collaboration"
- "personable"
- "thought leadership"
- "hands-on"
- "close to the work" / "close to the detail"

### Her frameworks
- "The 2 c's: clarity and connection" (from her article)
- "The people you meet at the pitch are the people who work with you" (from meeting)
- "We don't hand you a strategy and walk away" (approved copy)

### How she describes people she admires
From her recommendations:
- "a true partner in the business"
- "incredibly collaborative and strategic"
- "continuously seeking opportunities to connect people"
- "great to work with, nothing is too much trouble"
- "great drive, ambition and positivity and brings out these characteristics in others"
- "I have no hesitation in recommending"

## How Sarah structures takeaways

She uses bullet points or numbered lists for key points from events:
- "The key take-outs from me?" followed by bullet emojis (💡)
- "Some of my key take-aways were:" followed by plain text points

## What Sarah does NOT do

- She does not write manifestos or thematic essays
- She does not open with dramatic observations about industry trends
- She does not describe unnamed people as evidence ("several HR leaders told me...")
- She does not write measured, detached prose
- She does not use irony or dry humour
- She does not take controversial positions
- She does not close with wise-sounding one-liners
- She rarely writes without naming specific people or organisations

## Tone by format

### LinkedIn posts: Warm, relational, names people and events. Energy is genuine enthusiasm, not performed wisdom.
### Event invitations: Practical details, personal angle on why it matters, clear CTA to a named person.
### Recommendations: Specific, generous, always ties praise to concrete work.
### Approved Eaton copy: More measured but still direct. "We don't do faceless consulting" not "We provide bespoke solutions."
### Spoken voice (from transcripts): Practical, collaborative, action-oriented. "I'll blitz away at this." "Let's iterate." "What might be useful is..."
