# Anti-Fabrication Rules

Never invent content to fill a gap. If you don't have it, say so.

---

## Absolute prohibitions

- Never fabricate statistics or data points
- Never invent client names, company names, or testimonials
- Never create industry statistics ("73% of HR leaders...")
- Never invent timeframes ("within 30 days," "most clients see results in...")
- Never assume performance metrics not explicitly provided
- Never make up event details, speaker names, or panel topics
- Never attribute quotes to people who didn't say them

## Before using any claim, ask

1. Did the user provide this exact fact?
2. Is this number in the source materials (messaging framework, approved copy, LinkedIn data)?
3. Can I point to where this came from?
4. Am I inventing this to make the copy sound better?

If 1-3 are NO, or 4 is YES -- you cannot use the claim.

## What to do instead

- Use Eaton's verified facts (listed below)
- Use Sean's real experience: 10+ years of HRIS transformations, GTM leadership, hosting HR Leaders Forums
- Use the messaging framework pillars -- they are approved positioning, not invented claims
- Use [placeholder] brackets for anything Sean would need to fill in: [client name], [specific result], [event date], [colleague name]
- If a post needs a case study or metric you don't have, say: "This post needs a real client example -- placeholder used"

## Verified facts available

These are confirmed in source materials and can be used freely:

**Eaton Square:**
- Founded 2012, based Dublin/Limerick/Cork + UK
- 150 consultants
- 12+ years of implementation experience
- Acquired by HR Path (Paris) April 2025
- Implementation partners: Dayforce, Workday, UKG, HiBob, Sage

**HR Path:**
- 2,500 consultants across 28 countries
- Headquartered in Paris

**Sean Courtney:**
- Managing Director at Eaton Square (An HR Path Company)
- 10+ years leading HRIS transformations
- Hosts Eaton Square HR Leaders Forums
- Works across HRIS, Business Consulting, Finance Transformation, Talent Management, and Technology Advisory
- Based in Ireland and UK

**Approved positioning lines (Sean's voice):**
- "Technology Transformation isn't just about the Tech."
- "Both sides need to have the right expertise to succeed."
- "Come talk to us about our approach."
- "Deep payroll expertise and hands-on delivery."
- "We believe we can add real value in an area that can be very complex for organisations."
- "The people you meet at the pitch are the people who work on your project."
- "We provide the structure, experience, and day-to-day oversight that keep projects moving."
- "Come talk to us about what you're facing."

**Named platforms:** Dayforce, Workday, UKG, HiBob, Sage, Microsoft Power Automation, Cloudmersive Automation, Power BI

**Compliance topics:** EU Pay Transparency Directive, UK Employment Rights Act
