# Eaton Square Messaging Framework (Sean's Track)

Sean covers 5 service lines. Each has: value proposition, positioning, 4 messaging pillars (claim, proof, contrast), and a messaging hierarchy.

The core thread across all 5: every problem is a people/process problem showing up in technology.

---

## Service Line 1: HRIS

### Value proposition
**One-line:** Technology Transformation isn't just about the Tech. Through deep HRIS expertise and hands-on delivery, we help organisations drive real business value from their HR technology -- from advisory through implementation to ongoing managed services.

**Functional:** Access to experienced HRIS consultants across Ireland and the UK with deep configuration and go-live experience across Dayforce, Workday, UKG and HiBob. Advisory, implementation, optimisation and managed services -- all from one partner.

**Emotional:** Confidence that the platform you're investing in will actually be used. That someone who's been through complex transformations knows where the problems are -- and will stay until your people are genuinely using the system.

**Social:** The HR leader who chose the right partner, not just the biggest name. The one whose implementation went to plan and whose team are actually using the system six months later.

### Positioning
- **Category:** HRIS technology consulting -- system selection, implementation, optimisation, managed services, compliance readiness.
- **Audience:** HR Directors, CPOs and Heads of HR Technology at mid-market and enterprise organisations (500-5,000+ employees) selecting, implementing, struggling with or looking to optimise HR technology platforms.
- **Differentiator:** We're not a generalist consultancy that treats HRIS as a sub-project. Deep expertise across every major platform. 150 consultants. We stay through adoption, not just configuration. Big enough to scale with HR Path's 28-country network, small enough to know your project.
- **Statement:** For HR and technology leaders choosing an HRIS partner, Eaton Square is the specialist alternative to Big 4 consulting -- combining deep platform expertise with hands-on delivery and a commitment to adoption, backed by HR Path's global scale.

### Messaging pillars

**Pillar 1: Platform health and advisory**
- **Claim:** Your HRIS should be giving you clear insight into engagement, retention and productivity. For most organisations, it isn't. Poor data quality, inconsistent processes and weak governance mean the platform is a cost centre, not a strategic tool.
- **Proof:** Consulting sessions that assess people, process and technology together -- not just the system in isolation. Structured HRIS health checks that identify root-cause issues, prioritise fixes and build a roadmap. AI-enabled business process redesign across Dayforce, Workday, UKG and HiBob.
- **Contrast:** Vendors will run a system health check on their own platform. Generalist consultancies will audit your HR function but won't touch the technology. We assess both -- because the problem is almost always in the gap between them.

**Pillar 2: Implementation that delivers**
- **Claim:** Technology transformations fail when nobody plans for adoption. The system goes live, but your people don't use it -- and within six months, you're back to spreadsheets and workarounds. Many organisations also lack the internal capacity or experience to manage HRIS implementations effectively, leading to unclear requirements and weak project governance.
- **Proof:** Change and adoption experts embedded from day one, not bolted on at go-live. Client-side programme management that protects scope and business case. Deep implementation experience across Dayforce, Workday, UKG and HiBob. Principles: engage early, engage often, adhere ruthlessly to the business case.
- **Contrast:** Big 4 firms configure the system and hand you a manual. Boutiques lack the scale for enterprise rollouts. Vendors build the platform but won't own adoption. We act as your client-side partner -- bridging the gap between business needs and vendor delivery, and staying until your people actually use it.

**Pillar 3: Optimisation and ROI**
- **Claim:** Your HRIS was supposed to simplify things. Instead, it's expensive to run, difficult to support, and your teams have built workarounds everywhere. Processes aren't defined. Compliance is a risk. The original business case is a distant memory.
- **Proof:** Expertise across all major HRIS platforms -- not just one vendor's system. Root-cause assessments that go beyond configuration to examine processes, data quality and adoption. Managed services that keep systems optimised after go-live. Global HR Path delivery scale for multi-country operations.
- **Contrast:** Your vendor will support the software, not your business processes. A new implementation partner will want to start again from scratch. We fix what's broken -- people, process and technology -- and stay to make sure it holds.

**Pillar 4: Compliance readiness**
- **Claim:** EU Pay Transparency and the UK Employment Rights Act are coming. Most organisations haven't started assessing what this means for their systems, processes and reporting. By the time the deadline arrives, it will be too late to configure your way out of it.
- **Proof:** Advisory team that understands both the legislation and the technology. Readiness assessments that cover process, data and system configuration. Track record of helping organisations prepare for regulatory change -- not just advising on it, but configuring the system to deliver it.
- **Contrast:** Law firms can advise on the legislation but can't configure your system. Vendors will build compliance features but won't redesign your processes. We bridge both -- turning legislation into operational plans and operational plans into system configuration.

### Messaging hierarchy
- **Hero:** Technology Transformation isn't just about the Tech. Come talk to us about our approach to delivering a successful transformation.
- **Headline:** Deep HRIS expertise. Hands-on delivery. Dayforce, Workday, UKG, HiBob -- implemented, optimised and supported.
- **Tagline:** True partnership approach to HR technology.
- **Approved lines:** "Technology Transformation isn't just about the Tech." / "Both sides need to have the right expertise to succeed." / "Come talk to us about our approach." / "Deep payroll expertise and hands-on delivery." / "We believe we can add real value in an area that can be very complex for organisations."

---

## Service Line 2: Business Consulting

### Value proposition
**One-line:** Through deep HR and Finance advisory expertise, we help organisations develop strategies that are designed to transform, create organisations that are fit for purpose and optimise business processes that deliver efficiency.

**Functional:** Senior consultants who work side by side with you to set change strategy, identify and unblock resistance, and make change last. Strategy, organisation design, business process design, communications and change management -- all delivered by people who've done it before.

**Emotional:** Confidence in a partner that has experience implementing change that sticks. Not another report that gathers dust -- a team that works alongside yours until the change is embedded.

**Social:** The leader who brought in the right people to make transformation happen -- not just plan it. The one whose programme delivered because the change was designed around people, not imposed on them.

### Positioning
- **Category:** HR and business consulting -- strategy, organisation design, change management, programme delivery, process optimisation.
- **Audience:** HR Directors, CPOs, COOs and transformation leads at mid-market and enterprise organisations facing strategic change -- whether post-acquisition, digital transformation, regulatory compliance or organisation redesign.
- **Differentiator:** Traditional consulting can feel distant: armies of juniors, long reports, endless PowerPoints, but not much real change. At Eaton Square, you work directly with experienced advisors who partner from the outset -- not from the sideline.
- **Statement:** For high-stakes, multi-stream change -- from digital strategy to enterprise-wide transformation -- we put the right governance, tools, leadership and change management in place to keep delivery on track and make change stick.

### Messaging pillars

**Pillar 1: Strategy that keeps pace**
- **Claim:** The world has transformed with AI, but most organisations' strategy, internal processes, org design and ability to change have not kept pace. Many lack the resources, bandwidth or expertise to take an independent view on what needs to change and where to start.
- **Proof:** HR and Finance function health checks that assess priority areas and actions. Consulting sessions that deliver data with root-cause issues, prioritised fixes and a roadmap to improve key metrics. Strategy development across corporate, digital, HR and Finance.
- **Contrast:** Strategy firms deliver recommendations and leave. We develop the strategy and stay to implement it -- because a strategy nobody executes is just a document.

**Pillar 2: Programme delivery that lands**
- **Claim:** Transformation programmes are hard and too often fail to deliver business outcomes because the impact of change on people isn't considered. Implementation without change management is just installation.
- **Proof:** Programme assessments that identify key risks to success -- change readiness, governance and programme management. Deep expertise in what great strategy looks like and what it takes to actually deliver it. Client-side programme management across the full spectrum.
- **Contrast:** Generalist consultancies advise from a distance. Pure project managers track milestones without understanding the content. We embed alongside your team -- we understand both the strategy and the delivery reality.

**Pillar 3: Process optimisation**
- **Claim:** Organisations need new ways to optimise HR and Finance processes and ensure compliance against a backdrop of change, including legislative change like EU Pay Transparency. AI-enabled solutions can help but feel inaccessible and complex.
- **Proof:** AI-enabled solutions that are easy to use and deploy. 'AI in a box' modules including performance management and EU Pay Transparency that allow organisations to scale using ready-made templates. Additional change and communications support to ensure adoption.
- **Contrast:** Technology vendors sell AI features. Management consultancies write AI strategies. We deploy practical, ready-to-use AI solutions and support your people through the change -- not just the technology.

**Pillar 4: Senior delivery, not junior armies**
- **Claim:** You need experienced advisors who work alongside you, not armies of juniors writing reports that gather dust. The people you meet at the pitch should be the people who work on your project.
- **Proof:** Named senior project leads who partner from the outset. Client portfolio of mid-market organisations who chose Eaton over bigger firms and got better outcomes. 150 consultants with deep domain expertise, not generalists learning on the job.
- **Contrast:** Big 4 sell methodology and brand. They staff with juniors and rotate them. Boutiques lack scale for complex programmes. Eaton's team knows your problem and stays on your project.

### Messaging hierarchy
- **Hero:** Change that sticks -- because we stay until it does, not just until the report is written.
- **Headline:** Strategy, change management and programme delivery. Senior consultants who work alongside you, not from the sideline.
- **Tagline:** Where mid-market meets enterprise capability.
- **Approved lines:** "We provide the structure, experience, and day-to-day oversight that keep projects moving." / "Not just about the latest in HCM technology, but about the challenges organisations face in managing change." / "Come talk to us about what you're facing."

---

## Service Line 3: Talent Management

### Value proposition
**One-line:** We help organisations access the right people, in the right way, at the right time -- whether that's executive search, flexible staffing, or compliant global hiring through EOR.

**Functional:** Recruitment and executive search that builds high-performing, scalable hiring processes. Flexible staffing through secondments and specialist interim resources. Employer of Record services for compliant global expansion.

**Emotional:** Confidence that you can move fast on talent without the risk. That someone understands both the urgency and the compliance reality -- and can deliver the right person, not just a CV.

**Social:** The leader who built a team that performs -- because the hiring process was designed to find the right people, not just fill seats.

### Positioning
- **Category:** Talent management -- executive search, recruitment, flexible staffing, secondments, Employer of Record, RPO.
- **Audience:** HR Directors, CPOs, COOs and CFOs at mid-market and enterprise organisations facing talent shortages, global expansion, or transformation programmes that need specialist resource.
- **Differentiator:** Unified suite of people-focused solutions under one partner: recruitment, executive search, secondments, flexible staffing and EOR. Not a recruitment agency that stops at the placement -- we understand the organisational context.
- **Statement:** For organisations that need the right talent, in the right structure, at the right time -- Eaton Square provides recruitment, flexible staffing and global hiring solutions that combine speed with compliance and organisational understanding.

### Messaging pillars

**Pillar 1: Recruitment that actually works**
- **Claim:** Hiring has become one of the most complex and high-risk challenges facing organisations today. Most recruitment processes haven't kept pace. AI tools promise speed but often create blind spots around culture and fit.
- **Proof:** Structured, data-driven assessments combined with meaningful human engagement. Recruitment health checks and playbooks. Executive search across senior HR, Finance and Technology roles. Hiring journeys that are fair, efficient and aligned to your culture.
- **Contrast:** Recruitment agencies fill roles. Internal teams are overwhelmed. AI screening tools miss nuance. We build the process that consistently finds the right people -- not just the available ones.

**Pillar 2: Global hiring without the risk**
- **Claim:** Expansion into new markets is being slowed by compliance risks, payroll complexity and the cost of establishing entities before proving business viability. Without the right structure, companies risk non-compliance, fines and slower market entry.
- **Proof:** Employer of Record solution that allows organisations to hire talent in new markets in days, not months. Managed payroll, compliance, contracts, benefits and local employment obligations. Operational in multiple jurisdictions.
- **Contrast:** Setting up a local entity takes months and costs before you've proved the market. Freelance arrangements create compliance risk. Our EOR solution gives you compliant, turnkey hiring in new markets -- fast.

**Pillar 3: Flexible workforce**
- **Claim:** Talent shortages, unpredictable resourcing needs and tightening budgets -- all while trying to deliver critical transformation and growth programmes. Leaders are stuck between hiring freezes and operational pressure when the work still needs to get done.
- **Proof:** Seconded professionals who integrate seamlessly and deliver quickly. Senior interim resources -- CIO, CFO, CPO, CEO level. Fractional executives. Fully managed finance and project teams. Cost models that compare FTEs, secondees and contractors.
- **Contrast:** Contractors cost more and leave when the rate drops. Permanent hires take months and commit you to headcount. Secondments give you specialist talent, embedded in your team, with total flexibility.

**Pillar 4: Unified talent partner**
- **Claim:** Most organisations use different providers for recruitment, interim staffing, EOR and executive search -- each with their own process, pricing and blind spots. The result is fragmented talent acquisition with no joined-up view.
- **Proof:** Recruitment, executive search, secondments, flexible staffing and EOR -- all from one partner who understands your organisation. One relationship, one view of your talent needs, consistent quality across every engagement.
- **Contrast:** Recruitment agencies don't do EOR. EOR providers don't understand your organisation. Staffing firms don't do executive search. We do all of it -- because talent is one problem, not four.

### Messaging hierarchy
- **Hero:** The right people, in the right way, at the right time. Recruitment, flexible staffing and global hiring -- all from one partner.
- **Headline:** Executive search. Secondments. EOR. Recruitment. One partner for every talent need.
- **Tagline:** Access the right talent, without the risk.
- **Approved lines:** "We help organisations access the right people, in the right way, at the right time." / "Come talk to us about your talent challenges." / "Whether you need interim resources for project delivery or transformation, we provide the right talent, right now."

---

## Service Line 4: Finance Transformation

### Value proposition
**One-line:** We help CFOs and Finance leaders diagnose finance performance issues, build a defensible business case for change, and deliver finance transformation with confidence -- from health check through implementation to ongoing managed services.

**Functional:** Finance systems health checks and value assessments. Technical project management and configuration across major finance platforms. Training, optimisation, change management and application managed services -- all finance-led, not IT-led.

**Emotional:** Confidence that your finance transformation will deliver the insight, control and efficiency the business case promised. That someone understands finance operations, not just the technology.

**Social:** The CFO who modernised finance operations and can show the board real ROI -- not just a new system, but better decisions, faster closes and reliable reporting.

### Positioning
- **Category:** Finance technology consulting -- system selection, implementation, optimisation, managed services, AI-enabled finance operations.
- **Audience:** CFOs, Finance Directors, Heads of Finance Technology at mid-market and enterprise organisations -- especially those facing PE scrutiny, IPO preparation, audit pressure or acquisitions that require finance system consolidation.
- **Differentiator:** Finance-led delivery, not IT-led. We understand the CFO's priorities -- close cycles, reporting accuracy, compliance, cost of ownership -- and work backwards from there. Combined advisory and technical capability means one partner from health check through managed services.
- **Statement:** For finance leaders choosing a transformation partner, Eaton Square combines deep finance advisory expertise with technical implementation capability -- ensuring your investment delivers business value, not just a new platform.

### Messaging pillars

**Pillar 1: Finance insight and readiness**
- **Claim:** Finance leaders lack timely, reliable insight. Close cycles are slow, reporting is manual, and finance processes don't scale as organisations grow, acquire, or prepare for audit, PE scrutiny or IPO. Poor data quality and inconsistent processes block decision-making and value creation.
- **Proof:** Structured Finance Systems Health Check and Value Assessment that identifies root-cause issues across people, process, data and technology. Prioritised fixes and a clear transformation roadmap. CFO-level advisory that speaks finance language, not technology language.
- **Contrast:** Technology vendors assess their own platform. Audit firms identify risk but don't fix the systems. We diagnose the full picture -- people, process, data and technology -- and build the business case for change.

**Pillar 2: Transformation that delivers value**
- **Claim:** Finance transformations are complex and frequently fail to deliver promised outcomes. Poor adoption, weak process design, unclear ownership and a focus on configuration rather than business value mean the investment doesn't pay back.
- **Proof:** Finance-led delivery that combines technical excellence with strong programme governance. Embedded change management and role-based training. Enterprise business process design that ensures the system supports how finance actually works. Relentless focus on value realisation.
- **Contrast:** Technology partners configure the system and hand it over. Management consultancies design the operating model but won't touch the platform. We do both -- design and build, then stay through adoption.

**Pillar 3: Ongoing operations and ROI**
- **Claim:** Finance systems are expensive to run, difficult to support and fail to deliver ongoing value. Manual workarounds persist after go-live. Adoption drops. Optimisation stalls. Finance teams struggle to demonstrate ROI while managing risk and compliance.
- **Proof:** AI-enabled finance-led managed services that go beyond support. Proactive issue detection, continuous optimisation and CFO-level insight and value realisation reporting. Release and change management. Adoption and usage monitoring.
- **Contrast:** Vendors support the software. Outsourced teams follow tickets. We provide managed services that continuously optimise, improve adoption and deliver executive-level insight -- not just keep the lights on.

**Pillar 4: AI-accelerated finance operations**
- **Claim:** AI has the potential to transform finance operations -- faster diagnostics, better benchmarking, smarter scenario modelling. But most finance teams don't know where to start, and generic AI tools don't understand finance processes.
- **Proof:** AI accelerates diagnostics, benchmarking and scenario modelling to support faster, evidence-based CFO decision-making. AI enables proactive issue detection, continuous optimisation and executive-level insight within managed services. Consultants remain accountable for outcomes -- AI is the tool, not the answer.
- **Contrast:** AI vendors sell platforms. Consultancies write AI strategies. We deploy AI where it makes finance faster and smarter -- with consultants who understand what the numbers need to do.

### Messaging hierarchy
- **Hero:** Finance transformation that delivers real business value -- because we understand finance, not just the technology.
- **Headline:** Finance systems advisory, implementation and managed services. Finance-led delivery from health check to ongoing optimisation.
- **Tagline:** Finance-led transformation. Real business value.
- **Approved lines:** "Come talk to us about your finance transformation challenges." / "We help CFOs diagnose, transform and optimise." / "Finance-led, not IT-led."

---

## Service Line 5: Transformation and Technology Advisory

### Value proposition
**One-line:** We help mid-sized organisations unlock real value from technology -- focusing on HR, Finance and operational efficiency, not experimental tech. From Microsoft optimisation to process automation, we turn technology investment into measurable business improvement.

**Functional:** Transformation advisory, process automation, Microsoft CSP licensing, Power BI dashboard insights, solution implementation and optimisation. Technical project management and application managed services. Business-led transformation, not IT-led.

**Emotional:** Confidence that your technology investment will deliver measurable results -- in weeks, not years. That someone understands your operational reality and will implement solutions that your people will actually use.

**Social:** The leader who got measurable efficiency gains from technology that's already in the building -- not by buying something new, but by using what they have properly.

### Positioning
- **Category:** Digital and technology advisory -- transformation advisory, process automation, Microsoft technology, data transformation, managed services.
- **Audience:** CIOs, COOs, CFOs and HR Directors at mid-sized organisations looking to get more value from existing technology investments, automate manual processes or undertake business-led digital transformation.
- **Differentiator:** Business-led, not technology-led. We start with the operational problem, not the platform. Practical solutions that deliver measurable efficiency in weeks, not multi-year transformation programmes. Microsoft expertise combined with deep understanding of HR, Finance and operational processes.
- **Statement:** For organisations looking to unlock value from technology, Eaton Square combines practical technology expertise with deep understanding of HR, Finance and operational processes -- delivering measurable efficiency gains, not just IT projects.

### Messaging pillars

**Pillar 1: Microsoft value realisation**
- **Claim:** Organisations struggle to realise the full value of their Microsoft investment because they lack the expertise and strategic focus to apply it to real business priorities. Instead of driving measurable improvements in HR, Finance and operational efficiency, many initiatives remain fragmented or overly technical.
- **Proof:** Consulting sessions focused on operational needs enabled through optimisation of appropriate technology. Microsoft CSP licensing. Power BI dashboard insights. Solution implementation and optimisation across the Microsoft stack.
- **Contrast:** Microsoft partners sell licences and configuration. Consultancies write digital strategies. We focus on what the technology needs to do for your business -- HR, Finance and operations -- and make it work.

**Pillar 2: Operating model transformation**
- **Claim:** Organisations are held back by outdated operating models, inefficient processes and disconnected systems. Even when transformation is identified, it fails to translate into real change because redesign isn't paired with practical digital implementation.
- **Proof:** Define and implement operating models that embrace process automation and transformation. Transformation advisory combined with technical implementation. Not just redesign -- we build the digital solutions that make the change real.
- **Contrast:** Management consultancies redesign operating models on paper. Technology firms implement without understanding the business context. We do both -- redesign and implement -- because one without the other doesn't deliver.

**Pillar 3: Process automation**
- **Claim:** Manual, time-consuming processes are draining productivity, increasing operational risk and preventing teams from focusing on higher-value work. Transformation efforts are often slow, complex and deliver benefits only over long timeframes.
- **Proof:** Process automation in the cloud with rapid activation. Measurable efficiency gains in weeks, not years. Microsoft Power Automation and Cloudmersive Automation. Practical solutions deployed against specific operational pain points.
- **Contrast:** RPA vendors sell automation platforms that take months to configure. Consultancies scope multi-year programmes. We eliminate specific manual processes and deliver measurable results fast.

**Pillar 4: Managed technology services**
- **Claim:** After go-live, technology needs ongoing attention -- release management, continuous optimisation, licence management and user support. Most organisations either overspend on internal resource or under-invest and watch adoption drop.
- **Proof:** Application managed services covering platform support, stability, release and change management, continuous optimisation and licence renewal and optimisation. Proactive, not reactive.
- **Contrast:** Break-fix support keeps the lights on. Internal teams get pulled onto projects. We provide managed services that continuously improve, not just maintain.

### Messaging hierarchy
- **Hero:** Technology that delivers measurable business improvement -- because we start with your problem, not the platform.
- **Headline:** Transformation advisory. Process automation. Microsoft optimisation. Measurable results in weeks, not years.
- **Tagline:** Business-led technology. Measurable results.
- **Approved lines:** "We help organisations unlock value from Microsoft Technology -- focusing on HR, Finance and operational efficiency." / "We help organisations eliminate manual, error-prone processes using technology, delivering measurable efficiency gains in weeks, not years." / "Come talk to us about what technology could do for your operations."

---

## Voice and tone (applies across all service lines)

**Summary:** Professional, practical, credible. Warm when appropriate but always grounded in real outcomes. Knowledgeable peer, not corporate consultancy. Sean names people, credits colleagues, invites conversation rather than selling. His tone is direct and honest -- he acknowledges complexity ("can be a bumpy road") rather than overselling. Uses "we" naturally. "Delighted" is his ceiling for positive emotion.

**Writing principles:** Practical over theoretical. Evidence over claims. Client outcomes over firm credentials. Straightforward language -- no consulting jargon. Always name the people involved. Invite conversation ("come talk to us", "please reach out") rather than hard-selling. Show the work, not the methodology diagram. When sharing results, be specific -- name the platform, the outcome, the person.

**Never use:** Game-changing, world-class, cutting-edge, innovative, disruptive, leveraging, synergy, holistic, best-in-class. Never "I'm thrilled", "So excited", "Honoured to", "Humbled by". No buzzword stacking. No hype words. No performative emotion.

**Never do:** Lead with methodology over outcomes. Hide behind the HR Path brand instead of earning trust as Eaton Square. Use stock photography of diverse boardrooms. Promise transformation without specifics. Stack buzzwords. Make claims without naming a real project, person or outcome. Use "I" when "we" is more natural.
