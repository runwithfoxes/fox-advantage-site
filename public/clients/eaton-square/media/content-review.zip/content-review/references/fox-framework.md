# Fox Framework: Post Strategy

The content creator uses this framework in reverse -- start from the goal, build backwards.

## 5 Strategic Goals

| Goal | Purpose | Preview Strategy |
|---|---|---|
| 1. Salience | Build mental availability. Be remembered. | Memorable phrases, sticky metaphors > tactical advice |
| 2. Get Talked About | Spark conversation, debate, shares. | Debate-framing, polarising ideas, "hard truths" early |
| 3. Value Add | Deliver practical utility. Build trust. | Front-load utility. Don't hide tips behind "...more" |
| 4. Authority Build | Establish unique POV. Original thinking. | Preview the insight, not just a vague tease |
| 5. Strategic CTA | Drive specific action. | Preview a tangible benefit that justifies acting |

## Core Laws

1. The preview is the ad for the ad. If the truncated preview fails, nothing else matters.
2. Vulnerability is the value, not just a setup. In emotional posts, the human moment IS the product.
3. If it's unclear what the post wants me to think, feel, or do -- it fails.
4. Authority isn't built with mystery. Preview the logic, don't hide it.

## How to use this

1. **Choose the goal** based on what type hasn't been served recently
2. **Choose the format** that best serves that goal
3. **Write the truncated preview FIRST** using the goal-specific strategy above
4. **Build the rest** around the preview
5. **Score the draft** before delivering

## Scoring

- Goal Clarity: /20
- Preview Effectiveness: /30 (heaviest weight)
- Visual Alignment: /20
- Execution Quality: /20
- Brand Distinctiveness: /10

85-100: high-performing. 65-84: decent with friction. Below 65: strategic gaps.

## Red flags

- Visual-message mismatch
- Trying to serve multiple goals simultaneously
- Unsupported bold claims
- Wrong preview strategy for the goal type
- Giving away the answer before the fold (for Authority/Get Talked About)
- Generic content that could come from anyone
