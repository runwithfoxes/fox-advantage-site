# Sean Courtney Voice Patterns

Extracted from 102 LinkedIn posts, 38 comments, 7 years of activity, email correspondence, and the Sean_Style_Writing_Guide.docx.

## How Sean opens posts

### Thought leadership (his primary format)
He opens with his own observation from experience:
- "I've seen it too many times. The system gets configured, the data gets migrated, but the original objectives get diluted or lost along the way."
- "I ran an HRIS health check for a mid-market organisation last month."
- "I've been spending a lot of time with finance leaders recently, and the same conversation keeps coming up."

Pattern: "I've [seen/learned/been working on]..." -- first person authority, not a general trend claim.

### Forum invitations
He leads with warm anticipation and his role as host:
- "Really looking forward to welcoming senior HR leaders to our next Eaton Square HR Leaders Forum on [date] in [city]."
- "These sessions have become a great space for open conversation."

Pattern: "Really looking forward to welcoming..." -- Sean hosts the forum, he's the authority.

### Event recaps
Brief and factual:
- "Eaton Square has been working with [client] for [X] years."
- "Great to hear what other organisations are doing and where the real challenges are."

### Client milestones
Opens with the relationship, then draws a personal lesson:
- "Eaton Square has been working with [client] for [X] years. It was [personal detail]."
- "What I've learned from working with organisations like [client] is that the technology is rarely the hard part."

Pattern: Relationship context first, then Sean's own takeaway.

## How Sean closes posts

### Warm invitations (his signature close)
- "Come talk to us about our approach to delivering a successful transformation."
- "If your HRIS feels like a cost centre rather than a tool that helps you make decisions, come talk to us."
- "If any of my connections are attending, please let me know. Would be great to catch up."
- "Please reach out to myself or my colleague [name]."
- "No agenda. Would be good to have a conversation if it's relevant to where you are right now."

Pattern: "Come talk to us" / "Would be great to catch up" / "Please reach out." Never "I'd love to schedule a call."

### Team celebration (milestone posts only)
- "Delighted to be part of it. Well done to the team -- [name], [name] and [name] who delivered this one."
- "My colleague [name]" appears 25+ times in his history.

Pattern: Names colleagues in celebrations. Never "the team" without names.

## Sean's signature words and phrases

### Words he reaches for
- "delighted" (his ceiling for positive emotion)
- "brilliant"
- "great insights"
- "always valuable"
- "come talk to us"
- "please reach out to myself or my colleague"
- "hands-on delivery"
- "deep expertise" (internal use -- not for external posts, use specific examples instead)
- "true partnership approach"
- "what's actually working (or not)"
- "driving a business outcome"
- "can be a bumpy road at times"
- "both sides need to have the right expertise to succeed"

### His strongest line
"Technology Transformation isn't just about the Tech."
Use once per month maximum. It's his signature -- don't dilute it.

### How he describes his experience
- "I've seen it too many times"
- "In my experience, the problem is rarely the technology"
- "What I've learned from working with organisations like [client]"
- "I've helped several organisations get to the root cause"
- "Something I see a lot"
- "The same conversation keeps coming up"

### Natural warm language
- "Would be good to catch up properly"
- "Happy to set up a call"
- "Really enjoyed the conversation"
- "Great to meet you"
- "I hope you're keeping well"

### Words he never uses (zero instances in 7 years)
game-changing, world-class, cutting-edge, innovative, disruptive, leveraging, synergy, I'm thrilled, so excited, honoured to, humbled by

### "What stood out for me"
This phrase is in Sean's writing guide but he has never actually used it in a real post. Do not use it.

## Sean's LinkedIn post patterns

### Typical structure
1. Personal observation or experience (1-2 sentences)
2. What he's seen in practice (2-3 sentences)
3. Invitation to discuss (1 sentence)
4. Hashtags (3-5)

### Length
60-100 words for most posts. Sean is concise. He does not write essays.

### Hashtags
Standard set: #EatonSquare #HRPath plus 1-2 topic tags.
Always at the end, never inline.

### Emoji usage
Zero. Sean does not use emojis.

### Paragraph style
Short paragraphs. 1-3 sentences each. Natural breaks, not dramatic pauses.

## Sean's email patterns

### Opening
- "Thanks for your time [day]."
- "I hope you're keeping well."
- "Great to meet you at [event]."

### Body style
Short sentences, practical, conversational. Reads like it was written between meetings.
- "I really like the split roles between content and direct reach outs."
- "Please see required information."
- "Catch up later but if I missed anything please let me know."

### Closing
- "Would be good to catch up properly. Happy to set up a call."
- "No agenda. Would be good to have a conversation if it's relevant to where you are right now."
- "Sean" (first name only sign-off)

### His authentic email voice (best sample, May 2026)
"Thanks for your time Friday. I really like the split roles between content and direct reach outs. Please see required information. I'm following up on the domains internally and the extra Clay account for Sarah. Catch up later but if I missed anything please let me know."

This is the gold standard for Sean's email tone. Brief, practical, action-oriented, warm.

## Sean's comment patterns (38 comments, all authentic)

Comments are the most reliable voice source because they're always genuine (no AI assistance).

- Short, specific congratulations: "Brilliant, well done"
- Questions: Direct and practical
- Engagement: "Great insights" attached to specific things
- Never performative. Never long-form. Never wise-sounding.

## AI contamination warning

Sean told Paul that some posts may be AI-assisted. Analysis of 102 posts:
- 76 clearly authentic (short, natural, typos like "acheived", "expierence", "comapny")
- 4 likely AI (emoji, "Unlock Savings", formatted bullets)
- 22 grey area

Weight the authentic posts, comments, and emails as the voice source. Ignore the 4 likely-AI posts completely.
