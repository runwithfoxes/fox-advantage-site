---
name: content-calendar
description: Eaton Square content calendar builder. Takes raw material from Sean, Sarah or Ben and builds a complete content calendar with all posts written - what to create, when, for whom, in what format, and why. Use when someone says 'build a content calendar', 'plan this month's content', or drops source material and asks for a plan.
---

# Eaton Content Calendar Builder

Takes raw material from Sean, Sarah, or Ben and builds a complete content calendar with all posts written. This is the strategist skill -- it decides what to create, when, for whom, in what format, and why.

Use when someone says "build me a content calendar", "plan this month's content", "here's Sean's material", "here's raw material for the team", or drops a body of source content and asks for a content plan.

## Before building anything

1. Read `references/content-strategy.md` -- cadence, formats, pillar rotation, benchmarks
2. Read `references/fox-framework.md` -- the 5 strategic goals
3. Read `references/messaging-framework.md` -- Eaton's 5 service lines and messaging pillars
4. Read all three voice specs: `references/sean-voice.md`, `references/sarah-voice.md`, `references/ben-voice.md`

## Step 1: Ingest the raw material

Read everything the user provides. This could be:
- Sean's blueprints and long-form content
- Sarah's post examples and event recaps
- Ben's outbound sequences and campaign copy
- Case studies, client wins, industry reports
- A mix of all of the above

## Step 2: Mine for post-worthy angles

Extract every discrete angle that could become a LinkedIn post:

- **Stats and data points** -- specific numbers, benchmarks, research findings
- **Observations and patterns** -- "what we're seeing" themes that repeat
- **Diagnostic questions** -- questions that make the reader think about their own situation
- **Proof points** -- client situations (anonymised), before/after outcomes, go-live milestones
- **Contrarian insights** -- things that challenge the expected view
- **Frameworks** -- step-by-step processes, assessment models, decision trees
- **Quotable lines** -- phrases that stand alone as thought leadership

For each angle, note:
- Which voice it belongs to (Sean, Sarah, or Ben)
- Which service line it serves
- Which strategic goal it fits best
- Which format suits it (text, carousel, article)

## Step 3: Build the calendar

### Cadence rules
- 2-3 posts per person per week (6-9 total per week)
- Stagger across the week -- no two voices on the same day
- Best days: Tue-Thu. Best times: 7-8am and 12-1pm local
- Space posts 24+ hours apart

### Voice assignment
- **Sean (MD):** Authority Build, industry POV, thought leadership, deep frameworks. Tue/Thu.
- **Sarah (Director):** Proof, case studies, relational posts, event recaps, talent topics. Mon/Wed.
- **Ben (BD Lead):** Engagement, sector commentary, observation-led posts, practical. Wed/Fri.

### Pillar rotation
- Rotate one service line per week to build algorithmic topic authority
- Map to buyer problems, not service descriptions
- 4:1:1 pacing: 4 educational/insight pieces, 1 case study, 1 CTA

### Format mix per week (across all voices)
- 2 carousels (best for frameworks, case study teardowns)
- 4 text posts (observations, POV, personal stories)
- 1 multi-image or single image
- 1 article every 2-3 weeks (deep evergreen thought leadership)
- Polls: max 1 every 2 weeks, audience research only

### Strategic goal rotation
Use the Fox Framework to ensure variety:
- Not all Value Add -- mix in Authority Build and Get Talked About
- At least 1 case study per voice per week (Proof)
- Sean carries most Authority Build posts
- Ben carries most Engagement posts

## Step 4: Write all the content

For each calendar slot, write the complete post:

1. **Decide the goal** from the Fox Framework
2. **Write the truncated preview first** -- goal-specific strategy
3. **Write the full post** in the assigned voice
4. **Run the quality checklist** for that voice

Follow these rules from the voice specs:
- Sean: first-person authority, 60-100 words, "Come talk to us" close
- Sarah: warm, relational, names people, "Happy to share more" close
- Ben: observation-led, 80-120 words, "Happy to share more if useful" close

### For carousels
- 7 slides, 1080x1350px, under 30 words per slide
- Provide the text content per slide (not visual design)
- Structure: Cover Hook > Problem > 3 Value Points > Summary > CTA

### For articles
- 800-2,000 words in the assigned voice
- Evidence-before-opinion
- [Placeholder] brackets for unverified claims

## Step 5: Present the calendar

Output as a structured table:

| Week | Day | Voice | Topic | Format | Goal | Service Line |
|------|-----|-------|-------|--------|------|-------------|

Then present each post in full, grouped by week.

For each post, show:
- The strategic goal
- The format
- The truncated preview (highlighted)
- The full post content
- Fox Framework score

## Step 6: Repurposing suggestions

After the calendar, suggest how to extend the content:
- Which posts could be atomised further (carousel → 3 text posts)
- Which article could become a newsletter edition
- Which observation post could be reframed as a poll
- Which case study could be expanded into a full carousel teardown

## Anti-fabrication

Never invent stats, client names, outcomes, or quotes. If source material doesn't contain a proof point, use [placeholder] brackets and note what's needed. Read `references/anti-fabrication.md` for the full rules.

## AI detection

Every piece of content must pass implicit AI detection checks:
- Vary sentence length (no three consecutive sentences within 5 words of each other)
- Cut transitional scaffolding ("Furthermore", "Additionally", "Moreover")
- Use concrete, surprising words over predictable ones
- Let structure follow the argument, not a template
- Include at least one thing per piece that couldn't have been predicted from the brief
