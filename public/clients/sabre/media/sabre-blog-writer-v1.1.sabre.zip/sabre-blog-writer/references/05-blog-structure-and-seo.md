# 05 - Blog structure, scannability, and SEO

The containers a Sabre blog post fills, the rules that keep it readable on a screen, and the light-touch SEO that helps it get found without bending the writing out of shape. Copy is written to fit these, not the other way round.

> The single highest-leverage line in the whole piece is the **title**. Most people who see it never read past it. Write it last, write it five ways, pick the one that's specific and true. Everything else supports it.

---

## The structural blocks (in order)

Every Sabre post is built from these. Not every post uses every block, but the order holds.

| Block | Rule |
|---|---|
| **Title (H1)** | One per post. Sentence case (our rule, always). Specific over clever. 50 - 60 characters is the SEO sweet spot but never pad or truncate a good title to hit it. The promise, not the topic. |
| **Standfirst / dek** | One or two sentences under the title that say what the reader will get and why it's worth their time. Does not repeat the title. This is the "should I read this" decision. |
| **Intro** | First 2 - 3 sentences. The hook lands here, and the payoff comes early - don't bury the point under throat-clearing. A reader decides in the first paragraph. |
| **Subheads (H2 / H3)** | Break the body every 200 - 300 words. Each subhead is a real signpost a skimmer could read alone and still follow the argument. Sentence case. Descriptive, not cute ("How offer-and-order actually works", not "The plot thickens"). |
| **Body paragraphs** | Short. 2 - 4 sentences. One idea each. White space is a feature, not a gap. Vary length deliberately (see the AI-rhythm rules). |
| **Lists** | Only for 3+ genuinely parallel items, each with substance. Never a list as decoration. |
| **Pull quote / callout** | Optional. One per post at most, to surface the single sharpest line. Earns attention; don't overuse. |
| **CTA** | One primary action at the end, benefit-led, carrying the → arrow (the Sabre pattern). "Explore your retailing shift →", "Read the full report →". Never "learn more". |

---

## Title mechanics (the highest-leverage copy)

The title does three jobs at once: it earns the click, it sets the expectation, and it carries the search term if there is one. Hold all three.

- **Specific beats clever.** "What modern airline retailing actually means" beats "The future is now".
- **Lead with the value or the tension.** A number, a contrarian read, a clear promise.
- **Sentence case only.** Title Case reads as template and as a tell.
- **No clickbait the body can't pay off.** If the title promises a number, the body delivers it.
- **Front-load the search term** if there's a real one, but never at the cost of the writing. A title that ranks and reads badly loses the reader you fought to get.

Write the title last, after the piece exists, when you know what it actually delivers. Generate five, pick one, say in the evidence panel which you picked and why.

---

## Length, by type

Length is set by the type (see `03-blog-types.md`) and the reader's awareness, not by a target. The ranges:

| Shape | Words | When |
|---|---|---|
| **Short** | 400 - 700 | News reaction, tight recap, single-finding insight |
| **Standard** | 700 - 1,100 | Explainer, product, case study, practical guide |
| **Long** | 1,100 - 1,500 | POV, trend analysis, anything building a real argument |

Past ~1,500 words a B2B post loses most readers and starts accumulating the statistical patterns detectors read for (see slop audit item 9). If the material genuinely needs more, it's probably a two-part series, not one long post. Length is earned by substance, never padded to look authoritative.

---

## Scannability (write for the screen)

Senior readers skim before they commit. The piece has to survive a skim and reward a read.

- **The skim test:** read only the title, standfirst, and subheads. Do they tell the whole argument? If not, the subheads aren't pulling their weight.
- **Front-load every section.** The point of a paragraph comes in its first sentence, not its last.
- **One idea per paragraph.** Two ideas means two paragraphs.
- **White space is structure.** Short paragraphs, room to breathe. Crowded text reads cheap and goes unread.
- **Bold sparingly.** One key phrase per section at most. Bold on every line is noise.

---

## SEO, light touch (help it get found, never bend the writing)

SEO serves the reader; it never overrides the voice or the slop rules. The order of priority is always: real, specific, well-written first; discoverable second.

- **One primary search term** if there's a natural one. Put it in the title, the first paragraph, and one subhead. That's enough. Keyword stuffing is both a slop tell and a ranking penalty now.
- **Write the standfirst as the meta description** too: one or two sentences, ~150 characters, that say what the piece delivers. It doubles as the search snippet.
- **Descriptive subheads** help both the skimmer and the search engine. A subhead that names the thing ("How agentic AI handles real operational work") works twice.
- **Link to the real source** when citing a stat or report (the full report, the study). Honest sourcing is good for trust and good for ranking.
- **Never** invent a keyword-driven angle the piece can't honestly deliver, write "in today's fast-paced travel industry" to seed a term, or stack synonyms for the algorithm. Every one of those is in the slop audit for a reason.

If SEO and the writing ever pull against each other, the writing wins. A post that ranks and reads like a robot converts nobody.

---

## Brand facts (for any rendered or designed output)

These rarely affect the words but matter if the skill ever helps spec the visual:

- **Primary accent:** Terracotta `#E2553C`. Solid colors only - no gradients, no drop shadows, no rounded corners, no glow. Sabre is clean and flat.
- **Backgrounds:** off-white/beige `#F3EFE4`, black `#000000`, terracotta.
- **Typeface:** APK Galeria (Semi-Bold for headlines, regular for body); Arial fallback.
- **CTA buttons:** terracotta, square corners (no rounded corners - brand rule), label + → arrow.
- **Imagery:** cinematic, motion-blur, travel scenes (the brand photography style).

---

## What this means for the writer (practical)

1. Write the **title last**, five ways, sentence case, specific and payable.
2. Open with a **standfirst** that earns the read and doubles as the meta description.
3. **Front-load** the intro and every section. The point comes first.
4. **Subhead every 200 - 300 words** with real signposts that pass the skim test.
5. Keep paragraphs **short, one idea each, varied in length**.
6. End on **one benefit-led CTA** with the → arrow.
7. Treat SEO as a light layer: one term, placed naturally, never at the cost of the voice.
