# 04 - Positioning spine: staying on strategy

> Shared Sabre writing core. The strategy hierarchy and content gate apply to every channel.

> **Purpose.** This reference ensures every Sabre piece inherits from positioning and never fabricates its way to sounding strategic. Load before drafting any post.

---

## 1. The strategy hierarchy

Copy does not invent strategy. It inherits from the layers above it, in strict order:

```
Positioning (received, never rewritten)
    ↓
Messaging (Value Themes → One-Liner → Elevator Pitch → 100-word → 500-word)
    ↓
Copy (the post)
```

**If approved messaging exists:** draw from it. The post is a direct expression of that messaging.

**If approved messaging does not exist:** work directly from positioning and flag every output as a draft. Do not proceed as if messaging were settled.

**Upstream of all three sits the brief.** The brief must commit three things before a word is written:
1. A commercial outcome (what changes if this post works)
2. An audience trigger moment (the specific context in which the reader is receiving this)
3. An influence model (Direct Response or Salience - see section 2, point 5)

Without a brief, there is no post. There is only copy shaped like a post.

---

## 2. The 5 inheritances - what every Sabre piece must carry

If any of the five is missing, the post is writing to nobody. Check all five before drafting.

### 1. The competitive frame
Which alternative is this post displacing?
- **Do nothing** - inertia is the enemy; the cost of standing still is the argument
- **Build in-house** - proprietary complexity vs. open modular platform
- **A legacy incumbent or named competitor** (e.g., Outpayce, Amadeus) - specific functional gaps are the argument

The brief must name one. The argument changes entirely depending on which is live in the reader's world. A post that doesn't know which alternative it's displacing has no position to hold.

### 2. The audience trigger moment - not just the audience
Not "travel agencies." A moment: "agencies comparing payment partners at ITB" or "agencies whose payout rebate strategy is being renegotiated."

Insight is a moment, not a demographic. The trigger moment is the source material for the opening line's relevance. Without it, the opening line is generic and the reader does not feel seen.

### 3. One value theme only
Pick one theme from the positioning canvas, matched to the buyer's primary pain. The messaging may carry two to four themes; a post collapses to one. Writing to two themes simultaneously is writing to nobody in particular.

The chosen theme must be traceable to a unique attribute from the positioning - not something any competitor could claim.

### 4. Proof that belongs to that theme
Not generic credibility ("60 years in travel"). The specific proof that belongs to the chosen value theme. Using the wrong proof for the chosen theme is a mismatch the buyer feels even if they can't name it.

**Never cross proof and theme.** Each theme has its own proof. Use the matching one. (See the Mosaic table in section 3.)

### 5. A single, specific action - never "learn more"
Commit to one influence model before writing:
- **Direct Response:** books a demo or a call. Use when the reader is Solution Aware or Most Aware, and on later touches in a sequence.
- **Salience:** earns a click to a case study or product page. Use on early touches or with Problem Aware audiences.

Mixing both in one piece dilutes both. The influence model governs the CTA wording, the body argument, and the ask. Lock it in the brief. On the blog specifically, most posts run on Salience (earn a click to the report, the product page, the next post); a hard Direct Response ask suits only Most Aware readers or the bottom of a series.

---

## 3. The positioning anchor - the Mosaic Payments worked example

The positioning anchor is the one compressed statement that must survive translation from a 500-word description into any piece of copy. If it isn't traceable in the copy, the copy isn't on strategy.

### The anchor in three forms

| Form | Text |
|---|---|
| **Sentiment line** (internal compass) | "Payments that work the way travel works." |
| **One-liner** (external anchor) | "The only solution that gives travel agencies flexibility, broad choice, and deep expertise across both pay-in and pay-out." |
| **Copy-facing form** (most adversarial - earns its place in a title or subject line) | "Open, modular payments vs a closed legacy stack." |

### Why each word in the one-liner earns its place

| Word / phrase | What it does |
|---|---|
| *"only"* | The competitive move - excludes Outpayce, which covers pay-in for airlines and payout for agencies but not the full suite for one segment |
| *"flexibility + broad choice"* | Unique attributes stated in customer language, not product language |
| *"travel agencies"* | The segment signal - not airlines, not generic B2B |
| *"pay-in and pay-out"* | The market category frame - a complete two-sided suite, not one side of the transaction |

If any of those words blurs in translation to the post, the post has drifted off strategy.

### The three value themes and their proof

A post picks **one row.** Which row depends on the trigger moment. Never cross proof and theme.

| Value theme | Buyer pain it answers | Proof that belongs to it |
|---|---|---|
| **(a) Flexible pay-in** | Acceptance rates, conversion loss, stack complexity | "324M transaction authorizations in 2025 worth ~$113BN" |
| **(b) Payout choice** | Costs too high, no rebate revenue, limited bank access | "20+ virtual card issuers, 80+ connected banks, 100+ countries" |
| **(c) Value-added services** | Chargeback exposure, FX risk, manual back-office burden | "the only solution consolidating issuing and acquiring chargebacks in one platform" |

**The cross-check:** before drafting, write down (a) the chosen theme, (b) the matching proof, and (c) where the positioning anchor is traceable in the copy. If you cannot fill in all three, don't draft.

---

## 4. The content gate - NO CONTENT = NO COPY

The writer enhances, structures, and optimizes what it's given. It never invents content, statistics, claims, customer names, or timeframes.

### Pre-draft checklist - run this before writing a word

**Pillar 1 - Strategic foundation (always, in order)**

- [ ] Who is this for, and what is the **trigger moment**? (Role, company type, the specific moment they're in - not just the segment)
- [ ] Which of the nine blog types? (See `03-blog-types.md`)
- [ ] What is the **one thing** the reader should think, feel, or do? (Forces the single CTA and the influence model)
- [ ] Which **competitive alternative** are we displacing? (Do nothing, build in-house, or a named incumbent)

**Pillar 2 - Positioning inputs**

- [ ] Is there **approved messaging** for this product? (If yes: draw from it. If no: flag the draft.)
- [ ] Which **single value theme** are we leading with?
- [ ] What is the **proof that belongs to that theme**? (Not a different theme's proof - the matching one)

**Pillar 3 - Raw materials**

- [ ] What content has been provided to work with? (Case studies, named results, testimonials, data, existing copy, competitor examples, product detail)
- [ ] For a series: what is the **distinct angle** for each post? (A later post is the next chapter of an argument, not a recap)

**Pillar 4 - Verification**

- [ ] Is every statistic and claim **sourced from the provided materials**? (Not inferred, not plausible - sourced)
- [ ] Can Sabre legally make each claim?

### Absolute prohibitions

Never, under any circumstances:
- Fabricate statistics ("73% of agencies prefer...")
- Invent timeframes ("most clients see results in 30 days")
- Invent customer names or testimonials
- Create unverified industry benchmarks
- Make up proof to fill a gap in the materials

### Response to pressure to proceed without materials

> "Creating copy without proper materials would hurt your credibility. Let's get the right content first."

Hold that line. Moving fast with thin materials produces copy that sounds strategic but isn't - and it erodes trust when the claims can't be substantiated downstream. The gate exists to protect the post's credibility, not to slow the work.

---

## Quick pre-draft check (the one-page version)

Before any post is drafted, confirm:

1. **Brief complete?** Commercial outcome, trigger moment, influence model - all three named.
2. **Competitive frame named?** One of: do nothing / build in-house / named incumbent.
3. **Single value theme chosen?** One row from the positioning table, matched to the buyer's pain.
4. **Matching proof identified?** The proof that belongs to that theme - not another theme's proof.
5. **Anchor traceable?** Write the copy-facing form of the anchor. Confirm it will be visible in the finished post.
6. **All claims sourced?** Every number and named result came from the provided materials.

If any box is empty, collect what's missing before writing.
