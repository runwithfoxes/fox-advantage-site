# 06 - Formulas, series, and register

The structural toolkit for long-form: which formula to reach for, how the reader's awareness governs that choice, how a series distributes an argument across several posts, and the byline register spectrum.

---

## 1. The proven formulas, and when to use each

The same formulas that power email still apply to long-form; they just have more room to breathe. A blog post can run a full argument where an email only points at one.

| Formula | Use it for | Note |
|---|---|---|
| **AIDA** (Attention-Interest-Desire-Action) | Product deep-dives, capability posts, announcements | The backbone of a piece that builds to a single action. Room here to do Interest and Desire properly. |
| **PAS** (Problem-Agitate-Solution) | Problem-aware readers, product posts, practical guides | The agitate step is where weak writing pulls back. Make the cost specific, don't just say it louder. |
| **BAB** (Before-After-Bridge) | Customer stories, transformation narratives | The natural shape for a case study: the old constraint, the new state, how they crossed. |
| **Story-Insight-Application** | POV, thought leadership, recaps | A real, specific, counter-intuitive story → the lesson → what the reader does with it. The strongest long-form shape. |
| **Myth-Truth-Action** | Contrarian POV for "I already know this" readers | Requires real evidence. Fabricated contrarianism is worse than none. The "poke the bear" formula. |
| **Hook-Context-Findings-Application** | Research / data insight posts | Dissonant hook → who was asked and why it's credible → the findings → the so-what. The long-form sibling of the report-launch email. |
| **Signal-Reading-Implication** | Trend / market analysis | The change you see → the two readings (obvious + missed) → what it means for the reader's next move. |
| **Question-Answer-Build** | Explainers, "how it works" | The reader's real question → the short answer up front → the unpack. Don't make them scroll for the payoff. |

Pick the formula from the type and the awareness level, not from habit. Let the structure follow the argument; a formula is a starting shape, not a template to force the writing into (that rigidity is a slop tell).

---

## 2. Schwartz awareness match - governs formula choice

The reader's awareness level decides which formula to reach for. Picking the wrong one is the most common reason a post falls flat.

| Awareness level | What the reader already knows | Lead with |
|---|---|---|
| **Most Aware** (small %) | Knows Sabre, knows the product, ready to act | The offer or the deepest insight. Direct. |
| **Solution Aware** | Knows solutions exist, comparing options | Third-party proof, differentiation, the mechanism. |
| **Problem Aware** (large %) | Knows the problem, not sure what solves it | Empathetic, specific acknowledgment of the pain first. |
| **Unaware** | Doesn't yet recognise the problem | Story, a pattern interrupt, a contrarian but grounded hook. |

**Key insight:** most Sabre B2B readers are Problem Aware or Solution Aware. A post that opens by pushing a demo at a Problem Aware reader has skipped the step that makes the ask feel logical. Earn the read before you make the ask. On the blog specifically, the ask is usually a soft one (read the report, explore the shift), not "book a demo".

---

## 3. Series logic - a distributed argument across posts

A single post makes one argument. When the subject is bigger than one post can carry, distribute it across a series, the way a sequence distributes a sales case across touches. Each post carries one part of the whole and stands on its own.

**A series is not one long post chopped up.** Each part has its own hook, its own payoff, and its own single idea. A reader landing on part three cold should still get value. A reader following all three should feel the argument compound, never repeat.

### A workable series shape

| Part | Job | Type it usually maps to |
|---|---|---|
| 1 | **Frame the shift** - name the change and why it matters now | POV or trend |
| 2 | **Go deep on the mechanism** - how it actually works | Explainer or product deep-dive |
| 3 | **Prove it** - the named result, the customer, the data | Case story or research insight |
| 4 (optional) | **The practical move** - what the reader does about it | Practical guide |

### Rules for a series

- **Restate, never repeat.** The core thesis appears in every part; the angle changes each time. If a reader could skim part three and learn nothing beyond part one, the series has failed.
- **Each part links forward and back** with a real, specific pointer, not "in our next post we'll discuss".
- **Vary the shape across parts.** If every part is the same formula at the same length, the whole series reads as a single machine output. Different sittings, different rhythms.

---

## 4. The byline register spectrum

For a blog, the byline is the register selector, the same way the signature block is for email. The three voice traits (infectiously upbeat, knowingly provocative, endlessly supportive) stay constant across all registers. Register changes who's speaking and how personal it feels. It does not change the brand. Set the byline first; the voice follows.

| Register | Voice | Byline | Use it for |
|---|---|---|---|
| **1 - Brand** | Collective "we", company position | "Sabre" or "The Sabre team" | Announcements, official positions, broad newsletters |
| **2 - Team** | Warm collective, a defined group | "The Sabre Mosaic team" / "Sabre Airline Solutions" | Explainers, product deep-dives, case studies, guides |
| **3 - Named team voice** | Still "we", but a named person carries it | Named individual + title, light first person | Recaps, regional or product-team pieces |
| **4 - Named author** | A named person with a view, "I" measured | Named individual + title + photo | POV, thought leadership, trend analysis, reaction |
| **5 - Senior personal** | Fully first-person, a leader's own voice | Named senior leader only | A CEO or exec's personal stance on a major shift |

**Where most blog content sits:** registers 2 and 4. Use 2 when the company is teaching or proving something; use 4 when a person is taking a position. Reserve 5 for a genuine leadership moment where a corporate "we" would ring hollow.

---

## 5. A note on length

Length is governed by the type and awareness, and the ranges live in `05-blog-structure-and-seo.md`. The principle: length is earned by substance, never padded to look authoritative. Short and sharp beats long and loose every time. Long is an explicit choice for an argument that genuinely needs the room, not the default.
