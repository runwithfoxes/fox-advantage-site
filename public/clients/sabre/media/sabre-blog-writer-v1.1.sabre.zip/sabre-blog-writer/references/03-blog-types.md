# 03 - Blog and long-form types

The nine types this writer covers, each with a proven structure, a default length, a default byline register, and the watch-outs that sink it. Pick the type first: it sets the structure and the tone calibration. If a request doesn't fit one of the nine, say so and ask which it's closest to rather than inventing a tenth.

> **One thing per piece.** A blog post makes one argument or teaches one idea. The moment it carries two, it teaches neither. The type tells you what that one job is.

---

## The nine types at a glance

| # | Type | One job | Default length | Default register |
|---|---|---|---|---|
| 1 | Point-of-view / thought leadership | Plant a flag on an industry shift | 800 - 1,400 | 4 - named author |
| 2 | Explainer / "how it works" | Make one concept genuinely clear | 700 - 1,200 | 2 - team |
| 3 | Product / capability deep-dive | Connect one product to one real problem | 800 - 1,300 | 2 - team |
| 4 | Customer story / case narrative | Show the shift through one named customer | 700 - 1,100 | 2 - team |
| 5 | Research / data insight | Turn findings into a so-what | 600 - 1,000 | 2 - team |
| 6 | Trend / market analysis | Name what's changing and why it matters now | 800 - 1,300 | 4 - named author |
| 7 | Practical guide / listicle | Give the reader something to do | 600 - 1,000 | 2 - team |
| 8 | News reaction / commentary | Sabre's sharp take on a live event | 400 - 800 | 4 - named author |
| 9 | Event recap / behind-the-scenes | What we saw, what it means for you | 500 - 900 | 3 - named team voice |

Register numbers map to the spectrum in `06-formulas-and-length.md`. Length is a guide, not a cage; the awareness level and the depth of the supplied material move it.

---

## 1. Point-of-view / thought leadership

**The job:** take a defensible stance on where the industry is going, and earn the reader's agreement with argument, not assertion. This is where the "poke the bear" value shows up most. Closest to the Sabre brand voice at full volume.

**Reader / awareness:** mostly Problem Aware or Solution Aware senior decision-makers. They have opinions already; the piece either sharpens or challenges them.

**Proven structure:**
- **Hook** - a specific, attributable observation or a genuine tension in the market. Not "Most airlines are getting this wrong." A real, grounded thing.
- **The stake** - why this matters now, and to whom. Name the moment.
- **The argument** - three to four moves that build, each developing the last, not three parallel "points". Evidence before opinion: the proof earns the claim, the claim doesn't precede the proof.
- **The counter** - name the strongest version of the opposing view and answer it. This is what separates a POV from a rant.
- **The resolution** - what the reader should now believe or do. No neat bow. Land it on a real implication.

**Watch-outs:** a POV with no opposing view answered is just a brochure. A POV that fabricates a "most people think X" strawman is worse. The stance must be Sabre's actual position (open, modular, AI-native, customer-first), traceable to positioning, never invented to sound bold.

---

## 2. Explainer / "how it works"

**The job:** make one concept the reader half-understands genuinely clear, so they leave smarter. Teaching, not selling. The product can appear, but the value is the clarity.

**Reader / awareness:** Problem Aware or Unaware. They've heard the term ("modern retailing", "offer and order", "agentic AI") and want the real version, not the buzzword.

**Proven structure:**
- **The question** - the thing the reader actually wants answered, stated plainly.
- **The short answer** - give it early. Don't make them scroll for the payoff.
- **The build** - unpack it in two to four stages, each concrete, each with an example from the reader's world.
- **The "why it's hard" or "where it goes wrong"** - the honest bit that proves you've lived it.
- **What it means for you** - the practical so-what, lightly tied to how Sabre thinks about it.

**Watch-outs:** explainers drift into feature lists. Hold to teaching. If a sentence doesn't make the concept clearer, cut it. Never explain a thing Sabre can't actually do or back up.

---

## 3. Product / capability deep-dive

**The job:** connect ONE product or capability (Mosaic, IQ, Travel Data Cloud) to ONE real problem the reader has, and show the mechanism. Not a spec sheet.

**Reader / awareness:** Solution Aware, comparing options. They want to know how it actually works and why it beats the alternative they're weighing.

**Proven structure:**
- **The problem, in the reader's words** - the pain, specific, named. The trigger moment.
- **Why the usual fix falls short** - the closed legacy stack, the in-house build, the do-nothing cost.
- **How Sabre does it differently** - the mechanism, concrete. "Built to open", "AI built not bolted on" only when the body proves it.
- **The proof** - the matching proof for the claim (see the positioning spine's theme-to-proof table). Never cross proof and theme.
- **What changes for the reader** - the outcome, then a single, specific next step.

**Watch-outs:** this is the type most likely to fabricate a stat to sound credible. No content = no copy. Every number traces to supplied materials. One product per piece; if it sprawls across the portfolio it sells nothing.

---

## 4. Customer story / case narrative

**The job:** show the shift through one named customer's arc - before, the decision, after - so the reader sees themselves in it.

**Reader / awareness:** Solution Aware. Third-party proof is what they're hunting for.

**Proven structure:**
- **The situation** - who they were and the constraint they lived with. Specific, named (only if supplied and cleared).
- **The trigger** - what made them move. The moment, not the demographic.
- **The decision** - what they chose and why, including what they weighed it against.
- **The work** - what actually happened, honestly, including the hard parts.
- **The result** - the named, sourced outcome. Then what it unlocked next.

**Watch-outs:** never invent a customer, a quote, a metric, or a logo. If the materials don't name the customer, write it as an anonymised pattern and flag it. A case study with a fabricated number is a liability, not a credibility play.

---

## 5. Research / data insight

**The job:** take findings from a report, survey, or study and turn them into a so-what the reader can use. The companion long-form to the email type 9 (report launch).

**Reader / awareness:** any level; data is the hook that crosses awareness lines.

**Proven structure:**
- **The dissonant finding** - lead with the number or result that breaks an assumption. One, not five.
- **Who was asked, and why it's credible** - sample, method, in one or two lines. Credibility before interpretation.
- **What it means** - the interpretation, developed, not just restated. This is the value.
- **The deeper cut** - one finding unpacked properly, with the reader's segment named.
- **What to do with it** - the practical move, plus the link to the full report.

**Watch-outs:** never round a stat up to sound stronger, never imply a finding the data doesn't support. Spell out the method honestly. Attribution belongs here (this is the one type where "the study found" earns its place), but state known things directly elsewhere.

---

## 6. Trend / market analysis

**The job:** read the market - name what's changing, why now, and what it means for the reader's next decision. More observational than a POV, but it still takes a position.

**Reader / awareness:** Problem Aware or Solution Aware. They feel the shift; the piece names it and frames it.

**Proven structure:**
- **The signal** - the specific change you're seeing. Grounded, attributable, not a vibe.
- **Why now** - what's driving it. The forces, concrete.
- **The two readings** - the obvious interpretation and the one most people miss. The second is the value.
- **The implication** - what it means for how the reader should think or act.
- **Sabre's angle** - lightly, where the company's view fits. Not a pivot to a pitch.

**Watch-outs:** trend pieces are where invented specifics breed ("by 2027, 60% of..."). If a projection isn't in the materials, don't make one up - frame the direction qualitatively or ask for the source.

---

## 7. Practical guide / listicle

**The job:** give the reader something concrete to do - questions to ask, steps to take, things to check - that they could act on today.

**Reader / awareness:** Problem Aware. They've accepted the problem and want a handle on it.

**Proven structure:**
- **The promise** - what they'll be able to do by the end. Specific.
- **The list** - genuinely parallel items (three to seven), each with real substance, not a one-line filler. Each item: the what, then the why, then the how.
- **The connective argument** - the through-line so it reads as thinking, not a checklist. Lists with no argument are the classic AI tell.
- **The close** - the single most important one, or the first step to take.

**Watch-outs:** listicles tempt uniform structure (every item the same length, every heading the same shape). Vary it. Cut any item that's there to hit a round number. Five real items beat seven padded ones.

---

## 8. News reaction / commentary

**The job:** Sabre's sharp, fast take on a live industry event, announcement, or competitor move. Short, opinionated, timely. The type where "knowingly provocative" runs warmest.

**Reader / awareness:** any; the news is the hook.

**Proven structure:**
- **The news, in one line** - what happened, no throat-clearing.
- **The take** - Sabre's read on it, stated with conviction. The angle is the whole point.
- **The why** - the reasoning that backs the take, with one concrete reason the reader hadn't considered.
- **The so-what** - what it means for the reader's world. Land it and stop.

**Watch-outs:** the jab lands on the situation or the competitor's approach, never on customers. Don't punch down. Keep it short; a reaction that runs to 1,200 words has lost its timeliness. Verify the news is real and stated accurately before reacting to it.

---

## 9. Event recap / behind-the-scenes

**The job:** turn a conference, launch, or internal moment into something the reader who wasn't there can use. Warmth and specifics, not a press release.

**Reader / awareness:** any; usually warm-ish (they know Sabre).

**Proven structure:**
- **The scene** - where, when, the texture of it. One vivid, true detail.
- **The theme** - the one thing that mattered most. Not a play-by-play.
- **What we heard / learned** - two or three real takeaways, specific to what was said or shown.
- **What it means going forward** - the so-what for the reader, and where to go next.

**Watch-outs:** recaps slide into a list of sessions nobody cares about. Pick the one theme. Real specifics only; don't invent a quote or a moment to make it sing.

---

## A note on register and byline

Blog posts carry a byline, and the byline is the register selector, the same way the signature block is for email. A named author (register 4) reads as a person with a view, right for POV, trend, and reaction pieces. A team or brand byline (register 2) reads as the company, right for explainers, product, and case studies. Set the byline first; the voice follows. The full spectrum is in `06-formulas-and-length.md`.
