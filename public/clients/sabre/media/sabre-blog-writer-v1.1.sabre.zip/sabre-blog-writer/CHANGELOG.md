# Changelog - Sabre Blog Writer

How to read this: the version number is in `SETUP.md` and in the zip filename
(`sabre-blog-writer-v1.0.sabre.zip`). If the filename you downloaded matches the
version you already have loaded, it's the same skill. A higher number means a newer set.

## v1.1 - 28 June 2026

- Added a real verification layer (`references/08-verification-and-claims.md`) and made it a
  mandatory step. Every run now produces a **verification ledger**: every checkable claim
  (stats, named people, named customers, quotes, competitor claims, capability claims, legal
  claims) gets its own row, a status, and pasted evidence.
- The hard rule: a claim only stays in as a stated fact if it's SUPPLIED (quote the source line),
  POSITIONING (name the pillar), or WEB-VERIFIED (paste a real URL). Anything unproven is
  bracketed in the copy; anything needing a human is flagged. **A row cannot be marked
  WEB-VERIFIED without a pasted source** - this kills the "trust me, it's verified" failure.
- Honesty gate: if web search isn't available in the session, the writer says so and flags
  external claims rather than claiming it verified them.
- A pre-publish verification checklist (named-people titles, customer clearance, quote fidelity,
  competitor currency, legal claims always flagged) as the last gate.
- Output order is now: plan → post → verification ledger → writing-checks panel → flags.

## v1.0 - 28 June 2026

- First release. A narrow long-form writer covering nine types: point-of-view/thought
  leadership, explainer/how-it-works, product/capability deep-dive, customer story/case
  narrative, research/data insight, trend/market analysis, practical guide/listicle,
  news reaction/commentary, and event recap (a multi-part series handled as a variant).
- Built on the Sabre email writer's foundations: the same voice and lexicon, the same
  hard writing rules, the same positioning spine and content gate, and the same two-pass
  AI-slop audit (tuned for long-form, where varied rhythm and structure across sections
  is what keeps a longer piece reading human).
- Plan-first behaviour carried over: declares type, byline register, length, formula,
  value theme, structure and a candidate title before writing, then shows its working
  (the checks and the actual fixes).
- New long-form mechanics: title-last discipline, the standfirst, scannability for the
  screen, length-by-type, and a light-touch SEO layer that never overrides the voice.
