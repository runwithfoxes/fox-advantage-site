# Sabre Blog Writer - setup (Claude.ai)

**Version 1.1** · 28 June 2026 · see `CHANGELOG.md` in this folder for what changed. If the version here matches the copy you already have, it's the same skill, no need to re-import.

A narrow, deep long-form writer that drafts Sabre blog posts and articles in Sabre's brand voice, across the nine types you actually publish. It declares its plan before it writes, then shows its working, so you can see it didn't cut corners. Built on the same foundations as the Sabre email writer (same voice, same quality bar, same content gate), tuned for long-form.

## What it does

- Covers nine long-form types: point-of-view/thought leadership, explainer/how-it-works, product/capability deep-dive, customer story/case narrative, research/data insight, trend/market analysis, practical guide/listicle, news reaction/commentary, and event recap. A multi-part series is handled as a variant on top of these.
- Writes in the real Sabre voice (upbeat, knowingly provocative, endlessly supportive - the jab lands on the old way, never on the customer). A POV or reaction piece pokes the bear a little harder than an email does.
- Holds a hard quality bar: no em dashes, no exclamation marks, sentence case, no generic B2B, and a two-pass AI-slop audit on every piece, tuned so a longer post still reads human.
- Builds for the screen: a specific sentence-case title, a standfirst that earns the read, front-loaded sections, subheads that pass a skim test, short varied paragraphs, one benefit-led call to action with a → arrow.
- Treats SEO as a light layer: one search term placed naturally, never at the cost of the voice.
- Never invents facts. If you don't give it the proof, the stat, the customer, or the data, it won't make them up - it flags the gap instead.
- Proves its facts with a **verification ledger**: every checkable claim (every stat, named person, customer, quote, competitor claim) gets its own row with a status and a pasted source. Nothing is marked "verified" without a real source link. If it can't prove a claim, it brackets it or flags it for you - it never quietly leaves an unproven fact in.

## How it works each time

1. **It declares a plan first** - the type, the angle, the one value theme, the structure, and a candidate title - before writing a word. This primes a better post and shows it did the thinking.
2. **It writes the post.**
3. **It proves the facts** - a verification ledger, one row per claim, with a status and a pasted source. Then it walks a pre-publish checklist.
4. **It shows its working** - the writing checks it ran and the actual fixes it made.

If it's missing something important (a real result, approved product messaging), it tells you in the plan and marks the post a draft rather than papering over the gap.

## Set it up in Claude.ai (5 minutes)

1. Go to **claude.ai** → **Projects** → create a new project (or open an existing Sabre project).
2. Open **Project knowledge** (or the project's Skills, if available to your plan).
3. Upload the contents of this folder: `SKILL.md` and the whole `references/` folder. Keep the structure as-is.
4. Start a chat in the project and ask, for example:
   - "Write a thought-leadership post on why open beats closed in airline retailing. Here's the argument and the proof: [paste]."
   - "Draft an explainer on what agentic AI actually does in airline ops. Source material: [paste]."
   - "Turn these report findings into a data-insight post: [paste the findings, sample, and method]."
5. Answer its setup questions (who it's for, the one thing they should take away, what proof you have). The more real material you give it, the stronger the post.

## Tips

- **Give it real content.** It enhances what you provide; it does not invent. Case studies, named results, dates, data, a report to draw from, existing copy - all make the post better.
- **Pick the type and the length.** Each type has a default length; ask for "long" when the argument genuinely needs the room. It will push back on padding.
- **It works best in a project where Sabre's positioning is loaded**, so it can cite real specifics rather than flag them as gaps.
- **Ask it to "show your working"** any time you want the full checklist of inputs and checks.
- **Out of scope:** emails (use the Sabre email writer), paid social and organic social (use those writers), decks (Sabre presentation skill), website/landing-page copy. It will tell you and point you elsewhere.
