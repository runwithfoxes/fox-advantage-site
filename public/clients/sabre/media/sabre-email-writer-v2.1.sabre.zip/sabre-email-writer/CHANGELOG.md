# Changelog - Sabre Email Writer

How to read this: the version number is in `SETUP.md` and in the zip filename
(`sabre-email-writer-v2.1.sabre.zip`). If the filename you downloaded matches the
version you already have loaded, it's the same skill. A higher number means a newer set.

## v2.1 - 17 June 2026

- Removed the "Most [airlines / hotels / travel companies]..." generalisation opener.
  It had crept into headlines and read as LinkedIn-bro. The writer was learning it from
  one worked example, not from any rule.
- Added an explicit ban on that opener to the AI-slop audit (opener cliches list + the
  phrase-search checklist), so it gets caught on every email, not just spotted by eye.
- Reworded two seeded examples that used the same construction.

No change to the nine email types, the voice, the plan-first behaviour, or the templates.

## v2.0 - 16 June 2026

- Expanded to nine email types: webinar invite, event invite, event/webinar follow-up,
  campaign brand, campaign product, survey, CEO/senior-leader, operational, and
  research/report launch (ABM handled as a variant).
- Report-launch type built to Darren's preferred shape and backed by report-launch research.
- Plan-first behaviour: declares type, angle, value theme, structure and a candidate
  headline before writing, then shows its working (the checks and the actual fixes).
- Two-pass AI-slop audit on every email. Fits the 2026 Sabre email templates.
- Published to the Sabre client page with three sample emails.
