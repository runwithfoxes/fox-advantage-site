# Setup - Sabre Brief Coach (for Sabre's Claude.ai)

This skill is **script-free and self-contained** so it runs in Sabre's Claude in the browser. It depends on no other skill and no external site.

## Install into Sabre's Claude.ai

1. Zip the skill folder with the folder itself at the root of the archive:
   ```
   cd ~/.claude/skills && zip -r sabre-brief-coach.sabre.zip sabre-brief-coach
   ```
   (`unzip -l` should show `sabre-brief-coach/` then `sabre-brief-coach/SKILL.md`.)
   The `.sabre.zip` suffix is so Sabre's email/security gateway does not block it.
2. claude.ai -> Customize -> Skills -> + -> Create skill -> upload the zip.

## Load the positioning as project knowledge

The frameworks are baked in, but the coach needs Sabre's own positioning to be non-generic. In the Sabre project, add as project knowledge (see references/08):
- Mosaic Marketplace positioning (Payments / Insight / Experience).
- Airline Technology positioning.
- The "Positioning to messaging" Dunford method doc.

Without these, the coach still holds the discipline, but it will flag positioning specifics as gaps rather than cite them, which is correct behaviour, not a bug.

## Naming note

The `name:` field is `sabre-brief-coach` and deliberately contains no "claude" (claude.ai rejects that word in the name field).

## Test prompts after install

- "Brief coach. Here is a campaign brief, [paste]." -> should route to a tier and start at commercial.
- "Check this positioning against Dunford, [paste]." -> should run the canvas + five tests.
- "We need a video for the booth." -> should refuse the one-liner and pin the make-able dimensions.
