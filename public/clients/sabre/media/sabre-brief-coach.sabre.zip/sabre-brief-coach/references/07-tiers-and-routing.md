# 07 - Tiers and routing

Briefs are not one-size. Route FIRST, then apply the right depth. Running Dunford positioning rigour on a videography shot list is a category error and makes you look like you do not understand the work.

## Step 0: what is in front of you?

First split: is this a **positioning doc** or a **brief**?

- Positioning doc -> positioning-check mode. The only face is positioning (references/04), run the full canvas + five tests. Skip commercial / insight / operational, those belong to briefs that draw on this positioning.
- Brief -> identify the tier below, then work the faces top-down.

## The brief tiers

| Tier | Looks like | Faces to hold them to |
|---|---|---|
| **Strategic campaign** | A rebrand, a flagship campaign, a launch. Big spend, sets direction. | All four, full depth: commercial -> positioning -> insight -> operational. |
| **Moment / internal** | A reactive "moment" off a win or news hook, an internal promote brief. | Commercial (light: why now + one number) + insight (single ownable message + proof) + operational. |
| **Event / experiential** | A trade-show booth, an event, an activation. | Commercial (the objective and number) + KNOW / FEEL / DO (what they should know, feel, do) + operational (the make-able test on every asset and activation). |
| **Production** | A videography brief, a design spec, an asset-build request. | Operational only (references/06). Clarity and completeness. No strategy rigour. |

## How to use the tier

State it up front: "This reads as a strategic campaign brief, so I am going to hold it to all four faces, commercial first." That sets expectations and stops you over-coaching a production brief or under-coaching a flagship.

If a brief claims to be one tier but behaves like another (a "simple video brief" that is actually launching a positioning), say so and re-tier it. The tier follows the work, not the title on the document.

## KNOW / FEEL / DO (event tier)

For event and experiential briefs, the strategy layer is lighter but still required: what do we want them to KNOW, FEEL and DO at this event? Each must be specific and each DO must ladder to the commercial objective. "Visit the booth" is an activity, push it to "book a qualified meeting" and tie that to the number.
