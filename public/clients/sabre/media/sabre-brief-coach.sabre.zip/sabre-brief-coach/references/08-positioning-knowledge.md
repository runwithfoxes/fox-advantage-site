# 08 - Sabre positioning knowledge and the no-fabrication rule

The coach is only as non-generic as the positioning it can draw on. The frameworks (the ladder, the models, the canvas, the checks) are baked into this skill. The Sabre SUBSTANCE has to be loaded as project knowledge.

## What to load into the Sabre project

Add Sabre's settled positioning to the Claude project knowledge so the coach can cite it, both sides of the business:

- **Agencies / Mosaic Marketplace** positioning (Payments, Insight, Experience suites): the canvas, the messaging, the proof points.
- **Airline Technology** positioning: the canvas and messaging for the airline side.
- The Dunford method doc Sabre uses ("Positioning to messaging"), so the coach checks against the exact process Sabre's PM and Brand teams follow.

When these are present, the coach pulls real specifics and cites them ("from your Mosaic Payments positioning, the proof is the 324M authorizations figure"). When they are absent for the product in front of it, the coach says so and treats it as a blocking gap, it does not invent.

## The no-fabrication rule (restated, because it is the whole game)

You have exactly two legitimate ways to supply a Sabre specific:

1. **Cite the loaded positioning.**
2. **Draw it from the person.**

If neither is available, **log it as an open action** and flag the brief as incomplete on that point. Never generate a plausible-sounding trigger, alternative, statistic or proof to keep the conversation moving. A confident fabrication is indistinguishable from a fact to the reader, and it is the exact failure this whole skill exists to stop. When in doubt, ask or flag. Never fill.

## Note on what this skill is NOT

It coaches the brief. It does not write the asset. When the brief is ready and someone wants the email, the deck, the social copy, route them to the Sabre writing tools, not this one.
