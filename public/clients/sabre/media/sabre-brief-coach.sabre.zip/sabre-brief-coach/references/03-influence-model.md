# 03 - The single influence model

Every brief is using a model of how it will influence behaviour, consciously or not. The default failure mode is mixing three or four at once. Force commitment to ONE. No hybrids.

## The seven models

| # | Model | Core idea |
|---|---|---|
| 1 | **Hierarchy-of-Effects (AIDA)** | Linear: Awareness > Interest > Desire > Action. Move one rung at a time. |
| 2 | **Persuasion / Strong Theory** | Rational arguments change attitudes; changed attitudes change behaviour. |
| 3 | **Weak Theory (ATR-N / Ehrenberg)** | Awareness > Trial > Reinforcement > Nudge. Ads maintain behaviour, they do not change it. |
| 4 | **Salience / Mental Availability** | Make the brand easy to bring to mind at category entry points. |
| 5 | **Fame / Social Contagion** | Make the brand a talked-about cultural reference. |
| 6 | **Direct Response** | Engineer immediate, measurable action. |
| 7 | **Signalling** | The waste is the part that works; conspicuous presence signals quality. |

## The shortcut diagnostics

- Stage-based or situation-based? Hierarchy vs Salience.
- Change attitudes or maintain behaviour? Persuasion vs Weak Theory.
- Build the brand or harvest demand? Salience/Fame vs Direct Response.
- Cost-efficient or conspicuous? Any model vs Signalling.

## KPIs tell the truth

When the stated model says "brand building" but the KPIs are conversions, trust the KPIs, that is the real model. Look at what the team will actually be judged on, not what the objective paragraph claims. This is where you catch the mix: a brief that says "position us as a trusted guide" (salience) and measures "registrations and sales conversations" (direct response) is two campaigns in one coat.

## The collapse move

Name the mix, then make them pick: "This stacks salience and direct response. They brief differently, different hero asset, different CTA, different measure. Your KPIs lean direct response. Is that the master, with the guide idea as how you get there, or the other way round?" Express it as relief, not punishment, you are freeing them from pretending to do both.

You do not pick the model for them. You expose the mix, show the options, and make them commit to one.
