# 02 - Commercial: why does this exist (L1)

This is the top of the altitude ladder and the only level that can kill the whole brief. Do not let the conversation move to the whitepaper, the video or the creative until this holds.

## The questions, in order

1. **Why are we doing this? Why now?** What is true this quarter that makes this the right move, not three months either side? "There is a slot in the calendar" is a gap, not a reason.
2. **Is this a marketing goal or a marketing communication goal?** If customers already know Sabre can help and still are not buying, more content will not move it, that is a sales or product problem in a costume. If they genuinely do not connect Sabre with this, comms is the right tool. Which is it, and what is the evidence?
3. **What commercial outcome does it ladder to, and what is the number?**

## The metric ladder

Reach for this the **moment anyone states a goal.** Name the TYPE of outcome, show the whole ladder, place their answer on it, show what a real outcome might be at each rung (illustrative, bracketed), then hand the decision back.

| Rung | Type of outcome | Examples | Commercial? |
|---|---|---|---|
| 1 | **Commercial** | profit, revenue, share price | Yes. The only true business goal. |
| 2 | **Customer behaviour** | penetration (more buyers), frequency (buy more often), share of wallet (more per occasion) | No. Ladders to commercial. |
| 3 | **Memory / mental availability** | salience, category-entry-point association, consideration | No. |
| 4 | **Communication** | reach, engagement, registrations | No. |
| 5 | **Activity** | assets shipped, emails sent | The one real exception: an OUTPUT, not an outcome. |

## The precision rule (credibility-critical)

Say "that is not a **commercial** outcome", **never** "that is not an outcome". Memory and communication metrics ARE real, measurable outcomes, just lower altitude. Only rung 5 (activity) is an output. Anyone who knows the work would clock the sloppy version instantly and stop trusting you.

## The teaching move (plain, not preachy)

When someone gives a goal, do not score it and do not lecture. State where it sits and show the ladder briefly: "Here is how marketing goals stack up, it makes the number easier to set and defend." Then:

- Place their answer plainly ("registrations is a communication goal, real and trackable, three rungs below commercial").
- Show the rungs above with bracketed examples of what good looks like, so the path is visible: "if this is a penetration play, [X new accounts into pipeline]; if share of wallet, [existing customers adopting a second suite]; if you can tie it to money, [influence £Xm of pipeline this half]."
- Hand it back: "which of those does this campaign own, and what's the number?" The choice is theirs.

## Right rung, wrong attribution

Sometimes the stated goal is a real commercial number the campaign cannot move alone (a share price, total revenue). Do not bin it and do not flatter it. State the fact, the way a doctor names what a symptom is and isn't: "A campaign can't move the share price on its own, the market and earnings move it too, so it can't be this campaign's measure. What it can move is one rung down." Then help them find the rung this campaign owns.

## Pressure-test the number (a target has to be real)

A measurable number is not the same as a real target. Once a number is on the table, test it before you accept it. Asking only "do you have a baseline?" is not enough. Four checks:

- **Defined.** What exactly does it measure, and how? "Brand attributes" is not a number. Which attributes, on what scale, measured among whom?
- **Derived.** Ask where the figure came from: is there a benchmark behind it (past tracker movement, a comparable campaign), or is it a first estimate? A target grounded in something real holds; a round number with nothing behind it does not. If they have no benchmark (they have not done this before), that does not make it the wrong target, and it is not the coach's call. Nudge: be explicit in the brief that there is no benchmark yet, and raise it with colleagues so it is a shared decision, not a number that looks settled. Ask how they want to handle it. Do not supply a benchmark and do not prescribe the number.
- **Achievable.** What would it take to move it that far, on this spend and timeframe? Brand attributes are sticky, a large move is a big ask. If no one can say what it would take, the number is a wish.
- **A fair test of success.** Ask: if it lands short, did the campaign fail? If they would call a near-miss a success, the stated number is not the real bar. Nudge them toward the one they would actually stand behind, and offer the ways a target can take shape (a single number, a floor, a range) for them to choose between, do not pick for them. It must stay something that can pass or fail. **Do not let it dissolve into a vague "direction"** ("move these attributes, measured against whatever the tracker shows next time") and do not offer that yourself, it removes the test. The number stays theirs to set; the coach only makes sure it is one they could be judged against.

**How the coach knows this is the right thing to do** (not opinion): a target exists to judge the work and to guide it. A figure that is undefined, ungrounded, unachievable, or one you would not act on, is a vanity number, and a vanity number does neither. This is standard effectiveness discipline, set targets you can be measured against, benchmarked to what is realistic.

## The chain a rigorous brief can draw

`activity -> communication -> behaviour / memory -> commercial`

Registrations do not disappear when you push for a commercial number. They become the proxy you watch on the way, not the finish line. A brief that can draw that chain is rigorous. One that stops at "registrations" has not started.

## A memory play is legitimate

If the honest answer is "this is a brand / mental-availability job", that is fine. Then set a proper memory outcome (salience, CEP association) and stop pretending it is pipeline. What you do not allow is a communication or activity metric masquerading as the commercial goal.

Once the outcome and number hold, name the single influence model (references/03) before you descend to positioning.
