# 02 - Commercial: why does this exist (L1)

This is the top of the altitude ladder and the only level that can kill the whole brief. Do not let the conversation move to the whitepaper, the video or the creative until this holds.

## The questions, in order

1. **Why are we doing this? Why now?** What is true this quarter that makes this the right move, not three months either side? "There is a slot in the calendar" is a gap, not a reason.
2. **Is this a marketing goal or a marketing communication goal?** If customers already know Sabre can help and still are not buying, more content will not move it, that is a sales or product problem in a costume. If they genuinely do not connect Sabre with this, comms is the right tool. Which is it, and what is the evidence?
3. **What commercial outcome does it ladder to, and what is the number?**

## The metric ladder

Reach for this the **moment anyone states a goal.** Name the TYPE of outcome, show the whole ladder, place their answer on it, show what a real outcome might be at each rung (illustrative, bracketed), then hand the decision back.

| Rung | Type of outcome | Examples | Commercial? |
|---|---|---|---|
| 1 | **Commercial** | profit, revenue, share price | Yes. The only true business goal. |
| 2 | **Customer behaviour** | penetration (more buyers), frequency (buy more often), share of wallet (more per occasion) | No. Ladders to commercial. |
| 3 | **Memory / mental availability** | salience, category-entry-point association, consideration | No. |
| 4 | **Communication** | reach, engagement, registrations | No. |
| 5 | **Activity** | assets shipped, emails sent | The one real exception: an OUTPUT, not an outcome. |

## The precision rule (credibility-critical)

Say "that is not a **commercial** outcome", **never** "that is not an outcome". Memory and communication metrics ARE real, measurable outcomes, just lower altitude. Only rung 5 (activity) is an output. Anyone who knows the work would clock the sloppy version instantly and stop trusting you.

## The teaching move (not just refusing)

When someone says "drive demand" or "raise awareness" or "registrations":

- Name where it sits ("registrations is a communication outcome, rung 4").
- Show the whole ladder so they see the shape.
- Show what a real outcome MIGHT be at the rungs above, bracketed: "if this is a penetration play, maybe [X new accounts into pipeline]; if share of wallet, [existing customers adopting a second suite]; if you can tie it to money, [influence £Xm of pipeline this half]."
- Then: "Which rung is this brief actually playing at, and what is the number there?"

## The chain a rigorous brief can draw

`activity -> communication -> behaviour / memory -> commercial`

Registrations do not disappear when you push for a commercial number. They become the proxy you watch on the way, not the finish line. A brief that can draw that chain is rigorous. One that stops at "registrations" has not started.

## A memory play is legitimate

If the honest answer is "this is a brand / mental-availability job", that is fine. Then set a proper memory outcome (salience, CEP association) and stop pretending it is pipeline. What you do not allow is a communication or activity metric masquerading as the commercial goal.

Once the outcome and number hold, name the single influence model (references/03) before you descend to positioning.
