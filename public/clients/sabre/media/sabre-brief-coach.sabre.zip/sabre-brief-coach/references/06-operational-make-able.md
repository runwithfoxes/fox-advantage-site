# 06 - Operational (the make-able test)

The test: **could someone who was NOT in the room build exactly this from the brief, with zero follow-up questions?** If not, the brief is not finished. This is the WHOLE job for production-tier briefs, and it applies to every deliverable inside a strategic one.

A deliverable name is not a deliverable. "A video" is a hundred different things. "Some emails" is a send, not a brief. Pin each asset along these dimensions until it is make-able.

## The dimensions to pin

1. **Why this asset at all?** Does it earn its place against the model, audience and number above? ("Why a video in the first place?") This ladders back up, an asset that serves no agreed outcome comes out.
2. **Placement, where does it turn up?** Event screen, paid feed, site hero, email embed, sales meeting, booth loop. Each implies different everything.
3. **Context of consumption, the conditions it is seen in:**
   - **Sound on or off?** Feed ad: off, captions mandatory. Event or booth: no sound, visual-led. Sales meeting: sound on, leaning in.
   - **Interactive or passive?** Do they control it, or does it play at them?
   - **Attention.** Lean-in (meeting) vs scroll-past (feed, win the first one to two seconds) vs ambient (booth loop).
   - **How long will they actually give it?**
4. **Type / form.** For video: animatic, live action, talking head, product or UI display, motion graphics, montage. Different crews, budgets, timelines. For a doc: one-pager, deck, long-form.
5. **Format / spec.** Aspect ratio (9:16 / 1:1 / 16:9), length, file size and weight, resolution, captions, sound mix or none, language versions.
6. **Quantity and variants.** How many, how many cuts / sizes / versions (the full IAB display-set problem), per channel, per language.
7. **Recipient and moment** (especially email and comms). Who exactly, why them, the context when they receive it, where in a sequence, what came before and after. "The full database" is not an audience.
8. **CTA / next.** What it asks the viewer to do, and where it points.
9. **Mandatories.** Brand assets, logo frequency, legal, deadline, who approves.

## The "both" trap

When someone says one asset serves several homes ("social and the booth and the sales meeting"), that is not one asset, it is one idea cut several ways, each with its own rules. A film that ignores sound-off in the feed and sound-on in the meeting works in neither. Name the master cut and the adaptations, and pin each.

## How you coach it

Refuse "a video" and "some emails". Pin each dimension. Where a dimension is unknown, log it as an action (the brief is not done until it is answered), never invent the spec. The finish line is a stranger building it without coming back to ask.
