# 05 - Insight (the one thing only Sabre can say)

The insight is ONE sentence that only Sabre could credibly say, rooted in a moment, and provable. It is what the campaign opens on, before the product. Most briefs either have no insight or have a description dressed as one.

## The headline test, run it first

**Who else could say this?** Take the line that looks like the insight and ask who else could run it. If a competitor could say it ("we guide you through the volatility"), it is a wrapper, not your position. Find what only Sabre can claim underneath it. Charm is not ownership: the more attractive the line, the harder you test it.

## The full check

- **Insight vs description.** Does it reveal WHY they buy, or just describe who they are? "25-45 urban professionals" is a description. The insight is the motive.
- **A trigger moment, not a demographic.** Name the moment, not the person. "When a corporate client is squeezing them on cost and the renewal is looming" beats "agency TMC customers". Name what just happened in their week.
- **Implicit vs explicit motivation.** What is the gap between what they say and what they do?
- **Functional and emotional as one system,** not two separate columns.
- **Reflects how the decision actually happens,** not how we wish it did.
- **A goal state, not a feature wish.** "Ending the quarter without losing an account" is a goal state. "Wanting efficiency" is a feature wish.

## How you coach it

Probe for the moment ("when does this person stop scrolling and actually read it? what just happened?"). If they cannot answer, do not fill it in, that is the LLM's worst instinct. Log it as an action: the brief is not finished until the real trigger comes back, in one concrete sentence. If they hand you a charming line, run "who else could say this?" on it and let them find the provable thing underneath. They write the insight. You supply the test.
