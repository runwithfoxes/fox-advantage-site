# 04 - Positioning (the Dunford check)

Positioning is done ONCE for a product, then everything draws from it. Two jobs share this one brain:

- **Positioning-check mode** (a PM brings a positioning doc): run the full canvas + five tests on the doc itself.
- **Brief mode** (a campaign brief): the brief must CITE settled positioning, not re-derive it. Check its messages trace back to the canvas (the Fidelity test).

## The canvas - five elements, all present and provable

1. **Competitive alternatives** - what the customer would use instead. Include do-nothing, build-in-house, manual processes, and legacy bolt-ons, not just named rivals.
2. **Unique attributes** - what only Sabre has. Objective and provable, a capability or fact, not a marketing claim.
3. **Value + proof** - the value those attributes deliver, in customer language, with evidence.
4. **Customer segment** - who cares most about that value, and how to recognise them.
5. **Market category / frame of reference** - how the customer understands what this is.

If you cannot complete the canvas without guessing, that gap IS the diagnosis.

## The five tests - every claim must survive

1. **So What?** Does the claim connect to a concrete customer value? If you cannot answer "so what?" with a real outcome, it is too feature-focused.
2. **Who Else Can Say This?** Could a competitor credibly make the same claim? If yes, it is not differentiated. Back to unique attributes. (This is also the headline insight test, references/05.)
3. **Says Who?** Is the claim backed by a provable attribute, data point or customer? If not, it needs proof or reframing.
4. **Consistency.** Do the one-liner, elevator pitch, 100-word and 500-word versions tell the same story at different depths? The short forms should be compressions of the long.
5. **Positioning Fidelity.** Does every message trace back to a unique attribute or stated value? If not, it is brand-flavour copy, flag the difference.

## How you coach it

- Doc mode: walk the canvas, then run the five tests on each value claim. Where a claim fails "Who Else Can Say This?", say so and ask what only Sabre can claim instead. Do not rewrite it for them.
- Brief mode: ask "where is the settled positioning this draws on?" If the brief re-argues positioning from scratch, that is the finding, positioning is upstream, done once. If a message in the brief fails Fidelity (cannot be traced to the canvas), flag it.
- Never invent the positioning. If Sabre's positioning for this product is not in the loaded knowledge, say so and treat it as a blocking gap (references/08).
