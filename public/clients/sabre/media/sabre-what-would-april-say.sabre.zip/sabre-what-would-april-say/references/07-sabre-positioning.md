# 07 - Sabre's loaded positioning (the substance April cites)

This is the settled positioning April draws on, distilled from Sabre's own positioning docs (the Mosaic Marketplace suite positioning + Darren's "Positioning to messaging" method). It is the **heart of the skill**: it is what lets April answer with real Sabre specifics instead of placeholders.

**Snapshot and scope (read before citing):**
- Distilled from the Sabre positioning docs as of mid-2026. Approval status varied at the time (Insight Suite approved; Payments Suite draft 2; Experience Suite with David). Treat this as Sabre's *working* positioning, solid to cite, not necessarily the final-final word.
- Covers the **agency side: the Mosaic Marketplace Payments, Insight and Experience suites.** It does **not** contain the **Airline Technology** positioning, nor the other Marketplace suites (Offer, Order, Content). For anything outside the three suites below, April says the positioning isn't loaded and asks, she does not invent it.
- The no-fabrication rule still holds inside this file: cite what's here, do not extrapolate a new proof point, attribute or number beyond it. If a question needs a specific that isn't here, ask. If the loaded positioning has since moved on, the project-knowledge docs win over this snapshot.

## The Mosaic through-line (the spine across all suites)

The one position the whole Mosaic story rests on, and the one a monolith competitor cannot honestly claim:

**Open, modular, flexible, neutral. Adopt module by module, through the points of sale and systems you already use. Runs alongside the existing stack via API. No replatforming, no big-bang cutover, no lock-in.** Sabre's phrase for it is "flexibility with guardrails": the freedom of build-your-own without the operational chaos of a composable free-for-all.

The recurring competitive frame is the **Amadeus monolith** (and its arms: Outpayce for payments, Selling Platform Connect for experience, the GDS for insight), plus **build-in-house** and **do-nothing**. When a claim needs an ownable contrast, this through-line is almost always where it lives.

---

## Payments Suite

- **Category:** a complete travel payment suite. It IS an aggregator/facilitator of financial services and payment workflows, open and neutral. It is NOT a financial-service provider, NOT a payment processor, NOT a closed loop.
- **Anchor:** "Payments that work the way travel works."
- **One-liner:** the only solution that gives travel agencies flexibility, broad choice, and deep expertise across both pay-in and pay-out.
- **Competitive alternatives:** do nothing (keep existing payment setup); build in-house IT (own RFPs, direct integrations); **Outpayce by Amadeus** (the key named rival; gap: pay-in is airline-focused, payout is agency-focused, so not a complete suite for one segment, and its chargebacks cover issuing only, not acquiring).
- **Unique attributes:** only complete suite covering pay-ins + payouts + value-added services for any travel retailer including agencies; freedom to integrate any PSP / orchestrator / issuer / fintech; embedded natively in Sabre or via API into any in-house PSS; largest network of virtual-card issuers with best payout coverage and intelligent rebate rules; comprehensive payout (virtual cards + account-to-account); multi-sector expertise across travel, payments and fintech; single point of support.
- **Value themes + the proof that belongs to each (never cross proof and theme):**
  1. **Most flexible pay-in** (acceptance up, fraud down). Proof: handled 324M transaction authorizations in 2025 worth ~$113BN; connects to any PSP / LPM / AFOP; works with any in-house stack.
  2. **Most flexible payout** (choose the combination that makes more money). Proof: the only comprehensive payout suite (virtual-card issuing + A2A); largest network of 20+ premium virtual-card issuers and 80+ connected banks; 100+ countries (incl. LATAM), 40+ currencies; 43M virtual-card transactions in 2025 worth >$7BN; A2A to 94+ countries in ~70 currencies.
  3. **Value-added services** (visibility, liquidity, control). Proof: the only chargeback solution consolidating issuing AND acquiring chargebacks in a single platform; FX / trip protection.
  4. **Backed by Sabre.** Proof: 60 years in travel technology; trusted for payments by 55+ airlines and 1,000+ agencies.
- **Segments:** agencies simplifying the pay-in stack; agencies optimising payouts for rebate revenue / lower cost; agencies streamlining value-added-service workflows.

## Insight Suite

- **Category:** a market and competitive insight suite for travel sellers.
- **Anchor / sentiment:** see what the competition misses; make smarter moves faster.
- **One-liner:** comprehensive market and competitive intelligence so travel agencies can make smarter moves faster.
- **Competitive alternatives:** do nothing (Excel / manual reporting); build in-house (Looker, Cvent); other data providers (TravelClick, ForwardKeys, Lighthouse / formerly OTA Insights); traditional GDS (Amadeus, mostly self-service, low customisation, not integrated with Sabre workflows).
- **Unique attributes:** actionable, expert-driven insight (Sabre's consulting team interprets the data, not just dashboards); PNR-level data access (the real booking record, not modelled estimates); comprehensive market + competitive benchmarking on the proprietary Sabre Travel Data Cloud; near-real-time configurable dashboards.
- **Value + proof:** uncover hidden top-line growth. Proof: hotel-attachment studies found agents proactively offered lodging on air bookings only 19% of the time; up to 4% booking growth with deep customer insights, up to 37% with expert market-expansion analysis; based on engagements with 30+ agencies.
- **The sharpest differentiator vs Amadeus:** PNR-level, real transaction data on the Sabre Travel Data Cloud (not modelled estimates), interpreted by a consulting team and wired into Sabre workflows, versus self-service dashboards.
- **Segments:** agency leadership teams (enterprise / global TMCs; mid-market agencies wanting plug-and-play; OTAs needing data export for advanced analytics).

## Experience Suite

- **Category:** a flexible experience suite for travel sellers, the front-end / interaction layer (agent workspaces, APIs/SDKs, AI assistants) across search, sell and service.
- **Anchor:** one experience, everywhere your customers and agents show up.
- **One-liner:** the front-end of your travel business, the screens, AI assistants and toolkits agents, developers and travelers interact with across search, sell and service.
- **Competitive alternatives:** status quo patchwork (incumbent GDS + aggregators + direct connects); build in-house (OTAs / travel-tech teams on supplier APIs); supplier-direct (toggling between interfaces); competitor platforms (Amadeus Selling Platform Connect, Travelport+); niche aggregators / point solutions (Travelfusion, Mystifly).
- **Unique attributes:** (1) flexible by design, the "flexibility with guardrails" that dodges the buy-vs-build trap; (2) purpose-built experiences for every skill level, interoperable not siloed (Agency Workspace, formerly Sabre Red 360, for experts; Agency Workspace Lite, formerly Sabre Red Launchpad, for new/independent advisors; Agency Concierge AI assistant, formerly Email IQ); (3) continuous modernization through existing points of sale, an inheritance model with no replatforming; (4) one normalized end-to-end multi-source experience across air (traditional, NDC, LCC), lodging, ground and rail.
- **Value + proof:**
  1. **Adopt new capabilities without disrupting operations** (protect revenue, control tech spend). Proof: 400+ enterprise APIs incl. agentic-ready; AmTrav (Jeff Klee) developer-experience testimonial.
  2. **Grow revenue without slowing teams.** Proof: 35K+ agencies and ~200K advisors on Agency Workspace; ~100M bookings in 2025 across air/lodging/car; Sabre handles 60%+ of indirect-channel lodging bookings.
  3. **Future-proof productivity as the workforce/automation mix shifts.** Proof: agentic-ready multi-source APIs + intelligent cache + MCP server in production; Agency Concierge processed 3,500 emails in one month in a TMC pilot.
- **Segments:** travel sellers modernizing to scale revenue/productivity without adding headcount. Experience-led (global/upper TMCs, large leisure agencies, independent-consultant populations, agent-assisted OTAs) and extension-led (API-first OTAs, metasearch, fintech/LLM platforms adding travel, travel-tech startups).

---

## How April uses this file

- When a claim needs an ownable contrast, reach first for the **through-line** (open/modular/no-big-bang vs the monolith) and the relevant suite's unique attributes, and **cite the specific** (the 324M figure, the 19% attachment stat, the 35K agencies, etc.).
- When a tagline or claim fails Who Else Can Say This, point to the suite attribute or proof here that *would* be ownable, cited, not invented.
- For the airline side, the other Mosaic suites, or anything not in this file, say it isn't loaded and ask. Do not stretch these three suites to cover it.
