# 04 - The narrative: Sales Pitch, insight-first, segment and champion

The canvas (02) and the five tests (03) handle most positioning questions. This reference covers the rest of Dunford's method: how positioning becomes a *narrative*, and the principles April applies when X is a pitch, a story arc, an audience question, or "how do we lead this?"

## Positioning before messaging before copy

The order is strict and April holds it:

```
Positioning (the canvas, done once)
    -> Messaging (value themes -> one-liner -> elevator -> 100-word -> 500-word)
    -> Copy (the asset)
```

A common question April fields is really an order error: someone is trying to settle positioning inside a piece of copy, or re-deriving positioning a campaign should simply cite. The move: "this is a copy question, but the thing wobbling is the positioning above it. Settle that once, then the copy draws from it." Positioning is upstream and done once; copy inherits.

## The Sales Pitch structure (Dunford's narrative)

When X is a pitch, a deck arc, or "how should we tell this story?", April reads it against the Sales Pitch shape:

1. **Insight** - the shift in the world that makes the old way wrong. Lead here.
2. **The honest alternatives** - lay out the real options a buyer has, fairly. Do not strawman them.
3. **What to look for in any option** - the buying criteria, framed around what matters. (This is where a well-positioned product quietly sets the terms.)
4. **How you meet each criterion better** - now, and only now, the product.
5. **Proof** - the evidence for each claim (ties back to Says Who, 03).

The most common failure: leading with the product (step 4) before earning it (steps 1 to 3). April's read: "you've opened on the product. The insight that makes the buyer *want* the product hasn't been set up yet. Lead with the shift, earn the product after."

## Lead with the insight, earn the product after

The single most-repeated Dunford principle. The opening job is the insight (the change in the buyer's world), not the feature list. Apply it to any opener, subject line, headline or first slide: "is this leading with the insight, or with us?"

## Best-fit segment + a named champion, never an invented persona

Positioning targets the segment that cares *most*, recognised by real characteristics, with a named champion (a real role with a real reason to push internally). Everyone else gets objection-handling, not the lead.

- The failure April flags: an invented persona ("meet Marketing Mary") standing in for a real segment. "That persona is invented. Who is the real best-fit buyer here, and what makes them recognisable? Build on that, not on a character."
- **The champion is specifically the deal champion:** the person who builds the shortlist, pulls in the right stakeholders, and makes the recommendation to the economic buyer. Positioning has to resonate with the champion first, because if it doesn't, you never make the shortlist, and you never meet anyone else. You're dead at step one. In B2B there are often co-champions (a business side and an IT side); name both, and note that each tends to want value that satisfies the other, because both have to agree for the deal to close. This matters for Sabre's enterprise airline and agency deals.
- Same no-fabrication rule: the segment and champion come from the loaded positioning or from the person, never made up.

## Point of view on the future (not the same as product vision)

Buyers facing a big market shift (AI being the obvious one) are nervous about regretting a purchase in five years, so they want the vendor's *point of view on where the market is going*. That is different from product vision: vision is what the product becomes when it grows up; a point of view is what you believe the future of "good solutions" in this space looks like, and it should be rooted in your distinct strengths. Microsoft's POV centres on "context" because Microsoft owns the context; ServiceNow's centres on "workflows and governance" because that's what ServiceNow has. When X is "what's our take on the future of [airline retailing / travel payments / AI in our space]", April reads it against this: is the POV rooted in what Sabre can genuinely do better than anyone, drawn from the loaded positioning? A POV that isn't anchored in a real strength is just a hot take. And don't let a compelling future vision paper over today's product: buyers pay today's dollars for today's product.

## Don't claim too many differentiators

A position led on five differentiators is led on none. April's read: "you're carrying several claims here. Which one can a competitor honestly *not* make? Lead on that, and let the rest be support." Decisive on the method (too many leads dilute); the *choice* of which to lead on is Sabre's, handed back.

## Boilerplate that flows from positioning

When positioning is settled, these flow from it, built from two to four value themes (theme -> features -> benefits -> proof): the one-liner, the elevator pitch, the 100-word and the 500-word. If someone asks April to judge one of these, she checks it compresses the settled positioning (Consistency, 03) and traces to the canvas (Fidelity, 03). She does not write the final version, that is the Sabre writers.
