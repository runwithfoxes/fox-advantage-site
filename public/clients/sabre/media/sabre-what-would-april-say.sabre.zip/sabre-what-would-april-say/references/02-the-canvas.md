# 02 - The positioning canvas, and how to read X against it

Dunford's positioning is built from five elements. They are done ONCE for a product, then everything (messaging, copy, campaigns) draws from them. When someone asks what April would say about X, the canvas is the frame you read X inside.

## The five elements (all present and provable)

1. **Competitive alternatives** - what the customer would use instead if Sabre did not exist. Not just named rivals. Include do-nothing (inertia), build-in-house, manual processes, and legacy + bolt-ons. Positioning is always *relative to the alternative*, never in a vacuum. Count only the alternatives that show up on a real customer shortlist. A rival the buyer has never heard of is "a ghost that only we can see", and it does not belong in the frame (06).
2. **Unique attributes** - what only Sabre has. Objective and provable: a capability or fact, not a marketing claim. The thing a competitor genuinely cannot replicate or honestly claim. The unique thing can be a *combination*: no single attribute is unique, but the bundle is (fast to deploy AND saves money, when each rival does only one). Combination value still counts (06).
3. **Value + proof** - the value those attributes deliver, stated in the customer's language, backed by evidence. Attribute is what you have; value is what it does for them; proof is why they should believe it.
4. **Customer segment** - who cares most about that value, and how you recognise them. A best-fit segment with a named champion, never an invented persona. Value is context-dependent: the same capability is a weakness to one segment and a premium feature to another, so a too-broad segment blurs the differentiation. Tighten to the accounts that care most about what only Sabre delivers (06).
5. **Market category / frame of reference** - how the customer understands what this is. The category sets the buyer's expectations and the competitors they compare you against. Choosing the wrong frame is one of the most expensive positioning mistakes.

## Before the canvas: what exactly are we positioning?

Sabre is multi-product (Mosaic suites, the airline side, modules). So a recurring first question is: are we positioning a single product, a suite/platform, or the company? April treats this as a decision to surface, not one to make for them: do you lead with one product then cross-sell, let customers choose any entry product, or sell the platform as one integrated thing? The answer changes the whole canvas. If the question in front of you straddles several products, name that, and ask which they mean before reading X.

## How to read X against the canvas

Match the kind of X to the element it lives in, then check that element holds:

- **A tagline or one-liner** -> it is compressing the whole canvas. Ask: which unique attribute does it rest on, and which value does it promise? If it rests on nothing in the canvas, it is brand-flavour, not positioning. (Then run the Fidelity test, 03.)
- **A differentiation claim** ("we're the open platform") -> element 2, unique attributes. Ask Who Else Can Say This (03). If a competitive alternative could claim it too, it is not a unique attribute.
- **A category question** ("are we modular retailing or airline retailing?") -> element 5, frame of reference. This is usually a Sabre *strategy* choice, not a method verdict. April lays out what each frame would set the buyer up to expect, who it puts you next to, and what each frame demands you can prove, then hands the choice back. She does not pick the category for Sabre.
- **A competitive move** ("should we position against Amadeus by name?") -> element 1, competitive alternatives. April can be decisive on whether the *contrast* holds up against the method (does Sabre have a unique attribute the alternative honestly cannot claim?). Whether to *name* the competitor is a Sabre business call, hand it back.
- **A piece of copy or a message** -> Fidelity (03): does it trace to a unique attribute and stated value in the canvas, or is it floating free?

## The recurring move

Most positioning weaknesses are the same shape: a claim that sits in element 2 (unique attribute) but is actually claimable by a competitive alternative in element 1. When that happens, name it as a fact, then point to what *would* be ownable from the **loaded** Sabre positioning, cited. If the loaded positioning holds no ownable alternative for that claim, say so and ask. Never invent one.

## If the canvas can't be completed without guessing

That gap IS the answer. If you cannot say which alternative X displaces, or which unique attribute it rests on, that is what April would point at: "the canvas has a hole here, and that hole is the positioning question, not something I should fill for you." Ask for it, or flag it as missing.
