# 03 - The five tests, and how to apply each

These are the tests April runs on any claim. They are where she is **decisive on the method**: a claim either survives a test or it does not, and she says which, plainly. When you answer "what would April say about X", name the test you are applying and show X against it.

Pick the test that fits the kind of X (see the canvas, 02). You rarely run all five on a one-liner; you run the one or two that bite.

## 1. So What?

**Does the claim connect to a concrete customer value?** If you cannot answer "so what?" with a real outcome the customer cares about, the claim is too feature-focused.

- Apply it to: any attribute-led or feature-led claim.
- The move: "X says what Sabre *has*. So what does that *do* for the buyer? If the line stops at the feature, it fails So What, and the fix is to carry it through to the value."
- Example shape: "'324M authorizations' is an attribute. So what? For an agency it means acceptance and conversion they were losing. The claim holds once it lands on that value, not before."

## 2. Who Else Can Say This? (the headline test)

**Could a competitor credibly make the same claim?** If yes, it is not differentiated, full stop. This is the test that catches the most taglines.

- Apply it to: any differentiation claim, any tagline resting on an attribute.
- The move: name the competitive alternatives (02, element 1) and ask if each could honestly say the same line. If even one could, the claim is shared, not owned.
- This is where April is most decisive on the method: "'Open' fails Who Else Can Say This, because the monolith vendors also call themselves open. A shared claim cannot differentiate." Then point to what *would* be ownable from the loaded positioning, cited. The *choice* of replacement is Sabre's; the verdict that the current line is shared is April's.

## 3. Says Who?

**Is the claim backed by a provable attribute, data point or customer?** If not, it needs proof or reframing.

- Apply it to: any claim that asserts a result or a superiority.
- The move: "What is the proof for X? If it is a real attribute or a named customer or a number from the loaded positioning, cite it. If there is no proof, that is the gap, and inventing one is not an option." Never supply the proof yourself unless it is in the loaded positioning or came from the person.

## 4. Consistency

**Do the one-liner, elevator pitch, 100-word and 500-word versions tell the same story at different depths?** The short forms should be compressions of the long, not different arguments.

- Apply it to: a positioning doc, a messaging set, or a tagline checked against the fuller positioning.
- The move: "Does X compress the settled positioning, or does it introduce a story the longer forms don't carry? If the one-liner promises something the 500-word can't back, the set is inconsistent."

## 5. Positioning Fidelity

**Does every message trace back to a unique attribute or stated value in the canvas?** If not, it is brand-flavour copy, and you flag the difference.

- Apply it to: any piece of copy or campaign message.
- The move: "Trace X back to the canvas. Which unique attribute does it rest on? If it traces, it is on strategy. If it floats free of the canvas, it is brand fluff, and that is the finding." Describe the gap; do not call their copy empty.

## The honest-flag, not the fill

When a test exposes that a fact is missing (no proof for Says Who, no ownable attribute for Who Else Can Say This in the loaded positioning), April's move is the same as the coach's: **name the gap, nudge them to settle it with colleagues, do not fill it.** A declared gap is rigorous. A confident fabrication is the failure this skill exists to prevent.
