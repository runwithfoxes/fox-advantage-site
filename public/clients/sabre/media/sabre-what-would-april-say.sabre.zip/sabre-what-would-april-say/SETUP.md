# Setup - What Would April Say? (for Sabre's Claude.ai)

This skill is **script-free and self-contained** so it runs in Sabre's Claude in the browser. It depends on no other skill and no external site. It is the lighter, answer-giving sibling of `sabre-brief-coach`.

## Install into Sabre's Claude.ai

1. Zip the skill folder with the folder itself at the root of the archive:
   ```
   cd ~/.claude/skills && zip -r sabre-what-would-april-say.sabre.zip sabre-what-would-april-say
   ```
   (`unzip -l` should show `sabre-what-would-april-say/` then `sabre-what-would-april-say/SKILL.md`.)
   The `.sabre.zip` suffix is so Sabre's email/security gateway does not block it.
2. claude.ai -> Customize -> Skills -> + -> Create skill -> upload the zip.

## Positioning: baked in, plus project knowledge for depth

The **Mosaic agency positioning is baked into the skill** (`references/07-sabre-positioning.md`: Payments, Insight, Experience, with the real proof points and the Amadeus/Outpayce framing), so April answers with real Sabre specifics out of the box, no setup required. It is a dated snapshot of confidential positioning, so the `.sabre.zip` must only go into Sabre's own environment.

For depth and currency, also add the full source docs as project knowledge in the Sabre project (see references/05), because positioning evolves and the baked-in file is a snapshot:
- The Mosaic suite positioning docs (Payments / Insight / Experience) in full.
- **Airline Technology** positioning, and the other Marketplace suites (Offer / Order / Content) - these are NOT baked in, so without them April will correctly flag airline and non-agency questions as gaps and ask.
- The "Positioning to messaging" Dunford method doc.

If the loaded docs and the baked-in snapshot ever disagree, the loaded docs win, and 07 should be refreshed from them.

## Naming note

The `name:` field is `sabre-what-would-april-say` and deliberately contains no "claude" (claude.ai rejects that word in the name field). "April" and "What Would April Say?" appear freely in the H1 and body, only the `name:` field is restricted.

## Sibling skill

`sabre-brief-coach` is the full coach: it runs a whole brief or positioning doc to "ready" across four faces and gives no answers, it only asks. This skill is the quick oracle: one question, one grounded view. Keep the Dunford material consistent between them. If someone wants a whole brief worked to ready, route them to the Brief Coach.

## Test prompts after install

- "What would April say about the tagline 'Built to open'?" -> should identify it as a tagline, ask which alternative it beats / who it's for if needed, apply Who Else Can Say This, and (if it fails) point to what's ownable from the loaded positioning, cited.
- "Are we 'modular retailing' or 'airline retailing'?" -> should treat it as a category/frame question, lay out what each frame sets up and demands, and hand the choice back (Sabre strategy, not April's call).
- "Can we call ourselves an AI platform?" -> should run Says Who and Who Else Can Say This, ask for the proof, and refuse to invent it.
- "Should we position against Amadeus by name?" -> decisive on whether the contrast holds against the method, hands back the business call on naming the competitor.
