# Sabre Organic Social Writer - setup (Claude.ai)

**Version 1.0** · 28 June 2026 · see `CHANGELOG.md` in this folder for what changed. If the version here matches the copy you already have, it's the same skill, no need to re-import.

A narrow, deep organic-social writer that drafts Sabre posts in Sabre's brand voice, LinkedIn first. It declares its plan before it writes, then proves its facts, then shows its working. Built on the email and blog writers' foundations, plus Paul's LinkedIn strategic framework and 2026 LinkedIn research, so it writes from evidence rather than folklore.

## What it does

- Writes every post to ONE of five goals: Salience, Get talked about, Value add, Authority build, or Strategic CTA. One goal per post, because a post chasing two serves neither.
- Writes the hook first and hardest (most people never click "...more", so the visible first two lines decide whether the post is seen), and generates several options before picking one.
- Knows how LinkedIn actually works in 2026: saves beat likes, comments beat shares, the first 90 minutes set reach, a named person's profile out-reaches the company page by a wide margin, and posting in one coherent topic lane helps reach. It writes to all of that.
- Writes in the real Sabre voice (upbeat, knowingly provocative, supportive), turned up a little for the feed - the jab lands on the old way, never on the reader.
- Holds the same hard quality bar as the other writers: no em dashes, no exclamation marks, sentence case, no generic B2B, a two-pass AI-slop audit (tuned to catch the LinkedIn-template skeleton), and varied line lengths instead of a wall of one-liners.
- Proves its facts with a verification ledger: every checkable claim (every stat, named person, customer, quote, competitor claim) gets its own row with a status and a pasted source. Nothing is marked verified without a real source link.
- Never invents facts. If you don't give it the proof, the stat, the customer, or the data, it brackets it or flags it.

## How it works each time

1. **It declares a plan first** - the goal, byline, format, value theme, structure, and a candidate hook - before writing a word.
2. **It writes the post** - hook, body, engagement line, optional ask, and a visual direction if one's used.
3. **It proves the facts** - a verification ledger, one row per claim, with a status and a pasted source.
4. **It shows its working** - the writing checks it ran and the actual fixes it made.

## Set it up in Claude.ai (5 minutes)

1. Go to **claude.ai** → **Projects** → create a new project (or open an existing Sabre project).
2. Open **Project knowledge** (or the project's Skills, if available to your plan).
3. Upload the contents of this folder: `SKILL.md` and the whole `references/` folder. Keep the structure as-is.
4. Start a chat in the project and ask, for example:
   - "Write a Sabre LinkedIn post arguing that open beats closed in airline retailing. Author is [name, title]. Material: [paste]."
   - "Turn this customer result into an authority-build post: [paste the result and the source]."
   - "Write a get-talked-about post on the legacy-filing debate. Here's the angle and the proof: [paste]."
5. Answer its setup questions (who it's for, the one goal, what proof you have). If the author has real posts, paste 150-250 words of their writing so it matches their voice.

## Tips

- **Pick the goal.** It will ask, but telling it up front (authority, get-talked-about, value, salience, or a CTA) sharpens everything.
- **Default to a named author**, not the company page - it reaches far more people and reads as more trustworthy. Save the company page for brand lines.
- **Give it real material.** A real result, a real number, a real story. It enhances what you provide and flags what it can't prove.
- **It works best in a project where Sabre's positioning is loaded**, so it can cite real specifics rather than flag gaps.
- **Out of scope:** paid ads, emails, blogs, website copy, decks. It will tell you and point you elsewhere.
