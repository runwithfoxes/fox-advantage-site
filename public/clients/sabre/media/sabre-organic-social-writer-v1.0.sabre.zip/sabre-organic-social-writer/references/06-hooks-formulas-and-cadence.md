# 06 - Hooks, formulas, cadence, and byline

The craft toolkit for organic social: how to build the hook (the highest-leverage line on the platform), which formulas to reach for, how a series compounds, and whose name goes on the post.

---

## 1. The hook - the ad for the ad

Most readers never click "...more". The hook (the first one or two lines before the truncation) is where the post is won or lost. Treat it as a separate piece of craft from the body, and write it last, after you know what the post actually delivers.

**The constraints:**
- The visible cut is roughly the **first two lines / ~55 characters** before "...more" on mobile. Write the hook to land inside that. (Hassid, 2026.)
- The hook's only job is the **click-to-expand** (or, for a Value-add post, to deliver value immediately). It is a pattern interrupt: unexpected, counterintuitive, or hyper-specific.

**What makes a hook work:**
- **Specific beats clever.** A real number, a named moment, a concrete claim. "324M payments ran through one stack last year" beats "payments are changing".
- **Contrarian, but grounded.** A position against the conventional wisdom stops the scroll. But it must be specific and supportable, not a sweeping "most airlines are getting this wrong" - that generic-contrarian opener is banned in the slop audit as the LinkedIn-bro tell. The fix is to make the contrarian claim real and attributable, or drop the setup and start on the concrete point.
- **Match the hook to the goal** (see the table in `03-post-goals-and-types.md`): front-load utility for Value add; preview the insight (not a tease) for Authority; lead with the debate for Get-talked-about; a sticky phrase for Salience; the benefit for CTA.
- **A bold claim needs immediate support.** "Recruiters took six weeks. The tool got interviews in three days" beats "the tool beats recruiters". Unsupported bold claims create skepticism, not attention.

**Generate three to five hook options every time**, then pick the one that best serves the diagnosed goal, and say in the evidence panel which you picked and why. The hook is too important to write once.

**Hooks to avoid** (these are slop tells, see `07`): "Here's the thing", "Let's be clear", "Most [group]...", "Have you ever wondered", "Unpopular opinion:" as a reflex, and the curiosity-gap tease on a Value-add post.

---

## 2. The formulas, adapted for social

| Formula | Use it for | Note |
|---|---|---|
| **PAS** (Problem-Agitate-Solution) | Value add, Get-talked-about | The most versatile short form. Make the cost specific in the agitate step. |
| **Story-Insight-Application** | Authority, Get-talked-about | A real, specific, slightly uncomfortable story → the lesson → the so-what. The strongest social shape. The vulnerability IS the value; don't bolt a framework on. |
| **Contrarian-Reasoning-Question** | Get-talked-about, Authority | Grounded contrarian claim → the reasoning (show the logic) → a genuine question. |
| **Observation-Pattern-Point** | Authority | A specific thing you noticed → the pattern behind it → what it means. Original noticing is what reads as authority. |
| **One-line Salience** | Salience | A single memorable phrase or metaphor. The whole post is the line. |

Let the structure follow the idea. A formula is a starting shape, not a skeleton to force every post into - the rigid "hook / three one-liners / CTA" template is itself the slop the audit catches.

---

## 3. Awareness still governs the ask

| Awareness | Lead with | On social |
|---|---|---|
| **Unaware** | A story, a pattern interrupt, a contrarian-but-grounded hook | Most of the cold feed. Earn attention before any ask. |
| **Problem aware** | Specific acknowledgment of the pain | Value-add and Get-talked-about land here. |
| **Solution aware** | Differentiation, the mechanism, third-party proof | Authority posts. |
| **Most aware** | The offer | The only place a hard CTA post fits. |

95% of B2B buyers are out-of-market at any moment (LinkedIn Marketing Solutions). So most posts are building memory and trust for a buying window that hasn't opened. That is why four of the five goals are not asks - the salience compounds until the buyer is ready.

---

## 4. Series and cadence - the compounding layer

**A single post is a spark; a series is a bonfire.** Posting consistently in one lane turns content into something people check back for, and trains the algorithm (the first 90 days especially are about teaching LinkedIn what you're about; sporadic posting keeps you invisible). (Brewton, 2026.)

- **A series distributes one argument across posts**, each standing alone, each with its own hook and payoff. Restate the thesis, never repeat it - a reader following all of them should feel it compound.
- **Behavioural coherence** (from `05`): keep the series in one topic lane so LinkedIn reads Sabre as the authority on it.
- **Consistency over volume-without-purpose.** The research has a clear anti-pattern: years of daily posting with no offer or conversion path closes nothing (Jones, 2026). Cadence serves a goal; it isn't the goal.

---

## 5. The byline - whose name carries it

For social, the byline is both a voice choice and a reach lever, because **personal profiles out-reach the company page by ~561%** since 360Brew (Brewton, 2026).

| Register | Voice | Byline | Use it for |
|---|---|---|---|
| **1 - Brand** | Collective "we" | The Sabre company page | Salience / brand lines, official announcements. Lowest reach - use deliberately. |
| **2 - Team** | A defined group | "The Sabre Mosaic team" | Product or team posts. |
| **4 - Named person** | A named individual with a view, "I" | A named Sabre person + title | The default for Authority, Get-talked-about, and story. Far more reach and more trust. |
| **5 - Senior leader** | A leader's own voice | A named exec | A genuine leadership stance on a category shift. |

**Default to a named person (register 4)** for anything that needs to travel, and reserve the company page for brand/Salience moments where a corporate "we" is the point. Set the byline first; the voice follows.

---

## 6. Two craft moves worth using

- **Voice-matching:** if the named person has real posts, paste 150-250 words of their actual writing and match it, so the post sounds like them and not generic LinkedIn. (Futurepedia, 2026.) This is a supplied input, not something to invent - if you don't have a sample, write to the Sabre voice and flag that a voice sample would sharpen it.
- **Audience-language mining:** where real audience comments/replies are supplied, lift the exact phrases and pains they use. Using the reader's own words is what makes a post feel like it gets them. (Use only supplied material - never invent a quote or a pain, per the content gate.)
