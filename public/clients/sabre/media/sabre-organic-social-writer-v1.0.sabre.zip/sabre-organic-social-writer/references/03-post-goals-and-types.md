# 03 - Post goals and types

A social post has one job. Not two. The single most common failure on LinkedIn is a post trying to do three things, so it does none. Before writing a word, diagnose the one goal, and write the whole post (hook, body, visual, ask) to serve it. This is the social equivalent of choosing the email type, and it sets everything downstream.

> This framework is Paul Dervan's LinkedIn strategic-analysis system, built from analysing hundreds of posts, turned from a diagnostic into a writer. The diagnostic asks "what is this post trying to do, and does it?" The writer commits to the answer first.

---

## The five goals (pick ONE primary, at most one secondary)

| # | Goal | Strategic purpose | What success looks like |
|---|---|---|---|
| 1 | **Salience** | Build mental availability. Be the name they remember when the need arises. | A memorable phrase or visual. Saves, not just likes. |
| 2 | **Get talked about** | Spark conversation, debate, shares. Manufacture social proof. | Comments > likes. Reshares with added commentary. |
| 3 | **Value add** | Deliver real, usable utility. Build trust by being helpful. | Saves and bookmarks. "This helped me" replies. |
| 4 | **Authority build** | Establish a distinctive point of view. Show original thinking, not a recap. | "Never thought of it this way" replies. Follows. |
| 5 | **Strategic CTA** | Drive one specific action toward a business goal. | Comments/DMs, sign-ups, replies to the ask. |

Most Sabre posts will be **Authority build** or **Get talked about** (the brand is a knowing, provocative challenger), with **Value add** for the practitioner audience and **Salience** for the brand line. **Strategic CTA** is the rarest and should be used sparingly; a feed full of asks stops working.

**Why this matters for reach:** LinkedIn's algorithm rewards conversation over distribution. Posts that earn comments get more reach than posts that get shared without discussion (Tom's Marketing Ideas, 2026, from analysis of hundreds of posts). And saves now matter more than likes (Brewton citing Chris Donnelly, 2026). So the goal you pick should map to a real engagement behaviour, not "likes".

---

## The goal sets the preview strategy

The hook (the visible bit before "...more") is written differently for each goal. Do not apply one hook rule to all of them. (Full hook craft is in `06-hooks-formulas-and-cadence.md`; this is the goal-to-preview map.)

| Goal | Preview strategy |
|---|---|
| **Value add** | Front-load the utility. Deliver the help immediately. Never hide the tip behind "...more". |
| **Authority build** | Preview the unique insight, not a vague tease. Tension or a bold claim, but show the logic is coming. Authority is not built with mystery. |
| **Get talked about** | Lead with the debate: a polarising idea or a hard truth, framed to provoke discussion early. Do not resolve the tension before the fold, or the scroll dies. |
| **Salience** | A memorable, visual-first phrase. A sticky slogan or metaphor beats tactical advice. |
| **Strategic CTA** | Preview the tangible benefit or outcome that justifies acting. |

**Flag any post where the hook format mismatches the goal.** A Value-add post that hides its tip, or a Get-talked-about post that gives away the answer above the fold, is the most common and most damaging failure.

---

## The four laws (judgment filters, every post)

1. **The preview is the ad for the ad.** Most readers never click "...more". If the visible preview doesn't stop the scroll and serve the goal, nothing else in the post matters. The preview determines 60-70% of the post's success.
2. **Vulnerability is the value, not a setup for it.** In a story or trust post, the human moment IS the offer. Don't bolt a framework onto it to feel useful.
3. **If it's unclear what the post wants the reader to think, feel, or do, it has failed.** Strategic clarity beats cleverness.
4. **Authority isn't built with mystery.** A contrarian or expert take previews the reasoning; it doesn't hide it behind intrigue.

---

## The five goals as post types - structure and watch-outs

### 1. Salience post
**Job:** lodge one Sabre idea or phrase in memory. Short, sharp, repeatable.
**Structure:** a memorable line (the hook is most of the post) → one line of grounding → optional sign-off. The brand line or anchor does the work.
**Watch-outs:** don't explain the metaphor to death. Salience lives in the phrase, not the paragraph. Reach for a distinctive Sabre code (a recurring phrase, a visual) so it compounds over time.

### 2. Get-talked-about post
**Job:** start a real conversation. A grounded, debatable position that invites disagreement.
**Structure:** the provocation (specific, not a generic "most people are wrong") → the reasoning → an open question that genuinely invites a reply.
**Watch-outs:** the jab lands on the old way / the industry habit, never on the reader (the brand rule). Don't resolve the tension above the fold. The contrarian claim must be specific and supported, not a sweeping generalisation (which the slop audit bans as the LinkedIn-bro tell).

### 3. Value-add post
**Job:** teach one usable thing. The reader should be able to act on it today.
**Structure:** the promise/utility up front (no teasing) → the substance (a tight how, two to four real points) → a line on where it applies.
**Watch-outs:** never bury the value behind "...more". Don't pad to a round number of tips. The visual must reinforce the specific utility, or it confuses the offer.

### 4. Authority-build post
**Job:** show a distinctive point of view only Sabre would hold. Original thinking, not a recap of the discourse.
**Structure:** the insight or tension previewed plainly → the argument, evidence before opinion → the so-what for the reader.
**Watch-outs:** preview the logic, don't hide it. A bold claim needs immediate support ("Recruiters took six weeks. The tool got interviews in three days" beats "the tool beats recruiters"). If anyone in the category could have written it, it isn't authority.

### 5. Strategic-CTA post
**Job:** drive one specific action (register, reply, download, book).
**Structure:** the benefit/outcome that justifies acting → minimal context → one clear ask.
**Watch-outs:** one ask only. LinkedIn suppresses off-platform links, so prefer an on-platform action (comment, DM, reply) or put the link in the first comment. Use this goal sparingly across a content calendar.

---

## A note on the format and the cadence

The goal also informs the format (text-only, carousel, document, image, video) and where the post sits in a series. Those live in `05-platform-and-format.md` (formats, the algorithm, the visual diagnostic) and `06-hooks-formulas-and-cadence.md` (hooks, formulas, posting cadence, byline). Diagnose the goal here first; choose the format and hook there.
