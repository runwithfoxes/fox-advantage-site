# 05 - Platform, format, and the algorithm

How LinkedIn actually works, what the feed rewards, and the containers a post fills. Copy is written to fit the platform, not the other way round. The numbers here come from Paul's 2026 LinkedIn research (sources named inline) so the writer works from evidence, not folklore.

> The single highest-leverage element is the **hook** - the first line or two visible before "...more". Most readers never expand the post. Full hook craft is in `06-hooks-formulas-and-cadence.md`; this reference covers the structure around it, the formats, and the algorithm it all has to survive.

---

## The structural blocks (in order)

| Block | Rule |
|---|---|
| **Hook** | The first 1-2 lines, roughly 200 characters but the real cut is ~the first 2 lines before "...more". Its only job is to earn the click-to-expand, in the way the diagnosed goal requires. Pattern interrupt, not summary. |
| **Body** | Short paragraphs, often 1-2 lines each, but VARIED (a wall of identical one-liners is the AI tell, see slop audit item 9). One idea per paragraph. White space is structure. Written for a phone. |
| **The turn / payoff** | The post has to deliver what the hook promised. For a story, the human moment; for value, the actual tip; for authority, the reasoning. |
| **Engagement driver** | A genuine question or a line that invites a reply (comments drive reach more than shares). Not a tacked-on "Agree?" - that is a slop tell. |
| **CTA (optional)** | Only on a Strategic-CTA post. One ask. Prefer an on-platform action; if a link is essential, put it in the first comment (see links, below). |

---

## How the algorithm actually behaves (2026)

Write to these realities, not to 2019 LinkedIn advice.

- **Saves > comments > likes.** The current algorithm prioritises saves, then conversation. Likes are the weakest signal. (Brewton citing Chris Donnelly, 2026.) Write posts worth saving (utility, a framework, a line worth keeping) and worth replying to.
- **Comments beat shares.** The algorithm rewards conversation, not distribution. A post that sparks discussion out-reaches one that gets silently reshared. (Tom's Marketing Ideas, 2026.) This is why the engagement driver matters.
- **The first ~90 minutes decide reach.** Early engagement after posting sets the ceiling. (Brewton citing Donnelly, 2026.) A post that lands flat early stays flat - so the hook and the first replies carry disproportionate weight.
- **Personal profiles massively out-reach company pages.** Since LinkedIn's 360Brew LLM update (March 2025), company-page reach fell ~60-66%, and personal profiles now get roughly 561% more distribution. (Brewton & Braadbaart, 2026.) Personal reaches 10-30% of connections; a company page 2-5% of followers (Herubel, 2026). **Implication for Sabre:** a post in a named person's voice will travel far further than the same post from the Sabre company page. Recommend the byline accordingly (see `06`).
- **Behavioural coherence is now required.** LinkedIn uses an ensemble of LLMs; a sequential model reads your posting history for semantic consistency. Posting across scattered topics suppresses reach. (Penn, 2026.) **Implication:** keep Sabre's posts in a coherent lane (open retailing, AI-native travel, the category) rather than scattershot.
- **Interest graph over follower graph.** Relevance increasingly beats follower count; a tight, niche audience can out-perform a big generic one. (Brewton, 2026.) Write for the specific Sabre buyer, not "everyone".

---

## Formats - what works and why

| Format | When to use | Evidence |
|---|---|---|
| **Text-only post** | The default for authority, get-talked-about, and story. The voice carries it. | Conversation-first; cheapest to read in-feed. |
| **Single image** | Pair with a text post to win the scroll. **Scrappy and unbranded beats polished.** A 1080x1350 image that looks a bit rough outperforms a designed one. "The more it looks like an ad, the worse the post performs." (Hassid, 2026.) |
| **Carousel / document** | Value-add and how-to. Outperforms single images because it gets **saved**, and saves drive reach. (multiple, 2026.) | Strong for utility content. |
| **Native video** | Story and authority, when motion helps. 79% are watched **without sound**, so subtitle everything; early motion in the first second lifts retention. (Bunting/LinkedIn, 2020.) | |

**The format lifecycle warning.** A format that works gets copied until it stops. Whiteboard-style AI infographics went from pattern-interrupt to wallpaper within months (Hills, 2026). So: favour distinctive, slightly scrappy, on-brand formats over whatever trick is currently flooding the feed, and expect to refresh.

**The healthy mix** (Herubel, managing dozens of B2B brands, 2026): roughly 40% educational, 40% carousels, 20% personal/POV. A guide, not a rule.

---

## The visual diagnostic (when a post carries an image or video)

Five checks, from Paul's framework and the attention research:

1. Does the visual help the scroll-stop?
2. Does it reinforce the post's one strategic message? (A disconnected image confuses the offer.)
3. **Does it feature a face?** ~80% chance a viewer fixates on a face in the first two eye movements. Faces facing the headline redirect attention to it; **faces on the left** support natural left-to-right scanning. (This matches Sabre's own faces-left rule.)
4. **Does it include motion or implied motion?** Movement breaks scroll inertia. Even someone mid-action beats a static pose.
5. Is the composition simple and single-focus? Detailed visuals die on a phone screen.

For a value-add post especially, the visual must show the utility, not decorate around it.

---

## Links, hashtags, mentions (the mechanics)

- **Links:** LinkedIn suppresses posts with off-platform links in the body. If a link is essential, put it in the **first comment** and say so in the post. Better still, for non-CTA goals, run the post with no link at all and let it earn reach.
- **Hashtags:** a few relevant ones at most; they are weak signal now, not a reach lever. Never stuff them.
- **Mentions:** tag a person or brand only when it's genuinely relevant (a real collaborator, a real source). Irrelevant tagging reads as reach-gaming.

---

## What this means for the writer (practical)

1. Write the **hook first and hardest** - it decides whether the rest is seen.
2. **Vary the line lengths.** Never a stack of identical one-liners.
3. Build in a **genuine reason to comment**, because conversation drives reach.
4. Default to a **named-person byline** over the company page (561% more reach), unless the post is explicitly a brand/Salience line.
5. Keep posts in a **coherent topic lane** so the algorithm reads Sabre as an authority on one thing.
6. For visuals: **scrappy over polished, a face on the left, motion over static, one focus.**
7. **No body links** unless it's a CTA post; then first comment.
