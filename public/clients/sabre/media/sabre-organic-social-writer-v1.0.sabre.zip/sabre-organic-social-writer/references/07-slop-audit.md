# 07 - AI-Slop Audit (Mandatory Two-Pass)

> Shared Sabre writing core. The same two-pass audit applies to every channel. This copy is tuned for organic social; notes flag where social differs. Social has one extra tell on top of the universal ones: the LinkedIn-template skeleton (one-line hook, three one-line "value" lines, a "Here's the thing", an "Agree?" closer). That formula is itself the slop. Vary the rhythm and lead with a real point of view, not the template.

Every piece must pass both passes before it is shown to the user. Not optional. Not a vibe check. Both passes, both documented, evidence shown.

---

## Why This Matters

Senior travel and hospitality execs read a lot of vendor content. They recognize AI cadence on the first sentence. Copy that reads like it came off a template - however accurate the facts - signals that Sabre's team didn't think hard enough to write it themselves. That undermines the relationship before any argument is made. Both passes below are mandatory. They catch different things: Pass 1 catches words, Pass 2 catches patterns.

---

## PASS 1 - Word-List Slop Guide

### Extreme overuse - never use these

| Avoid | Use instead |
|-------|-------------|
| Delve into | Explore, examine, look at |
| Harness the power | Use, apply, take advantage of |
| Unlock potential | Enable, help achieve |
| At its core | Essentially, basically |
| Leverage | Use, apply, build on |
| Seamless / seamlessly | Smooth, easy, works well |
| Revolutionary | New, different, advanced |
| Game-changing | Important, significant |
| Cutting-edge | Advanced, modern, latest |
| Unprecedented | Unique, first of its kind |
| In today's fast-paced world | (Delete. Start with your actual point.) |
| In the ever-evolving landscape | (Delete. Start with your actual point.) |
| It is important to note that | (Delete. Just state the point.) |
| In order to | To |
| Captivate | Engage, interest |
| Elevate | Improve, raise, strengthen |
| Empower | Give, enable, help |
| Transformative | Effective, significant |
| Dynamic | Active, changing, flexible |
| Holistic | Comprehensive, complete, full |
| Tapestry | (Don't use in business writing) |
| Realm | Area, field, space |
| Symphony | (Don't use in business writing) |
| Alchemy | (Don't use in business writing) |
| Odyssey | Journey, path, effort |

### High overuse - avoid in Sabre copy

| Avoid | Use instead |
|-------|-------------|
| Underscore | Highlight, show, make clear |
| Pivotal | Important, crucial, key |
| Navigate | Handle, manage, deal with |
| Illuminate | Explain, clarify, reveal |
| Facilitate | Help, enable, make easier |
| Optimize | Improve, make better |
| Comprehensive | Complete, full, thorough |
| Robust | Strong, solid, reliable |
| Streamline | Simplify, make more efficient |
| Resonate | Connect, land, click with |

### Transition phrase red flags

| Avoid | Use instead |
|-------|-------------|
| Moreover / Furthermore | Also, plus, and |
| That being said | However, but, still |
| It's worth noting | (Delete. Just note it.) |
| In light of this | Because of this, so |
| At the end of the day | Ultimately, in the end |
| Moving forward | Next, going ahead |
| By the same token | Similarly, likewise |
| To put it simply | In short |
| In conclusion | Finally, (or just conclude without a flag) |
| Firstly / Secondly / Thirdly | First / Second / Third, or drop them |
| Without further ado | (Delete entirely) |

### Business buzzwords that destroy credibility

| Avoid | Use instead |
|-------|-------------|
| Synergy | Working together, combined effect |
| Paradigm shift | A change in approach, a new model |
| Disruptive | (Show why it's new - don't label it) |
| Best-in-class | (Provide proof or omit) |
| Thought leader | (Demonstrate it, don't declare it) |
| Low-hanging fruit | Quick wins, easy opportunities |
| Move the needle | Make a measurable impact |
| Circle back | Follow up |
| Touch base | Connect, reach out |
| Bandwidth (for capacity) | Capacity, time, ability |
| Future-proof | Built to last, prepared for change |
| Scalable solution | (Specify how it scales or omit) |
| Value proposition | Value, benefit, what you get |
| Ecosystem (vague use) | Network, environment, market |
| Think outside the box | Think creatively |
| Now more than ever | (Specify why now or delete) |
| For all your needs | (Be specific about which needs) |

### AI opener cliches - never open a piece with these

- "In today's fast-paced travel industry..."
- "In the ever-evolving landscape of hospitality..."
- "In a world where travelers expect..."
- "It could be argued that..."
- "Some experts say..." (name them or don't cite them)
- "Have you ever wondered..."
- "Let's face it..."
- "The fact of the matter is..."
- "Most airlines / hotels / travel companies [generic claim]..." - the contrarian-generalisation opener. Reads as LinkedIn-bro, worst of all as a headline. Don't reach for "Most [group]..." as a default hook. Either make the claim specific and grounded in the reader's actual world (a real, attributable observation, not a sweeping "most of you are getting this wrong"), or drop the setup and start on the concrete point. A specific contrarian observation is fine; a generic one dressed as insight is the tell.

### AI closer cliches - never end a piece with these

- "Remember: [platitude]"
- "In conclusion..."
- "At the end of the day..."
- "The future belongs to those who..."
- "The question isn't whether X will happen, but when."
- "Thoughts?"
- "Agree?"

### Punctuation and formatting tells

| Tell | Rule |
|------|------|
| Em dashes ( - ) | Zero tolerance. Use a period, comma, colon, or rewrite the sentence. |
| Excessive colons and semicolons | Break the sentence instead. |
| Bullet point overload | Only list 3+ genuinely parallel items. Each bullet must have real substance. |
| Title Case In Subject Lines or Headers | Use sentence case. Title Case reads as template. |
| Emojis as formatting | Not in Sabre B2B writing. None. |
| Excessive bold | One key phrase per section at most. Not every sentence. |
| "Emphasis" in quotation marks | Use a more precise word or italics. |
| Single-sentence paragraphs as default | Mix lengths naturally. One-liners are for genuine emphasis, not habit. |

### Structural patterns to eliminate

- Uniform paragraph length - every paragraph the same number of sentences
- Hook-points-CTA formula applied identically to every piece
- First / Second / Finally enumeration as the default structure
- Predictable topic order: "What is X? Why does X matter? How to do X?"
- Repetitive sentence construction: "X is important because Y. Z is critical because W."
- Checklist of points with no connecting argument
- Identical intro-body-close template recycled across pieces

### Tone and voice tells

- Overly neutral: no opinion, no angle, hedges everything
- Excessive hedging: "It appears that...", "In many cases...", "Some might say..."
- Fake enthusiasm: "Incredible results!" without evidence
- Generic empathy: "We understand your challenges" without specifics
- Corporate passive voice and self-important phrasing
- Discussing customer challenges in a detached, clinical way
- Forced conversational tics: "Why, you ask? Well...", "Guess what?"

---

## PASS 2 - AI Detection Checklist (Jabarian & Imas, Chicago Booth, Sept 2025)

**Source:** "Artificial Writing and Automated Detection", SSRN 5407424. Study tested 1,992 passages across 4 LLMs and 3 commercial detectors.

Pass 1 catches words. Pass 2 catches patterns. Detectors don't read for meaning - they read for statistical fingerprints. These are the ten fingerprints.

**For organic social, items 1, 2, 3, 5, and 7 matter most** - the post is short, so every line is exposed. The killers are uniform one-line-paragraph cadence (statistical smoothness), transitional scaffolding, predictable word choice, the template skeleton (structural predictability), and the absence of a genuinely original point (no surprise). A post that any vendor could have written is the tell.

---

### 1. Statistical smoothness
**Tell:** LLM text has unnaturally even sentence length, paragraph size, and complexity. Human writing is lumpy. A 4-word sentence next to a 38-word one.

**Fix:** Vary sentence length deliberately. Mix short punches with longer, winding thoughts. Don't let three consecutive sentences land within 5 words of each other in length. Break rhythm on purpose.

---

### 2. Transitional scaffolding
**Tell:** LLMs over-use connective tissue: "furthermore," "additionally," "moreover," "in conclusion," "it's worth noting." These appear at rates humans rarely match.

**Fix:** Cut transitional phrases. Let the logic carry itself. If two sentences connect, the connection should be obvious without a signpost. When a transition is genuinely needed, use a short one: "But," "And," "So," "Still."

---

### 3. Lexical predictability
**Tell:** LLMs reach for the statistically probable next word. Detectors measure how predictable the word choices are. Even non-slop words can fail this if they're the obvious choice.

**Fix:** Use concrete, specific, unexpected words. "Stalled" not "stopped." "Clattered" not "fell." Prefer the word a well-read person would actually say over the word that sounds correct. The word-ban tables above help here, but go further: any word that feels like the obvious choice should be reconsidered.

---

### 4. Hedging uniformity
**Tell:** LLMs hedge everything the same way: "It's important to note," "while there are many factors," "this can vary depending on context."

**Fix:** Either commit to the claim or cut it. If hedging is appropriate, do it once and specifically: "This worked for regional airlines; international routes are a different calculation." Not "results may vary."

---

### 5. Structural predictability
**Tell:** LLM text follows reliable patterns: intro paragraph, three supporting points, conclusion. Each section roughly the same length. Lists in threes or fives.

**Fix:** Let structure follow the argument. Some points need one sentence, others need a paragraph. Lists can have two items or seven. Start in the middle of the argument if that's more interesting.

---

### 6. Emotional flatness
**Tell:** LLM text maintains a steady emotional register throughout. It doesn't get sharper when the stakes are high or more casual when the point is lighter.

**Fix:** Match energy to content. An important claim should feel important. A throwaway aside should feel like one. Don't write the whole piece at one temperature.

---

### 7. Absence of genuine surprise
**Tell:** LLM text rarely says anything the reader wouldn't expect. It summarizes known positions competently but doesn't introduce a genuinely unexpected angle.

**Fix:** Include at least one thing per piece that couldn't have been predicted from the brief. A counterintuitive observation. A specific connection only someone with sector knowledge would make. If the copy could have been written by anyone given the same inputs, it reads as AI.

---

### 8. Perfect grammar as a signal
**Tell:** Ironically, flawless grammar is now a detection signal. Human writing has minor imperfections: sentence fragments for emphasis, starting with "And," ending with a preposition, comma splices used deliberately.

**Fix:** Don't clean up natural speech patterns. "And that's the thing" at the start of a paragraph is fine. The goal is writing that sounds like a specific, knowledgeable person wrote it - not a copy-edited press release.

---

### 9. Length management
**Tell:** Length isn't the social risk (posts are short); uniformity is. A LinkedIn post built as a stack of identical one-line paragraphs is maximally smooth and maximally detectable, even at 80 words.

**Fix:** Vary the line lengths on purpose. A short punch, then a two-line thought, then a one-liner. Never a wall of identical one-line paragraphs, which is the default LinkedIn-AI cadence. Keep the post as long as the idea needs and no longer; if it runs past ~250 words it had better earn every line. Line breaks are for rhythm and scannability, not decoration.

---

### 10. Over-attribution
**Tell:** LLMs attribute everything: "According to research," "studies show," "experts suggest." Humans often state things as known without citing a source for every claim.

**Fix:** State things you know directly. "Carriers that held distribution share during COVID recovered yield 18 months faster" not "Research suggests that carriers which maintained distribution during the pandemic tended to experience faster yield recovery." Save attribution for when the source matters to the argument.

---

## CRITICAL GOTCHA: Em Dashes Creep Back In

When applying detection-pass fixes - especially varying sentence structure or fixing statistical smoothness - an AI will often reintroduce em dashes. They are a natural output of rewriting complex sentences.

**Always re-strip em dashes after the detection pass.** Run a final search for - before any piece is shown. Target: zero.

---

## The Evidence Requirement

The audit is not "done" when you've mentally run through the list. It is done when you can show the work.

After both passes, report explicitly:

> **Slop audit clean - N fixes applied:** [list what changed]

Examples of valid evidence:
- "Cut 2 em dashes, replaced 'leverage' with 'use', broke a three-point landing into two paragraphs"
- "Removed 'moreover' and 'in light of this', varied sentence length in paragraph 3, replaced 'seamless' with 'straightforward'"
- "Rewrote opener to remove AI cliche, cut transitional scaffolding in body, added one unexpected observation about yield recovery timing"

A check only gets ticked when the evidence is shown. "Slop audit: clean" with no detail is not acceptable - it means the audit was not run.

---

## Quick Audit Checklist

**30-second visual scan:**
- [ ] Uniform paragraph lengths?
- [ ] Excessive bullet points?
- [ ] Em dashes (target: zero)?
- [ ] Generic opener or closer?
- [ ] Title Case in subject line or headers?

**2-minute phrase search:**
- [ ] Search for: delve, leverage, moreover, furthermore, seamless
- [ ] Search for: "it is important to note," "in today's," "at the end of the day"
- [ ] Search openers/headlines for "Most airlines / hotels / travel / companies" (the LinkedIn-bro contrarian hook - rework to specific or start on the concrete point)
- [ ] Count em dashes (target: zero)
- [ ] Check transition density - more than one per few hundred words is too many

**5-minute detection-pass check:**
- [ ] Sentence length varied? (not three consecutive sentences of similar length)
- [ ] Any genuinely unexpected observation in the piece?
- [ ] Structure follows argument, not a hook-points-CTA template?
- [ ] Energy matches content - not written at one temperature throughout?
- [ ] Does it read like different sittings across sections, not one smooth generation?

**After both passes:**
- [ ] Em dash re-check (detection-pass rewrites often reintroduce them)
- [ ] Evidence statement written and shown
