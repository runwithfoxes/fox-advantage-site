# Changelog - Sabre Organic Social Writer

How to read this: the version number is in `SETUP.md` and in the zip filename
(`sabre-organic-social-writer-v1.0.sabre.zip`). If the filename you downloaded matches the
version you already have loaded, it's the same skill. A higher number means a newer set.

## v1.0 - 28 June 2026

- First release. A narrow organic-social writer, LinkedIn-first, built on three foundations:
  1. The Sabre email/blog writer core (shared voice, writing rules, positioning spine,
     slop audit, and the verification ledger - every claim gets a row, a status, and a
     pasted source; nothing is WEB-VERIFIED without a real URL).
  2. Paul Dervan's LinkedIn strategic-analysis framework, turned from a diagnostic into a
     writer: the five post goals (Salience / Get talked about / Value add / Authority build /
     Strategic CTA), the goal-to-preview map, the four laws, and "the preview is the ad for
     the ad".
  3. 2026 LinkedIn craft research (from the nugget database, sources cited inline): the
     algorithm (saves > comments > likes, first 90 minutes, personal profiles ~561% more
     reach than company pages since 360Brew, behavioural coherence), hook construction
     (~55 chars / 2 lines, pattern interrupt), formats (scrappy beats polished, carousels
     win on saves, 79% of video watched silent), the visual diagnostic (face left, motion),
     and the anti-patterns (template skeleton, vanity metrics, format saturation).
- Plan-first behaviour: declares goal, byline, format, hook, value theme and structure
  before writing, then proves the facts, then shows its working.
- Output order: plan → post → verification ledger → writing-checks panel → flags.
