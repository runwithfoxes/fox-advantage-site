# Sabre Email Writer - setup (Claude.ai)

**Version 2.2** · 28 June 2026 · see `CHANGELOG.md` in this folder for what changed. If the version here matches the copy you already have, it's the same skill, no need to re-import. (v2.2 adds a verification ledger that proves every claim with a pasted source.)

A narrow, deep email writer that drafts Sabre marketing emails in Sabre's brand voice, across the nine email types you actually send. It declares its plan before it writes, then shows its working, so you can see it didn't cut corners.

## What it does

- Covers nine email types: webinar invite, event invite, event/webinar follow-up, campaign brand, campaign product, survey, CEO/senior-leader, operational, and research/report launch. ABM is handled as a variant on top of these.
- The report-launch type is built to Darren's preferred shape (short entertaining hook, 2-3 lines of context naming who was surveyed, three bullet findings, one download CTA, 100-200 words) and backed by research into how HubSpot, Salesforce, LinkedIn and McKinsey launch reports.
- Writes in the real Sabre voice (upbeat, knowingly provocative, endlessly supportive - the jab lands on the old way, never on the customer).
- Holds a hard quality bar: no em dashes, no exclamation marks, sentence case, no generic B2B, and a two-pass AI-slop audit on every email.
- Fits the 2026 email templates: headline and sub-header to two lines each, one benefit-led call to action with a → arrow.
- Never invents facts. If you don't give it the proof, the stat, or the names, it won't make them up - it flags the gap instead.
- Proves its facts with a **verification ledger**: every checkable claim (every stat, named person, customer, quote, competitor claim) gets its own row with a status and a pasted source. Nothing is marked "verified" without a real source link. If it can't prove a claim, it brackets it or flags it for you - it never quietly leaves an unproven fact in. (New in v2.2.)

## How it works each time

1. **It declares a plan first** - the email type, the angle, the one value theme, the structure, and a candidate headline - before writing a word. This primes a better email and shows it did the thinking.
2. **It writes the email.**
3. **It proves the facts** - a verification ledger, one row per claim, with a status and a pasted source. Then it walks a pre-send checklist.
4. **It shows its working** - the writing checks it ran and the actual fixes it made.

If it's missing something important (a real result, approved product messaging), it tells you in the plan and marks the email a draft rather than papering over the gap.

## Set it up in Claude.ai (5 minutes)

1. Go to **claude.ai** → **Projects** → create a new project (or open an existing Sabre project).
2. Open **Project knowledge** (or the project's Skills, if available to your plan).
3. Upload the contents of this folder: `SKILL.md` and the whole `references/` folder. Keep the structure as-is.
4. Start a chat in the project and ask, for example:
   - "Write a webinar invite for [session]. Here are the details: [paste speaker, date, time, what they'll learn, the audience]."
   - "Draft a follow-up for the agencies who attended Tuesday's session. Resources: [deck link, recording link]."
5. Answer its setup questions (who it's for, the one action you want, what proof you have). The more real material you give it, the stronger the email.

## Tips

- **Give it real content.** It enhances what you provide; it does not invent. Case studies, named results, dates, speakers, existing copy - all make the email better.
- **Pick the length.** It defaults to shorter (drives a click). Ask for "longer" when the email needs to explain in-message, or "test" for both a short and a long version to A/B.
- **Ask it to "show your working"** any time you want the full checklist of inputs and checks.
- **Out of scope:** decks (use the Sabre presentation skill), social posts, and landing pages. It will tell you and point you elsewhere.
