# 02 - Writing rules: the hard bar

Every Sabre email must clear every rule below before it ships. One failure = rewrite. No exceptions, no "close enough."

> **Note on real Sabre examples:** Sabre's own emails sometimes break these rules - em dashes in headlines, Title Case subject lines, the occasional exclamation mark. We hold the higher bar anyway. These are AI credibility tells and craft signals; our standard beats their house style. When you see a real Sabre email that violates a rule, the rule still stands.

---

## 1. Hard constraints

Fail any one of these and the email needs a rewrite.

| Rule | What's banned | Fix |
|---|---|---|
| **No em dashes** | - (em dash) in any context | Use a comma or a full stop |
| **No exclamation marks** | ! anywhere | Remove; let the language do the work |
| **No passive voice** | "It is being built," "solutions are provided" | "We're building," "we provide" |
| **No generic B2B phrases** | See list below | Replace with specific, earned language |
| **No fabricated claims** | Stats, data, case study details not supplied by the user | If it isn't in your materials, it doesn't exist |
| **No flat verbs** | See list below | Upgrade to punchy alternatives |
| **Sentence case only** | Title Case Headlines or Subject Lines | Sentence case everywhere |

### Generic B2B phrases - banned

These could come from Amadeus. They cannot come from Sabre.

- "Unlock opportunities" / "unlock new opportunities"
- "Seamless integration"
- "End-to-end solutions"
- "Leverage" (in any form)
- "Best-in-class"
- "Cutting-edge"
- "Holistic approach"
- "Digital transformation"

### Flat verb upgrades

| Don't write | Write instead |
|---|---|
| improve | boost |
| start | kick off |
| change | shift |
| move quickly | whizz |
| help | champion |
| pull | yank |
| open | pry |

---

## 2. AI rhythm detection

**The problem:** AI defaults to a predictable beat - short punch, medium sentence, marketing punch, marketing punch. Senior travel executives spot it before they reach the second paragraph.

**The core principle:** Human writing develops an idea across sentences. AI restates the same idea with different emphasis. If every sentence in a paragraph could stand alone as a bullet point, it's AI rhythm.

### Rules

- **Never stack punchy sentences.** After a short landing sentence, the next must be longer and more substantive. Two punchy sentences in a row = rewrite.
- **Vary paragraph structure, not just sentence length.** Some paragraphs are one long sentence. Others mix three different lengths. Predictability kills credibility.
- **The three-point landing is a giveaway.** Three consecutive sentences each ending on a "point" = AI slop. Restructure so the paragraph develops rather than lands three times.
- **Read it aloud.** If it sounds like a product-demo voiceover or a keynote speech, rewrite. It should sound like a specific person thinking through a specific problem.

### The test

Could a skeptical CMO read this aloud to their team without it sounding like a script? If no, rewrite.

### Examples

❌ "The travel industry is changing. Fast. And the companies that adapt will thrive. The ones that don't will be left behind."

❌ "This isn't about technology. It's about transformation. It's about putting travelers first. It's about building for the future."

✅ "Airlines have known their pricing engine is a constraint for years, but the switching cost calculation keeps coming out negative. What's changed is that the constraint is now visible to customers, not just revenue managers, and that visibility has a cost that's harder to model."

The difference: the ❌ examples restate. The ✅ example develops.

---

## 3. Construct limits

Overuse of these constructs is how AI writing gets caught. Each one is a tool, not a tic.

| Construct | Limit | Rule |
|---|---|---|
| Rhetorical questions | Max 1 - 2 per email | Never in consecutive paragraphs |
| "This isn't X, it's Y" | Once per email max | Must be grounded in specific evidence; the contrast must be genuinely surprising |
| Parallel triplets ("From X to Y. From A to B.") | Once max | Three consecutive fragments each landing on a point = rewrite |

### Banned openers (AI tells - never use)

- "Here's the thing"
- "Here's why"
- "Let's be clear"
- "Make no mistake"
- "The reality is..."

---

## 4. Anti-patterns - never ship

### Generic B2B (could be any company)

"Unlock new opportunities" / "Dismantling siloes" / "End-to-end solutions" / "Leverage our platform" / "Digital transformation" / "Best-in-class" / "Cutting-edge" / "Seamless integration" / "Holistic approach"

### AI and junior-writer tells

"Level up" / "Tailor-made" / "Value prop" / "Done right..." (as an opener) / "Game-changing" / "Revolutionary" / "In today's competitive landscape" / "Now more than ever"

### Passive and corporate constructions

| Passive | Active |
|---|---|
| "It is being built" | "We're building" |
| "Solutions are provided" | "We provide" |
| "Value is delivered" | "You get" |
| "The decision was made" | "We decided" |

### Safe headlines - avoid

These are the Amadeus playbook, not the Sabre one:

- "The future of travel technology"
- "Innovating for tomorrow"
- "Your partner in digital transformation"
- "Leading the way in travel tech"

Instead, challenge: "They lock you in. We free you up."

---

## 5. Style mechanics

| Element | Rule |
|---|---|
| **Language** | American English throughout |
| **Headlines and subjects** | Sentence case only - never Title Case |
| **Contractions** | Yes - they're warmer and more natural |
| **Oxford comma** | Omit unless it genuinely aids clarity |
| **Em dashes** | Never |
| **En dashes** | Ranges only (pages 10 - 14, June - August) |
| **Exclamation marks** | Never |

### Numbers

| Rule | Example |
|---|---|
| Spell one through nine | "three airlines," "nine months" |
| Numerals for 10 and above | "14 markets," "200 carriers" |
| Comma for numbers over three digits | 1,000 / 47,000 |
| Use % symbol with numerals | 34% not "34 percent" |
| Spell fractions | two-thirds, not 2/3 |

### Dates and time

| Rule | Example |
|---|---|
| Month-day-year | January 7, 2026 |
| Spell the month | January, not Jan or 1 |
| No ordinals | January 7, not January 7th |
| Numerals with am/pm and a space | 9 am, 3:30 pm |
| US time zones abbreviated | ET, CT, MT, PT |
| International zones spelled out | Central European Time |
