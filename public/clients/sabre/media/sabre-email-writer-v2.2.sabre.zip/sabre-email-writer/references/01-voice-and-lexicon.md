# Sabre email voice and lexicon

> Single reference for how a Sabre email sounds. Self-contained. No external files required.

---

## 1. The three voice traits

Voice stays the same across all Sabre content. Tone is the volume control. For marketing email: Upbeat = MED-HIGH, Provocative = MEDIUM, Supportive = MED-HIGH.

---

### Trait 1: Infectiously upbeat

Bright, natural, optimistic. Positive energy through clear writing. Even technical topics can lift the reader.

**How it works in email:**
- Vary sentence length for rhythm. Short = energy. Long = momentum. Never stack two punchy sentences.
- Lead with what's possible, not what's wrong.
- Active voice, punchy verbs throughout.

**Real Sabre examples:**
- "It's the reason our platform is open. And AI is hard-wired in. And we stay up when others go down. And a billion travelers can count on us."
- "You've never been so first."
- "Technology that takes you wherever you want to go."

---

### Trait 2: Knowingly provocative

Sharp, disruptive, witty. Words that make readers stop. Playful digs, done with maturity and intelligence.

**How it works in email:**
- Make direct comparisons against the status quo or competition.
- Challenge assumptions. Question conventional wisdom.
- Use surprising words and unexpected verbs. A riff off a cliché lands harder than a straight punch.

**Real Sabre examples:**
- "If you like being locked in to closed systems, then go with the other guys. But if you want to be in the pilot seat, then we're for you."
- "They lock you in. We free you up."
- "Whoever said 'slow and steady wins the race' has never won a race."

**CRITICAL RULE: The jab lands on the situation, never the customer.**

Humor lands on "the old way is ridiculous," never "you're doing it wrong." Jab at the status quo, the legacy system, the industry habit. Never at the person reading. If the reader could feel scolded, rewrite it.

---

### Trait 3: Endlessly supportive

Warm, relatable, specific. Meet the reader where they are and guide them forward. Respect what they know, add to it.

**How it works in email:**
- Write to one person. Place yourself in their shoes.
- Guide, don't lecture. Show the path forward.
- Be specific about how you help. Vague "support" is a waste of a sentence.

**Real Sabre examples:**
- "You see, we've rebuilt our entire business around you. And your success."
- "All to get you where you want to go. Because when you're on top, we're on top too."
- "We'll show you the way."

---

## 2. The Sabre difference in one line

We're not Amadeus. We prod with wit and clarity, the partner in their corner. We don't play their game.

### Competitor differentiation

| | Sabre | Travelport | Amadeus |
|---|---|---|---|
| **Tone** | Upbeat, provocative, supportive | Straight-talking, contemporary | Corporate, authoritative, optimistic |
| **Positioning** | Challenger with warmth | Efficient modern software | Established institution |
| **Language** | Personality-driven ("whizz", "crew", "champion") | Clean and empowering | "Dismantling siloes", "unlocking opportunities" |
| **Customer relationship** | Partner in your corner | Vendor-to-customer | The community that connects |
| **Tagline** | "Let's get going" | "Get Modern, Get Travelport" | "The community that connects travel" |
| **Sounds like** | An energized, provocative technology partner | Efficient modern software | An institution that's always been there |

---

## 3. Brand foundation quick-reference

| Element | Content |
|---|---|
| **Tagline** | Let's get going |
| **Who we're for** | The Ambitious |
| **Personality** | The Ultimate Customer Champion |
| **Brand focus** | Customer success |

**Brand values:**
- Them before us
- Open is a mindset
- Get there first
- Don't be afraid to poke the bear

**Messaging pillars:**

| Pillar | One line |
|---|---|
| **WHAT** | Open, modular, AI-native SaaS platform. Break free from closed systems. |
| **HOW** | Innovating together, around the same table, not in a vacuum. |
| **WHY** | We make you no. 1. Customer success is the only metric that matters. |

**Products:** Sabre Mosaic, Sabre IQ, Travel Data Cloud.

---

## 4. The real Sabre email lexicon

These phrases are mined from Sabre's actual sent emails. They are a palette, not a template. Using them all in one email makes it sound like a highlights reel. Use one or two per email, when earned, to calibrate the tone and make the copy sound unmistakably Sabre rather than generic B2B.

### Signature sign-off / CTA lines

- "Let's get going" (tagline use and natural sign-off)
- "Let's go further" (variant for follow-on or progression emails)

Note: the live emails use "Let's get going!" with an exclamation mark. This skill bans exclamation marks. Use "Let's get going" or "Let's go further" without the mark.

### Provocative beats (jab at the status quo)

These lines land on how broken or absurd the old way is, not on what the reader is doing wrong.

- "We don't do fluff."
- "Stay fast."
- "Stop wrestling with legacy hurdles. Start building the future of travel."
- "Stop waiting for 2030. Start retailing today."
- "You're already winning. Let's accelerate."
- "held to ransom" (as in: a legacy program held to ransom by a single vendor)
- "The people actually living it rarely get asked."
- "A real voice in the conversation."

### Product and positioning phrases

- "One platform, built to open."
- "built to open"
- "AI built, not bolted on."
- "No big-bang risk. No vendor lock-in."
- "built on top of your existing systems, from day one."
- "open, modular, AI-native"
- "This isn't a sales pitch. It's a technical masterclass for the people writing the code."

### Real CTA labels

Sabre's live CTAs end with a → arrow. Match this pattern.

- "Register now →"
- "Schedule a meeting →"
- "Take survey →"
- "Give us feedback →"
- "Explore your retailing shift →"
- "See for yourself here →"
- "Let's go further →"

---

## 5. On-brand word swaps

| Use this | Not this |
|---|---|
| Use | Utilize |
| Lets | Allows |
| Help | Facilitate |
| To | In order to |
| Smooth | Seamless |
| Simplify | Streamline |
| Change | Transforms (when "transforms" is doing no work) |
| Roll out | Implement |
| Co-solve | Work together |
| Hardwired | In-built |
| Tools | Solutions |
| Pilot seat | Driver's seat |
| Miles ahead | Leading |
| Tune | Optimize |
| Know-how | Expertise |
| People | Staff |
| Boost | Improve |
| Kick off | Start |
| Shift | Change |
| Whizz | Move quickly |
| Yank | Pull |
| Pry | Open (when forced) |
| Champion | Help |

**Punchy verb upgrades for email body copy:**

| Instead of | Use |
|---|---|
| improve | boost |
| start | kick off |
| change | shift |
| move quickly | whizz |
| pull | yank |
| help (as verb) | champion |

---

## 6. Hard constraints (fail any = rewrite)

- No em dashes. Use commas or full stops.
- No exclamation marks.
- No passive voice.
- No generic B2B phrases: "unlock opportunities," "seamless integration," "end-to-end solutions," "leverage," "best-in-class," "cutting-edge," "holistic approach," "digital transformation."
- No fabricated statistics, data, or claims.
- No flat verbs when punchy alternatives exist.
- No title case headlines. Sentence case only.
- No AI rhythm: never stack two punchy sentences. No three-point landings (three consecutive sentences each closing on a "point"). Read it aloud. If it sounds like a product-demo voiceover, rewrite.
- No banned openers: "Here's the thing", "Here's why", "Let's be clear", "Make no mistake", "The reality is..."
- No AI slop words: "level up", "tailor-made", "value prop", "game-changing", "revolutionary", "In today's competitive landscape", "Now more than ever."
- Rhetorical questions: max 1-2 per email, never in consecutive paragraphs.
- "This isn't X, it's Y" construction: once per email maximum.
- Parallel triplets ("From X to Y. From A to B."): once per email maximum.

---

> "Every time someone reads something from Sabre, they should know it's us. Let's get going."
