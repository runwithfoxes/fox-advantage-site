# Design Constraints - The Containers Our Copy Fills

Sabre's emails are built on a fixed 2026 template system. Copy is written to fit these containers, not the other way round. This reference defines the structural limits the copy must respect so the finished email is build-ready, not just well-written.

> The single most important constraint: **the header block is capped at ~200px**, which forces the headline and sub-header to be SHORT. Everything else follows from that.

---

## The header block (the hard limit)

Every marketing template opens with a header block containing, in order: **logo → headline → sub-header → CTA**. The whole block must fit in **~200px of height**.

| Element | Limit | Notes |
|---|---|---|
| **Headline** | **2 lines maximum** | The promise/hook. Sentence case (our rule). This is the highest-leverage copy in the email. |
| **Sub-header** | **2 lines maximum** | Extends the headline, explains what the email is. Does not repeat the headline. |
| **CTA** | short label + → arrow | e.g. "Register now →", "Explore your retailing shift →". Terracotta button. |

**Two header layouts exist:**
- **Stacked:** headline, sub-header, and CTA all left-aligned, one above the other.
- **Split:** headline on the left; sub-header + CTA on the right.

Write headlines that read in one glance and fit two lines at large type. If a headline needs three lines to make sense, it's trying to do the body's job - cut it back.

> This is the answer to the "how long should emails be?" question: **header and sub-header are tightly capped (2 lines each); the body is the variable.** Choose body length with the length mode (Shorter default / Longer / Test), not by stretching the header.

---

## The template types (match the email type to a template)

| Template | Used by email types | Shape |
|---|---|---|
| **Operational** (1A no header block / 1B with) | Operational | "Dear customer" → plain headline → body → "Your Sabre team". Operational often needs no marketing header block. |
| **Single story** (2A - 2D) | Campaign product, event invite, simple notes | Header block + hero image + "Title" + body + bullets + body + CTA. Optional photo signature (Name + title). |
| **Newsletter** (3A default / 3B extended) | Campaign brand, multi-story sends | Header block + alternating story blocks (text-left / image-right preferred, small divider between) + revert to full-width after two blocks. Extended "only where absolutely necessary." |
| **ABM** | any of the above, for a named account | Single story or newsletter + partner logo added to the header. |
| **Accelerate** | Accelerate program sends | Same templates; "Accelerate" as the header text, sub-header explains what the Accelerate email is about. |

**The body block** (inside single-story / newsletter) has its own structure: a **"Title"** sub-heading (separate from the header headline) → body paragraph → bullets (≈3) → body paragraph → CTA button. Keep paragraphs short (1 - 3 sentences), mobile-first.

**Sign-off / signature options:**
- "Your Sabre team" or "Your NAM Sales Team" (collective).
- A named individual: Name + title (e.g. "Senior Vice President, Airline Global Sales & Accounts"), optionally with a **photo signature**.
- "The Sabre Executive Leadership Team" (brand/leadership).

The signature block is effectively the register selector - see the register spectrum in the formulas reference.

---

## CTA mechanics

- One primary CTA per email (one CTA pulls far more clicks than several).
- Label is specific and benefit-led, never "learn more." Real Sabre labels: "Register now →", "Schedule a meeting →", "Take survey →", "Give us feedback →", "Explore your retailing shift →", "See for yourself here →", "Let's go further →", "Let's get going →".
- Always carries the **→ arrow**.
- Terracotta button, **square corners (no rounded corners - brand rule)**.
- Resource links in follow-ups (Presentation deck, Webinar recording) can be secondary buttons or bold links, placed high.

---

## Personalization tokens

Sabre emails use merge tokens. Write to them directly:
- `Hi {{Recipient.FirstName}},`
- `Dear {{Recipient.FirstName}},`

When a token is the opener, remember the first body line shows as mobile preview text - make the line after the salutation carry the hook.

---

## Brand facts (for any rendered/designed output)

These rarely affect copy but matter if the skill ever helps spec the visual:
- **Primary accent:** Terracotta `#E2553C`. Solid colors only - no gradients, no drop shadows, no rounded corners, no glow. Sabre is clean and flat.
- **Backgrounds:** off-white/beige `#F3EFE4`, black `#000000`, terracotta.
- **Typeface:** APK Galeria (Semi-Bold for headlines, regular for body); Arial fallback.
- **Marks:** the "sabre" wordmark + the compass/diamond device + ® on brand moments. These come from the template - never hand-place them.
- **Imagery:** cinematic, motion-blur, travel scenes (the brand photography style).

---

## What this means for the writer (practical)

1. Write the **headline to 2 lines** and the **sub-header to 2 lines** at the top of every marketing email. If they don't fit, they're too long - tighten, don't spill into a third line.
2. Pick the **template** that matches the email type (table above) and write to its blocks.
3. Give every email **one CTA** with a real benefit-led label and the → arrow.
4. Write to the **merge token** opener.
5. Keep body paragraphs **short and mobile-first**; use the "Title" sub-heading to break the body.
6. The header carries the hook; the **length mode** decides how much the body explains.
