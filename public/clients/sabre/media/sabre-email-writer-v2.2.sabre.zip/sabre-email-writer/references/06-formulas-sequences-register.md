# 06 - Formulas, sequences, and register

The structural toolkit. Which formula to pick, how sequences distribute an argument, the register spectrum, and the two length modes.

---

## 1. The proven formulas, and when to use each

| Formula | Use it for | Note |
|---|---|---|
| **AIDA** (Attention-Interest-Desire-Action) | Marketing/nurture, announcements, content sends | The backbone of longer relationship-building email. Too much machinery for a five-line note. |
| **PAS** (Problem-Agitate-Solution) | Problem-aware audiences, sales follow-up, re-engagement | Most versatile short-form. The agitate step is where mediocre writers pull back: make the cost *specific*, don't just say it louder. |
| **BAB** (Before-After-Bridge) | Solution-aware nurture where a relationship exists | Aspirational framing. Weak for cold or unaware audiences. |
| **Story-Insight-CTA** | Brand nurture, longer formats | Real, specific, counter-intuitive story → lesson → application. |
| **Myth-Truth-Action** | Contrarian content for "I already know this" audiences | Requires real evidence. Fabricated contrarianism is worse than nothing. |
| **Question-Reframe-CTA** | Shorter emails, surveys, prompting thought | Lighter-touch PAS. Good for shorter formats where full formula machinery is overkill. |
| **Hook-Context-Findings-CTA** | Research / report launches, any data-led send | The house formula for type 9 (Darren's preference): 1-2 line dissonant hook → 2-3 lines of why-care naming who was surveyed → three bullet findings → single download CTA. 100-200 words total, no exceptions. |
| **Bob Stone's 7 steps** | Longer nurture | Strongest benefit first → expand → state what they get → prove → cost of inaction → rephrase benefit → CTA. Underlies most well-built nurture even when unnamed. |

---

## 2. Schwartz awareness match - governs formula choice

The reader's awareness level determines which formula to reach for. Picking the wrong one is the single most common reason an email fails to convert.

| Awareness level | What the reader already knows | Lead with |
|---|---|---|
| **Most Aware** (small %) | Knows you, knows the product, ready to buy | The offer. Direct. |
| **Solution Aware** | Knows solutions exist, comparing options | Third-party proof, differentiation. |
| **Problem Aware** (large %) | Knows they have a problem, not sure what solves it | Empathetic pain acknowledgment first. |
| **Unaware** | Doesn't yet recognize the problem | Story, pattern interrupt, contrarian hook. |

**Key insight:** most Sabre B2B audiences are Problem Aware or Solution Aware. That means leading with "book a demo" on a first touch is almost always the wrong formula - the reader hasn't yet arrived at the mental state that makes a demo request feel logical. Earn the ask before making it.

---

## 3. Sequence logic - a distributed argument

**A sequence is not a series of reminders.** A sales letter must do a complete selling job: every reason to buy, every objection answered. A single 50-75 word email cannot do that. A sequence distributes the case across 4-5 touches. Each email carries one part of the argument. A follow-up is the next chapter, not a nudge.

### Default 5-touch structure

| Touch | Day | Job | CTA type |
|---|---|---|---|
| 1 | 0 | **Recognition** - prove you know their world; one specific observation | Interest-based: "worth exploring?" |
| 2 | +3 | **Reframe** - different angle, new proof point; not "following up" | Value offer: "want the benchmark?" |
| 3 | +7 | **Evidence** - third-party validation, named result | Soft meeting: "open to a 15-minute walk-through?" |
| 4 | +10-14 | **Direct ask** - you've earned it; add one new reason to act | Specific: "Thursday at 2pm?" |
| 5 | +17 | **Breakup** - lower the cost of replying; permission to say no | Easy out: "stop following up, or check back in Q3?" |

### Cadence findings

- First follow-up alone adds 40-66% more replies.
- 3-4 follow-ups is the sweet spot; after touch 5, spam complaints triple.
- 58% of replies come on email 1; 42% come from follow-ups. Follow-ups are not optional.
- Space 3-4 days early in the sequence, extending to 7-14 days later.

### Angle rotation

Never repeat the same argument in new words. The core benefit appears in every touch; the framing changes. The rule: restate, never simply repeat. If a reader could skim touch 3 and learn nothing new beyond touch 1, the sequence has failed.

Angle types by touch: trigger/observation (1), contrarian insight (2), named result (2-3), resource offer (2-3), third-party validation (3-4), timing/scarcity (4), graceful exit (5).

### Temperature variants

| Temperature | When | Structure |
|---|---|---|
| **Cold** | No prior contact | Full 5-touch. Interest-based CTA on touch 1. |
| **Signal-based** | Visited site, attended event, downloaded content | Compress to 3-4 touches. Reference the signal on touch 1. Escalate the CTA faster. |
| **Warm** | Met at an event, accepted LinkedIn connection | 3 touches max. Open with the relationship reference. Meeting CTA can go in touch 1. |
| **Re-engagement** | Previously engaged, then went cold | 2-3 touches max. Reference the prior conversation and add something genuinely new since then. |

### The report-launch sequence (for type 9)

A research report earns more than one email. Campaigns of 4+ touches get roughly 3x the response of 1-3 touch campaigns, and a report gives every touch genuinely new material - no angle has to repeat.

| Touch | Day | Job | Shape |
|---|---|---|---|
| 1 | 0 | **Launch** | The full Hook-Context-Findings-CTA email. |
| 1b | +2-3 | **Re-send to non-openers only** | Same email, reframed subject line (if launch was a question, go contrarian statement, or vice versa). Change the subject/angle, not the body; wait 48-72 hours; send only to non-openers. MailerLite reports resends lift total opens ~30%+ (one case 14.16% to 23.5%) with no meaningful unsubscribe penalty; a three-campaign study saw 160-390% conversion lifts. If the incremental unsubscribe rate tops ~0.3-0.5% per send, cut the resend or tighten the segment. |
| 2 | +3-4 | **One insight, deeper** | Take a single finding from inside the report and unpack it in 3-4 lines. New subject, same single CTA. |
| 3 | +7-14 | **Application angle** | "What this means for [airlines / hotels / agencies]" - the so-what for the reader's segment. The natural place to split by vertical if touch 1 went broad. |
| 4 | +21 | **Reaction / social proof** | What readers and peers are saying, or the finding generating the most discussion. Last call framing without scarcity theatre. |

Each touch teases different material - the report never runs out of new angles, so never restate touch 1 in new words. Timing: Tuesday-Thursday, 9-11am recipient-local (HubSpot: 47.9% of B2B marketers see best results between 9am and 12pm); test an earlier 7:45-9:15am variant for the C-suite segment, who skew earlier. Cadence note: 4+ touches earns roughly 3x the response of a 1-3 touch campaign, but for senior travel audiences keep the touches high-value and spaced wider (every few days early, stretching to 1-2 weeks) rather than aggressive.

---

## 4. The register spectrum

A user-pickable dial - 1 to 5 - for how personal the email feels. Register is expressed through the pronoun choice AND the signature block. The three voice traits (infectiously upbeat, knowingly provocative, endlessly supportive) stay constant across all registers. Register changes the pronoun and the intimacy. It does not change the brand.

The signature block is effectively the register selector. Choose it first; the voice follows.

| Register | Voice | Pronoun | Signature block | Use it for |
|---|---|---|---|---|
| **1 - We / Corporate** | Brand "we", collective identity | We | "Your Sabre team" or "The Sabre Executive Leadership Team" | Brand campaigns, operational announcements, broad newsletters |
| **2 - Team** | Warm collective, defined group | We | "Your NAM Sales Team" / "Your Sabre team" | Webinar and event invites, team-based follow-ups |
| **3 - Named team voice** | Still "we", but a named individual carries the message | We | Named individual + title (no deep first-person) | Event invites with a specific host, regional team outreach |
| **4 - Personal-professional** | Named sender writing as themselves, light first person | I (measured) | Named individual + title + photo signature | ABM sequences, post-event notes, account-team outreach |
| **5 - Personal** | Fully first-person, one-to-one, conversational | I | Named sender only | Direct sales follow-up after a real interaction, senior-leader personal note |

**Where most outbound sits:** registers 1-3. Reserve 4-5 for genuine one-to-one moments where a corporate "we" would ring false. A first-touch cold email at register 5 reads as performance, not warmth.

---

## 5. Length modes

Ask the requester which mode applies up front. Default to Shorter unless they specify otherwise.

### Shorter (default)

Tight. One idea. Drives a click to learn more rather than delivering the full argument in-message. The header and sub-header carry the hook; the body is lean. Best for high-volume sends and busy executives.

- Body: under ~125 words.
- For executives specifically: under ~75 words.

### Longer

Explains within the email. Teaches, builds the case in-message. Use when the click is not the point - a webinar invite with event details, a CEO note with a full argument, a brand email building a position. The reader should come away knowing something, not just curious enough to click.

### Test variant

When time allows, generate both a shorter and a longer variant so the team can A/B. Different audiences respond differently; having both ready costs little extra effort at draft stage.

**The principle:** Sabre's real emails skew medium-to-long, but the default here is shorter because shorter, sharper copy is almost always stronger. Longer is an explicit opt-in, not the fallback.
