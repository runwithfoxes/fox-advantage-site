# 08 - Verification and the claims ledger

> Shared Sabre writing core. Applies to every channel. This is the anti-fabrication spine: it turns "trust me, it's verified" into a checklist where every factual claim has a row, a status, and pasted evidence. A tick with no evidence behind it is a failure, not a pass.

## The principle

The writer enhances what it is given; it never invents. But "I checked it" is not a check. A check is a **claim, a status, and the evidence for that status, written down**. This reference makes verification auditable: you can read every factual claim in the email, see where each came from, and see exactly what is still unproven before anything sends.

**The hard rule, stated once:** No claim may appear as a stated fact in the copy unless its ledger row is marked SUPPLIED, POSITIONING, or WEB-VERIFIED. Anything UNVERIFIED becomes a bracketed gap in the copy. Anything that needs a human becomes a FLAG. **A row cannot be marked WEB-VERIFIED without a real source URL pasted in its evidence cell. If you cannot paste a source, you have not verified it - downgrade the row to FLAG. Never write "verified" where you mean "seems right".**

---

## Step A - Extract every checkable claim

Before verifying anything, list every factual claim in the draft. A checkable claim is anything a reader could challenge as true or false:

- **Statistics and numbers** - percentages, counts, money, dates, timeframes, growth figures
- **Named people** - any person named, with their title and company
- **Named customers / logos** - any company cited as a Sabre customer or example
- **Quotes / testimonials** - anything in quotation marks attributed to a person
- **Competitor claims** - any statement about Amadeus, Travelport, Outpayce, etc.
- **Product capability claims** - "the only solution that...", "built to...", anything Sabre says it does
- **Industry / market claims** - "most airlines...", "the industry is moving to...", benchmarks
- **Legal / regulatory claims** - compliance, certifications, "approved", "compliant with..."

If a sentence contains no checkable claim, it doesn't go in the ledger. Opinion, argument, and brand voice are not claims. "Open beats closed" is a position. "324M authorizations in 2025" is a claim.

---

## Step B - Assign each claim a status

Every claim gets exactly one status. The status determines what happens to it in the copy.

| Status | Means | Required evidence | What happens in the copy |
|---|---|---|---|
| ✅ **SUPPLIED** | Traceable to the user's own materials | The quoted line from their brief/source | Used as written |
| 📐 **POSITIONING** | Sabre's own positioning or brand fact | Which positioning doc / pillar it comes from | Used as written |
| 🌐 **WEB-VERIFIED** | Confirmed against an external source | **A real URL + one line on what it confirms** | Used as written |
| ⛔ **UNVERIFIED** | No source found, not in materials | (none - that's the point) | Converted to a `[bracketed gap]` |
| 🚩 **FLAG** | Needs a human to confirm | Why it can't be auto-verified | Kept, but flagged for Sabre before send |

**Order of preference:** prefer SUPPLIED over WEB-VERIFIED. A number from the user's own approved materials is stronger than one you found online. Only reach for the web when the claim is stated as fact but isn't in the supplied materials.

**The downgrade rule:** if a claim is stated as fact, isn't in the materials, and you cannot find a real source for it, it does NOT stay in as fact. It becomes ⛔ (bracketed) or 🚩 (flagged). There is no fourth option where it quietly stays in unproven.

---

## Step C - What to actually do per claim type

- **Numbers / stats not in the materials:** web-search for the primary source (the report, the filing, the official page). Paste the URL. If the only sources are secondary or you can't confirm, mark 🚩, don't guess the figure.
- **Named people:** web-verify the name, current title, and company are right and current. People move. A wrong title is the most common and most embarrassing error. No confirmation → 🚩.
- **Named customers / logos:** unless the materials explicitly clear the customer for public use, mark 🚩. Naming a customer who hasn't agreed to be named is a real liability, not a copy choice.
- **Quotes:** must be SUPPLIED, word for word, with attribution. Never reconstruct or tidy a quote. Not supplied → it doesn't exist.
- **Competitor claims:** web-verify it's currently true (competitor capabilities change). Frame as what's publicly known. No source → 🚩.
- **Product capability claims:** must be POSITIONING or SUPPLIED. "The only solution that..." needs a source for the "only". No source → soften to what's provable or 🚩.
- **Legal / regulatory claims:** always 🚩. The writer never self-certifies that Sabre can legally make a claim. That's a human call, every time.

---

## Step D - The verification environment check (the honesty gate)

Web verification only works if the tool can actually search the web.

- **If web search is available** (e.g. Claude.ai with web search on): run it for every claim that needs it. Paste real URLs.
- **If web search is NOT available:** say so plainly at the top of the ledger ("web search unavailable in this session - external claims flagged, not verified"). Then **every claim that would need the web is marked 🚩, never 🌐.** You may not mark a claim WEB-VERIFIED in an environment where you could not have searched. This is the exact failure the ledger exists to prevent: claiming verification you didn't do.

---

## The output: the verification ledger (shown every run)

This goes in the output, after the email, before the writing-checks panel. It is a table, not a sentence. Every checkable claim, one row:

```
🔎 Verification ledger

| # | Claim (as written)                          | Type        | Status         | Evidence |
|---|---------------------------------------------|-------------|----------------|----------|
| 1 | 324M transaction authorizations in 2025     | Stat        | ✅ SUPPLIED    | Your brief, line: "324M auths worth ~$113BN" |
| 2 | Open, modular, AI-native platform           | Capability  | 📐 POSITIONING | Mosaic positioning, WHAT pillar |
| 3 | IATA targets 100% offer-and-order by 2030   | Industry    | 🌐 WEB-VERIFIED| iata.org/.../retailing - confirms 2030 target |
| 4 | Most airlines have moved fare content off filing | Industry | ⛔ UNVERIFIED | No source → bracketed as [XX% of airlines] |
| 5 | Jane Doe, CRO at ExampleAir                  | Named person| 🚩 FLAG        | Could not confirm current title - verify before send |

Web search: available, run on rows 3-4.
Claims total: 5 | Supplied 1 | Positioning 1 | Web-verified 1 | Bracketed 1 | Flagged 1
Nothing is marked verified without a pasted source.
```

If the ledger has zero rows, say so ("no checkable factual claims in this piece - it's argument and positioning only") rather than omitting the ledger. An empty ledger is a result; a missing ledger is a skipped check.

---

## The pre-send verification checklist (the last gate)

Before the email is called ready, walk this list and tick only what's true:

- [ ] **Every checkable claim is in the ledger** (re-read the email; any fact not in the table is a miss)
- [ ] **Every ledger row has a status**, and no row is WEB-VERIFIED without a pasted URL
- [ ] **Every ⛔ UNVERIFIED claim is bracketed** in the actual copy (not left as a bare fact)
- [ ] **Every 🚩 FLAG is listed** in the Flags section with what to confirm
- [ ] **Every named person's title and company web-checked** (or flagged)
- [ ] **Every named customer is cleared for public use** (or flagged)
- [ ] **Every quote is word-for-word from supplied materials** (or removed)
- [ ] **Every competitor claim is current and publicly known** (or flagged)
- [ ] **Every legal/regulatory claim is flagged** for a human (no self-certifying)
- [ ] **The environment honesty line is present** (web available? say so; if not, nothing is marked web-verified)

A box ticks only when it's actually true. If you can't tick it, the piece is a draft, and the unticked box is the reason.
