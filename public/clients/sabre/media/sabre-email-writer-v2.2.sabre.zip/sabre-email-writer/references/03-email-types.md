# The 9 Sabre Email Types

Each type below is calibrated against Sabre's own recent sent emails (type 9 against Darren's stated preference plus verified industry research). For each: when to use it, the proven structure (the blocks in order), the default register and length, the sign-off pattern, and the watch-outs. ABM is a delivery variant that sits on top of these, covered at the end.

> These structures are skeletons, not scripts. Fill them from the supplied materials (see the content gate). Never invent the stats, names, dates, or proof. If a block has no real content to fill it, cut the block - don't pad it.

The voice (the three traits) and all the hard writing rules apply to every type without exception. What changes type to type is the structure, the register, and the tone calibration.

---

## Quick selector

| Type | Default register | Default length | Primary job |
|---|---|---|---|
| 1. Webinar invite | 2 - Team | Longer | Fill seats for a live session |
| 2. Event invite | 3 - Named host | Shorter - Longer | Book meetings / drive booth visits at an industry event |
| 3. Event / webinar follow-up | 2 - Team | Shorter | Deliver resources, keep momentum, soft next step |
| 4. Campaign brand | 1 - We / Corporate | Longer | High-level positioning, the "who we are now" story |
| 5. Campaign product | 1 - 2 | Shorter | The benefit of one specific product, one value theme |
| 6. Survey | 1 - 2 | Shorter | Earn a completed response, make them feel heard |
| 7. CEO / senior-leader | 5 - Personal "I" (named leader) | Longer | Relationship, candor, partnership at the top |
| 8. Operational | 1 - We / Corporate | Shorter | Tell them clearly what's changing and what to do |
| 9. Research / report launch | 1 - 2 | Shorter (100 - 200 words, hard) | Earn the report download |

---

## 1. Webinar invite

Sabre's highest-volume type, usually sent by the NAM sales team running local sessions. Two real shapes seen: a broad "AI in action" session and a developer-only "API live demo."

**When:** to fill seats for a live or on-demand webinar.

**Proven structure (in order):**
1. **Header block** (≤200px): logo + headline (2 lines max) + sub-header (2 lines max) + the why-now hook. Headline names the session's promise, sub-header explains what it is. *(real: "Build Travel's Next Chapter: Sabre AI in Action" / "Automate complex workflows, accelerate conversions, and scale your agency's performance.")*
2. **Hero image** (motion/travel).
3. **Why-now paragraph** - the shift that makes this session worth an hour, framed at the status quo. *(real: "AI has evolved far beyond basic conversational chatbots. Today, it functions as a robust operational engine…")*
4. **Expert:** - named speaker + role. One line. *(real: "Victor Sivira - Product Technology Consultant")*
5. **What you will learn:** - 3 to 4 specific, outcome-led bullets. Each starts with a verb. *(real: "Execute the Agentic Blueprint / Automate Care with Sabre IQ / Slash Integration Time with the MCP Server / Drive Conversions via Agentic-Ready APIs")*
6. **Save your spot** (or "Save your access:") - Date + Time, clearly labeled.
7. **CTA button:** "Register now →"
8. **Closer line** - a provocative or warm beat that gives one more reason. *(real: "Don't miss out, we are holding a live, friendly Q&A at the end…" / "Stop wrestling with legacy hurdles. Start building the future of travel.")*
9. **Sign-off:** "See you there," → "Your NAM Sales Team" (or the relevant team).

**Register:** 2 (Team). **Length:** Longer (this type earns its length - it teaches what you'll get).

**Watch-outs:** the bullets must be specific outcomes, not topics. "Automate Care with Sabre IQ" beats "An overview of AI tools." Match the speaker and the session promise. If it's a developer session, say so bluntly and drop the marketing gloss *(real: "This isn't a sales pitch. It's a technical masterclass for the people writing the code.")*.

---

## 2. Event invite

For in-person industry events (conferences, trade shows). The job is a meeting or a booth visit, not a registration.

**When:** Sabre is exhibiting or attending an industry event and wants target accounts to come find them.

**Proven structure:**
1. **Header block:** logo + headline naming the event + where to find Sabre. *(real: "Meet us at the 158th IATA Slot Conference in Bangkok")*
2. **Hero image** (event/destination).
3. **Open with the recipient + the event** - "Dear {{Recipient.FirstName}}, [Sabre team] is heading to [event] on [dates], and we'd love to see you there." Name the booth/location. *(real: "Stop by Booth 43/44 to…")*
4. **Three specific reasons to stop by** - bullets, concrete (see a demo, talk through X, get a chat with the expert). *(real: "See what's new across our Network Planning suite with live demos / Talk through your slot and scheduling requirements with our team / Get a feel for where we're heading next, or just have a chat")*
5. **Escalation line** - offer the higher-intent option (a booked 1:1). *(real: "If you want to go deeper, secure a one-on-one meeting with us.")*
6. **Provocative/warm closer** + tagline beat. *(real: "Let's Get Going.")*
7. **CTA button:** "Schedule a meeting →"
8. **Sign-off:** named host + photo signature + title (register 3). *(real: Jeff Vernon, Principal Product Manager, Network Planning & Optimization)*

**Register:** 3 (named host). **Length:** Shorter to Longer depending on how much the booth offer needs explaining.

**Watch-outs:** lead with the recipient and the event, never with Sabre. The booth number / meeting link is the whole point - make it impossible to miss.

---

## 3. Event / webinar follow-up

Often created by the sales team. The job is to deliver what was promised and keep momentum. A follow-up is the next chapter, never "just checking in."

**When:** after a webinar or event the recipient attended (or registered for).

**Proven structure:**
1. **Recognition opener** - name what they just did, in their words. *(real: "You've seen the architecture. You've watched the live build. Now, it's time to take those insights and cut your development cycle.")* For a product session: "Thanks for joining our Product Updates Live session."
2. **What you get** - the resources, as buttons or bold links: Presentation deck, Webinar recording, plus any glossary/asset. *(real: "Access the resources from the session below:" → Presentation deck → / Webinar recording →)*
3. **A forward ask** - usually a short survey to shape the next session, framed as "help us make the next one as good." *(real: "We don't do fluff. To ensure our next session is as high-impact as this one, tell us what you want to build next." → Short survey)*
4. **A help offer** - low-pressure, specific. *(real: "Don't let a technical hurdle stall your progress. If you're stuck on a specific integration or need to dive deeper into the code, reach out. We're here to help you own your stack.")*
5. **Sign-off** with a signature beat. *(real: "Stay fast. Best regards, Your Sabre Team" / "Let's get going! Regards, NAM Sales Team")* - note: we render the tagline without the exclamation mark per our rules.

**Register:** 2 (Team). **Length:** Shorter - this is a delivery email, not a teaching one.

**Watch-outs:** the resources are the reason to open; put them high. Don't re-pitch the webinar they already attended. One forward ask, one help offer - don't stack CTAs.

---

## 4. Campaign brand

High-level positioning. The "who Sabre is now" story (rebrand, platform vision). Infrequent, high-stakes, multi-block.

**When:** a brand moment - rebrand, repositioning, the umbrella story above any single product.

**Proven structure (newsletter / multi-block):**
1. **Header block:** logo + headline + sub-header. *(real: "Get to know the new Sabre" / "Say hello to our new look"; or "Introducing the new Sabre")*
2. **Opening** - address the reader, state the change plainly, no hype. *(real: "Yes, we've refreshed our brand. The new look reflects a company that has genuinely changed.")*
3. **2 - 3 story blocks**, each a sub-headline + short paragraph (+ image, alternating left/right): the platform, the AI tools, the people/leadership. *(real blocks: "More than meets the eye" → Sabre Mosaic; "A suite of new AI tools" → Sabre IQ)*
4. **Named conviction beats** - the positioning lines that carry the idea. *(real: "One platform, built to open." / "AI built, not bolted on." / "built to open")*
5. **A close that invites the relationship forward** - "talk it through with your account team." *(real: "Time for you to meet the new Sabre? … some fresh faces in the leadership team. Your Account Team is ready to talk through what this means for you.")*
6. **CTA:** "Let's get going →" or "See for yourself here →"
7. **Sign-off:** "The Sabre Team" / "The Sabre Executive Leadership Team" (register 1).

**Register:** 1 (We / Corporate). **Length:** Longer.

**Watch-outs:** brand emails tempt hype - resist it. The provocation lands on the old closed way ("built to open" implies others are closed), never on the reader. One value theme per block; don't let blocks blur into each other.

---

## 5. Campaign product

The benefit of one specific product. Single value theme, single proof, single action. *(We have no standalone real example yet - this skeleton is built from Sabre's ABM/retailing emails and the Mosaic positioning. Flag any draft of this type as not-yet-calibrated against a real Sabre product email.)*

**When:** to drive interest in one product or capability with a clear benefit.

**Proven structure (single-story):**
1. **Header block:** logo + benefit-led headline (the outcome, not the product name) + sub-header.
2. **Hero image.**
3. **Trigger/relevance opener** - one specific observation about the reader's situation.
4. **The one value theme** - the single pain it answers, with the proof that belongs to that theme (never generic credibility, never crossed proof).
5. **How it works without the pain** - the "no big-bang risk" reassurance where relevant. *(real Sabre reassurance pattern: "No big-bang risk. No vendor lock-in." / "built on top of your existing systems, from day one.")*
6. **Single CTA** matched to the influence model (demo/call for Direct Response, case study/product page for Salience).
7. **Sign-off** at register 1 - 2, or a named account contact for a targeted send.

**Register:** 1 - 2. **Length:** Shorter (default) - one idea, drive the click.

**Watch-outs:** one product, one theme, one proof, one action. The moment a second value theme appears, split it into a sequence. This is the type most at risk of generic B2B - hold the line hard.

---

## 6. Survey

Infrequent. The job is a completed response, and the emotional hook is making the recipient feel their voice matters.

**When:** gathering customer input (research, thought-leadership input, session feedback).

**Proven structure:**
1. **Opening that frames why THEIR voice** - set up the gap, then close it. *(real: "Most commentary on travel's current headwinds comes from analysts watching from the outside. The people actually living it rarely get asked. We want to hear from you directly.")*
2. **What it's for** - where their input goes (a thought-leadership piece, the next session). One or two lines.
3. **The reassurances** - confidential, anonymized, and the time cost stated honestly. *(real: "All responses are strictly confidential, anonymized, and analyzed in aggregate. 5 minutes of your time. A real voice in the conversation.")*
4. **CTA button:** "Take survey →" / "Give us feedback →"
5. **Sign-off:** "Your Sabre team" (register 1 - 2). Note the survey example used no header logo block - a survey can run plainer than a campaign.

**Register:** 1 - 2. **Length:** Shorter.

**Watch-outs:** state the real time cost (don't say "quick" - say "5 minutes"). The hook is being asked, not being sold to. Don't bury the link.

---

## 7. CEO / senior-leader

Infrequent, distinct register. A named leader writing to partners with candor - relationship over pitch, aware of the wider business reality (even earnings).

**When:** a periodic note from a senior leader to valued partners/customers.

**Proven structure:**
1. **Header block / headline** naming the relationship and the moment. *(real: "Thank you for your partnership" - "Q1 Update from Kurt Ekert, President and CEO, Sabre")*
2. **Salutation:** "To our valued partners," (or named).
3. **A candid read of the moment** - name the uncertainty honestly, including for Sabre itself. This candor is the whole credibility of the type. *(real: acknowledges "fundamental change… perhaps faster than at any time in history," names real numbers and headwinds, even a debt-reduction and refinancing note.)*
4. **What Sabre is doing about it** - concrete, not spin. Products in production, partnerships, the direction. *(real: agentic AI moved from blueprint to production, the ChatGPT plugin, the MCP server, 50+ partners.)*
5. **A forward, shared-future close.** *(real: "We believe the best is ahead for all of us. Let's get going.")*
6. **Sign-off:** the named leader + title + photo (register 5).

**Register:** 5 (personal, named leader). **Length:** Longer.

**Watch-outs:** the candor is non-negotiable - a senior-leader note that only says good things reads as PR and fails. Don't manufacture the leader's voice; if you don't have the leader's real material/positions, flag it and work from what's supplied. No hype, no exclamation.

---

## 8. Operational

Functional. A product change, sunset, outage, fee update, or policy change. Clarity over everything; wit dialed almost off.

**When:** to advise of a product outage, sunset, fee change, migration, or any operational matter.

**Proven structure:**
1. **Header (often no marketing header block)** - a plain, accurate headline. *(real subject seen: "Upcoming customer care fees." Sub-header takes ≤2 lines and states the substance plainly.)*
2. **Salutation:** "Dear customer," (or named).
3. **What's changing** - first sentence, no preamble. State it plainly.
4. **When, and what it means for them** - dates, impact, any action they must take.
5. **What to do / who to contact** - one clear next step, a reference or contact where relevant.
6. **Sign-off:** "Your Sabre team" (register 1).

**Register:** 1 (We / Corporate). **Length:** Shorter. *(No real operational body copy in hand yet - this skeleton is built from the design template and direct-communication principles. Flag any operational draft as not-yet-calibrated against a real Sabre operational email.)*

**Watch-outs:** lead with the change, not with reassurance or brand voice. The reader needs facts: what, when, what to do. Warmth stays (it's still Sabre), but provocation comes fully off. Never bury the action in paragraph three.

---

## 9. Research / report launch

Launching a research report, benchmark study, survey results, or any data-led asset. The job is the download. *(Calibrated against Darren's stated structure preference, 12 Jun 2026, then refined 13 Jun 2026 against a controlled-evidence review - length, single-CTA, numerals-null, specificity/negativity, resend, and travel benchmarks. Not yet calibrated against a real sent Sabre report email - flag drafts accordingly.)*

> **Governance (David and Darren's brief governs).** Where the research below conflicts with David's or Darren's stated preference, their preference wins. The evidence is supporting material and a test agenda, not an override. When in doubt, write to the brief and flag the research alternative as a thing to A/B test, not a thing to do instead.

**When:** Sabre publishes research and wants the database to read it - traveller studies, industry benchmarks, survey findings, analyst-style reports.

**The structure (Darren's formula - this is the law for this type):**
1. **Header block:** logo + headline (2 lines max) + sub-header. The headline carries the tension or the promise of the data, not the word "report."
2. **The hook - 1 to 2 lines.** Very short, insightful, entertaining - this is Darren's brief, and it governs. Within that, the evidence says the *entertaining* beat lands hardest when it is also *specific and assumption-challenging*: lead with the most *dissonant* finding, not the biggest number - the stat that makes the reader question something they currently believe or do. Behavioural science supports it: information-gap theory (Loewenstein 1994 - curiosity spikes when a reader sees the gap between what they know and what they could know) and a controlled negativity effect (Robertson et al., *Nature Human Behaviour* 2023; 22,743 randomized trials, 5.7M clicks: each extra negative word lifted CTR ~2.3%). One guardrail from the same body of evidence - keep it **clear, not cryptic** (BDOW, 150k+ headlines: straightforward lines beat clever ones 88% of the time). So a surprising, assumption-breaking fact stated *plainly*. (86% of B2B decision-makers prefer content that challenges assumptions over content that validates them - Edelman/LinkedIn 2025.) The curiosity comes from the insight, never from marketing language. **This dissonant angle is the least-proven part of the type (theory plus headline-CTR data, not report-email A/B tests), so it is a recommendation to test on Sabre's own list - never a reason to override Darren's "entertaining".**
3. **The context - 2 to 3 lines max.** What's going on and why they should care. Name the sample here: who was surveyed and how many *(pattern: "We surveyed 2,500 travellers across Europe, North America and APAC.")*. The sample size is the credibility - never bury it.
4. **Three findings** - diamond bullets, specific, numeric where the data allows, each one standing on its own *(pattern: "62% would switch providers for a better digital experience / AI-assisted trip planning is now mainstream among under-35s / Loyalty remains highly correlated with disruption handling")*. Two or three findings, never five. Tease the report, don't empty it - the findings open the gap, the report closes it.
5. **Single CTA** - one button, nothing else. Lead-in line frames the learning, not the mechanics *(pattern: "Download the full benchmark report to see the complete findings and implications for travel brands.")*. Button copy is outcome-led: "Get the benchmark →" / "See where airlines stand →" / "Download the report →".
6. **Optional report cover image** as the only visual. Treat it as a test variable, not a given - image-heavy report emails are not proven to lift clicks.
7. **Sign-off:** "Your Sabre team" (register 1 - 2).

**Register:** 1 - 2. **Length:** Shorter, and hard-capped - 100 to 200 words total (Darren's cap). Within that range the evidence favours the lower half (~150 and below): ~200 words / 20 lines hit peak CTR in Constant Contact's 2.1M-customer study, a 95-word email beat a 170-word one by 5.81% (MarketingExperiments), and Boomerang's 40M-email analysis puts the sweet spot at 75-125 words. This type never goes Longer; the report does the teaching.

**Subject line and preview text for this type (evidence-backed):**
- Short: 2 - 4 words or a short question, under ~40 characters. *"What 2,500 travellers told us" / "How does your airline compare?"* Question forms trigger peer comparison and perform at the top of the range.
- **Keep the number out of the subject line.** This is Darren's preference and the controlled evidence agrees. Stats in subject lines show no open-rate lift (Belkins, 5.5M-email study; GetResponse, tens of billions of emails). The stat is the body hook, not the subject. A plain label subject ("2026 traveller expectations, benchmark study") works as an annual-edition signal; offer the question form alongside it as the likely stronger variant.
- **The real subject-line levers are specificity, clarity, a curiosity gap, and an audience call-out - not numerals.** The famous "numbers get +45% opens" claim (Yesware) is an uncontrolled correlation that circulates as +45% / +113% / +57% / +12.5% - the inconsistency is the tell that it was never a real measurement. Ignore it. What controlled tests *do* support: a more specific subject beat its control by 15.8% (NextAfter RCT, n=12,352) and adding the recipient's name lifts opens ~20% (academic field experiments). So spend any A/B budget on *angle* - curiosity gap vs specific benefit vs audience call-out ("For airline revenue leaders:...") - never on numeral-vs-no-numeral.
- Preview text extends the subject, never repeats it. Subject asks, preview teases: subject "How does your airline compare?" / preview "We asked 2,500 travellers. The gap is wider than expected."
- The first body line is now a third hook - inbox AI summaries (Apple, Gmail) surface it before the open. The hook opens the body cold, no warm-up sentence.

**Watch-outs:**
- **One CTA only.** The moment a second action creeps in (download AND register for the webinar), split it into two emails or a sequence.
- **Segment by vertical when the list mixes airlines, hotels, and agencies.** The headline stat must hit the reader's own sector - an airline distribution stat is noise to a hotel revenue manager. Same structure, swapped hook and findings per segment.
- **Judge it on clicks and click-to-open, not opens.** Apple Mail Privacy Protection has inflated opens by 10 - 25+ points since 2021, so opens are noise. This matters double for Sabre: travel and transportation post the *lowest* open rate of any industry (30.10% vs a 43.46% cross-industry median; travel click rate ~1.68% - MailerLite 2025, 3.6M campaigns). Set expectations accordingly - a senior travel audience rewards relevance, mid-week mornings, and a disciplined sequence over clever creative. Success = downloads and CTOR.
- **Gating is a campaign decision above the email - David and Darren's call, not the writer's - but it shapes what the CTA points at.** Pure-gating a report now makes it invisible to AI search (GPTBot, ClaudeBot, PerplexityBot cannot fill forms), and AI Overviews already hit ~half of queries (B2B Tech rose 36% to 82% in a year, BrightEdge). The 2025 - 26 evidence favours a *hybrid* model: ungate a one-page executive summary (findable and citable), gate the full report behind the form. Flag this as a recommendation; never assume it - if Sabre's brief says gate everything, gate everything.
- Every stat comes from the supplied report materials, exactly as published. Never round, never approximate, never invent.
- A report launch is usually a sequence, not a single send - see the report-launch sequence in `06-formulas-sequences-register.md`.

---

## ABM (a delivery variant, not a 10th type)

ABM emails take one of the types above (usually campaign product, event invite, or a single-story note) and wrap it for a named account: a co-branded header (sabre | partner logo), copy personalized to that account's situation and language, and a named regional/account director signature with photo (register 4 - 5).

**Real examples:**
- **sabre | TAP Air Portugal** - "Stop waiting for 2030. Start retailing today." Personalized to TAP's "Go Beyond 2030" program; reassurance beats ("No big-bang risk. No vendor lock-in."); signed Jean Vincent, VP, Airline Sales & Account Management, EMEA.
- **sabre | GOL** - "You're already winning. Let's accelerate." Built on GOL having already led in retailing; "Let's go further →"; signed Simone Silveira, Sr Regional Director, Airline Sales & Accounts, Latin America.

**The ABM rules:**
- The opener references something true and specific to THAT account (their program, their position, their language). If the line could be sent to any airline unchanged, it isn't done.
- Co-brand the header (Sabre + partner logo).
- Register 4 - 5, named account owner with photo.
- Everything else (one value theme, matching proof, single action, all writing rules) still applies.
- Never fabricate the account's program, results, or situation - it must come from supplied materials.
