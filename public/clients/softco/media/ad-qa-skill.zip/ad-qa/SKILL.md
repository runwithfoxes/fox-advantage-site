---
name: ad-qa
description: Reusable readability QA gate for HTML-rendered ads. Measures contrast, font size, edge spacing and copy density from a real render and FAILS an asset that breaks a threshold. Use when wiring automatic QA into an ad machine (e.g. /softco-ads), when someone says "readability QA", "QA gate", "auto-fail assets", "contrast/legibility check", or to check one rendered ad. Config-driven and brand-agnostic - new brand = new config, same engine. NOT a renderer (it checks what a renderer produces) and NOT a redesign tool.
---

# ad-qa - readability QA gate

Turns the measurable half of an ad-craft checklist into an automatic, blocking test.
Give it a rendered HTML ad (brand + format) and it returns PASS, or FAIL with an
itemised report. It does not design or fix - it judges, with numbers.

## The four gates
Every check is measured from a real render, never eyeballed.

1. **Contrast (two-tier).** Body / sub-copy >= 4.5:1 (WCAG AA). Large / display text
   >= 3:1 (WCAG AA-large) OR an approved brand pair from the config whitelist. The
   ratio uses the ACTUAL pixels behind each text block (the screenshot is sampled in
   a ring around the block, worst sample wins), so gradients and photos are handled
   like flat colour.
2. **Min font size.** Each text block's computed px at the asset's true output size
   must clear the per-format floor.
3. **Edge spacing.** Text must not be jammed against the canvas edge; the logo must
   not be buried (min height, no text overlapping it).
4. **Density.** Total words must be under the per-format cap; single-line formats
   (email banners) must stay one line.

## Use it
**Standalone, on one rendered asset (HTML with `window.READY = true`):**
```
NODE_PATH=<playwright node_modules> \
  node ~/.claude/skills/ad-qa/scripts/qa.cjs <brand> <format> <resolved.html> [W] [H]
```
Exit 0 = pass, 1 = fail (report printed either way).

**Wired into a machine (the real use).** `/softco-ads`' `produce.cjs` already calls
`qa.runQAOnPage(page, 'softco', format, W, H)` right after the render reaches READY,
and refuses to write the PNG if it fails. To wire a new machine, do the same:
```js
const qa = require(require('path').join(process.env.HOME, '.claude/skills/ad-qa/scripts/qa.cjs'));
const res = await qa.runQAOnPage(page, BRAND, format, W, H); // page at READY
qa.printReport(res, BRAND + '/' + format);
if (!res.pass) { /* don't emit the asset */ }
```
Bypass switches (env): `QA_OFF=1` skip entirely, `QA_WARN=1` report but don't block.

## Add a brand
Copy `configs/_default.json` to `configs/<brand>.json` and set per-format
`minFontPx`, `minEdgePx`, `maxWords`, `singleLine`, plus `contrast.approvedPairs`
and `logo`. Anything missing inherits the brand `_default` format, then the global
`_default.json`. Derive the floors from the brand's already-approved templates so the
gate codifies signed-off work rather than arbitrary numbers (that's why it doesn't
false-fail). `configs/softco.json` is the worked example.

## How the numbers are chosen
Contrast is objective WCAG. Size / edge / density floors sit at or just below the
smallest approved element per format, so approved assets pass and genuinely
too-small / low-contrast / overcrowded assets fail. `approvedPairs` exists for
intentional brand colour combos on light backgrounds that sit under AA-large; seed
them as they surface (start empty).

## Gotchas
- **HTML in, not PNG.** The gate needs the DOM to read font px and colours, so it
  runs on the rendered HTML (the machine's template after inputs are injected), not
  a flat PNG. The background contrast is still read from real pixels.
- **`window.READY`.** The page must set `window.READY = true` when fonts/layout are
  settled (every `/softco-ads` template already does). The CLI waits for it, then
  falls back to a short delay.
- **Logo by id.** Logo checks look for `#logo`. No `#logo`, no logo checks.
- **Tune in config, never in code.** A false fail means a threshold is wrong for that
  brand/format - fix the JSON. The engine stays brand-agnostic.

Add gotchas here as failure points are discovered.
