// ad-qa review page builder. Turns flagged QA cases into ONE self-contained HTML
// page the brand owner opens, looks at, and decides on. Each case: the rendered
// ad, a zoom on the flagged element, the detail, our recommendation + why, and a
// choice. Choices are saved in the browser; "Apply" downloads a qa-decisions.json
// that apply.cjs feeds back into the brand's own config. No server, no Run with
// Foxes in the loop - the brand owns its guardrails.
//
// Module:  buildReview(assets, outPath) -> writes HTML, returns path
//          assets = [{ brand, format, assetId, label, shotB64, W, H, violations }]
// CLI:     node report.cjs <results.json> <out.html>   (results.json = { assets:[...] })

const fs = require('fs');

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function cropStyle(rect, W, H, CW, CH) {
  if (!rect) return null;
  const pad = 40;
  const zoom = Math.max(1.1, Math.min(4, Math.min(CW / (rect.w + pad * 2), CH / (rect.h + pad * 2))));
  const bgW = W * zoom, bgH = H * zoom;
  const bgX = -(rect.x + rect.w / 2) * zoom + CW / 2;
  const bgY = -(rect.y + rect.h / 2) * zoom + CH / 2;
  return { zoom, bgW, bgH, bgX, bgY, boxW: rect.w * zoom, boxH: rect.h * zoom };
}

function violationCard(a, v, vi) {
  const CW = 360, CH = 220;
  const cs = cropStyle(v.rect, a.W, a.H, CW, CH);
  const id = `${a.assetId}::${v.gate}::${v.el}`;
  const zoom = cs
    ? `<div class="crop" style="width:${CW}px;height:${CH}px;background-image:url(data:image/png;base64,${a.shotB64});background-size:${cs.bgW}px ${cs.bgH}px;background-position:${cs.bgX}px ${cs.bgY}px;">
         <div class="crop-box" style="width:${cs.boxW}px;height:${cs.boxH}px;"></div>
       </div>`
    : `<div class="crop crop-whole"><img src="data:image/png;base64,${a.shotB64}" style="max-width:${CW}px;max-height:${CH}px;"></div>`;
  const ruleOpt = v.fix
    ? `<label class="opt opt-rule"><input type="radio" name="${esc(id)}" value="rule"> <b>Change the rule for all</b> <span class="opt-sub">${esc(ruleText(v.fix))}</span></label>`
    : '';
  return `
  <div class="card" data-id="${esc(id)}" data-fix='${esc(JSON.stringify(v.fix || null))}' data-asset="${esc(a.assetId)}" data-format="${esc(a.format)}" data-gate="${esc(v.gate)}" data-el="${esc(v.el)}">
    <div class="card-vis">${zoom}<div class="card-cap">${esc(a.label || a.format)}</div></div>
    <div class="card-body">
      <div class="gate">${esc(v.gate)}</div>
      <div class="detail">${esc(v.detail)}</div>
      <div class="metric"><span class="bad">${esc(v.measured)}</span> &nbsp;needs&nbsp; <span class="need">${esc(v.threshold)}</span></div>
      <div class="rec"><b>Recommendation</b> ${esc(v.rec)}</div>
      <div class="why">${esc(v.why)}</div>
      <div class="opts">
        <label class="opt"><input type="radio" name="${esc(id)}" value="fix" checked> <b>Fix it</b> <span class="opt-sub">leave it failing until the design is changed</span></label>
        <label class="opt"><input type="radio" name="${esc(id)}" value="accept"> <b>Accept just this one</b> <span class="opt-sub">let this single ad through, keep the rule</span></label>
        ${ruleOpt}
      </div>
    </div>
  </div>`;
}

function ruleText(fix) {
  if (fix.type === 'minFontPx') return `allow text down to ${fix.value}px in ${fix.format} from now on`;
  if (fix.type === 'maxWords') return `allow up to ${fix.value} words in ${fix.format} from now on`;
  if (fix.type === 'approvedPair') return `approve this colour pair (${fix.fg} on ${fix.bg}) from now on`;
  return 'change this rule from now on';
}

function buildReview(assets, outPath) {
  const total = assets.reduce((s, a) => s + a.violations.length, 0);
  const cards = assets.map(a => a.violations.map((v, vi) => violationCard(a, v, vi)).join('')).join('');
  const html = `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Readability QA - decisions needed</title>
<style>
  :root{--ink:#0b1f33;--mut:#5b6b7a;--line:#dfe5ea;--bad:#c0392b;--ok:#1f9d55;--blue:#047fe5;--bg:#f6f8fa;}
  *{box-sizing:border-box;}
  body{margin:0;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:var(--ink);background:var(--bg);}
  .wrap{max-width:960px;margin:0 auto;padding:40px 28px 120px;}
  h1{font-size:26px;margin:0 0 6px;letter-spacing:-0.01em;}
  .lede{color:var(--mut);font-size:15px;line-height:1.55;max-width:680px;margin:0 0 4px;}
  .count{display:inline-block;margin:18px 0 26px;font-size:13px;color:var(--mut);border:1px solid var(--line);background:#fff;padding:6px 12px;}
  .card{display:grid;grid-template-columns:380px 1fr;gap:24px;background:#fff;border:1px solid var(--line);padding:20px;margin:0 0 18px;}
  .card.decided-accept{border-left:4px solid var(--ok);}
  .card.decided-rule{border-left:4px solid var(--blue);}
  .card.decided-fix{border-left:4px solid var(--bad);}
  .card-vis{}
  .crop{position:relative;background-repeat:no-repeat;border:1px solid var(--line);background-color:#0b1f33;}
  .crop-whole{display:flex;align-items:center;justify-content:center;height:220px;}
  .crop-box{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);outline:2px solid #ffd400;box-shadow:0 0 0 9999px rgba(8,18,30,.45);}
  .card-cap{font-size:12px;color:var(--mut);margin-top:8px;text-transform:uppercase;letter-spacing:.08em;}
  .gate{display:inline-block;font-size:11px;text-transform:uppercase;letter-spacing:.1em;color:#fff;background:var(--bad);padding:3px 8px;margin-bottom:10px;}
  .detail{font-size:16px;font-weight:600;margin-bottom:6px;}
  .metric{font-size:14px;margin-bottom:14px;}
  .bad{color:var(--bad);font-weight:700;}.need{color:var(--ink);font-weight:700;}
  .rec{font-size:14px;line-height:1.5;margin-bottom:4px;}
  .why{font-size:13px;color:var(--mut);line-height:1.5;margin-bottom:14px;}
  .opts{display:flex;flex-direction:column;gap:8px;}
  .opt{font-size:14px;border:1px solid var(--line);padding:9px 12px;cursor:pointer;display:flex;align-items:baseline;gap:8px;}
  .opt:hover{background:#fafcfe;}
  .opt-sub{color:var(--mut);font-size:12px;}
  .bar{position:fixed;left:0;right:0;bottom:0;background:#fff;border-top:1px solid var(--line);padding:14px 28px;display:flex;align-items:center;gap:18px;justify-content:center;}
  .bar .sum{font-size:13px;color:var(--mut);}
  button{font:inherit;font-size:15px;font-weight:600;color:#fff;background:var(--blue);border:0;padding:11px 22px;cursor:pointer;}
  button:hover{background:#0369c0;}
  .hint{font-size:12px;color:var(--mut);margin-top:14px;}
  @media(max-width:760px){.card{grid-template-columns:1fr;}}
</style></head>
<body><div class="wrap">
  <h1>Readability QA &mdash; your call</h1>
  <p class="lede">The automatic check flagged the items below before these ads could go out. For each one, look at it, read why, and choose what should happen. Your choices update <b>SoftCo&rsquo;s own</b> rules &mdash; nobody outside your team is involved.</p>
  <p class="lede"><b>Fix it</b> keeps the rule and leaves the ad failing until it is changed. <b>Accept just this one</b> lets a single ad through. <b>Change the rule for all</b> updates the guardrail itself, so use it deliberately.</p>
  <span class="count">${total} item${total === 1 ? '' : 's'} to decide across ${assets.length} ad${assets.length === 1 ? '' : 's'}</span>
  ${cards}
</div>
<div class="bar">
  <span class="sum" id="sum">0 of ${total} decided beyond &ldquo;fix it&rdquo;</span>
  <button id="apply">Apply decisions</button>
</div>
<script>
  const KEY = 'adqa-decisions';
  const cards = [...document.querySelectorAll('.card')];
  function restore(){ const saved = JSON.parse(localStorage.getItem(KEY)||'{}');
    cards.forEach(c=>{ const id=c.dataset.id; const ch=saved[id]; if(ch){ const r=c.querySelector('input[value="'+ch+'"]'); if(r){r.checked=true;} } mark(c); }); upd(); }
  function mark(c){ const v=c.querySelector('input:checked')?.value||'fix'; c.classList.remove('decided-accept','decided-rule','decided-fix'); c.classList.add('decided-'+v); }
  function upd(){ const n=cards.filter(c=>(c.querySelector('input:checked')?.value||'fix')!=='fix').length;
    document.getElementById('sum').textContent = n+' of '+${total}+' decided beyond \\u201cfix it\\u201d'; }
  cards.forEach(c=> c.addEventListener('change',()=>{ const id=c.dataset.id; const v=c.querySelector('input:checked').value;
    const saved=JSON.parse(localStorage.getItem(KEY)||'{}'); saved[id]=v; localStorage.setItem(KEY,JSON.stringify(saved)); mark(c); upd(); }));
  document.getElementById('apply').addEventListener('click',()=>{
    const decisions = cards.map(c=>({ assetId:c.dataset.asset, format:c.dataset.format, gate:c.dataset.gate, el:c.dataset.el,
      choice:(c.querySelector('input:checked')?.value||'fix'), fix: JSON.parse(c.dataset.fix||'null') }));
    const out = { brand:${JSON.stringify(assets[0] ? assets[0].brand : 'softco')}, decisions };
    const blob = new Blob([JSON.stringify(out,null,2)], {type:'application/json'});
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='qa-decisions.json'; a.click();
    alert('Saved qa-decisions.json to your Downloads.\\n\\nNow tell your Claude: \\u201capply QA decisions\\u201d.');
  });
  restore();
</script>
</body></html>`;
  fs.writeFileSync(outPath, html);
  return outPath;
}

if (require.main === module) {
  const [, , resultsPath, outPath] = process.argv;
  if (!resultsPath || !outPath) { console.error('usage: node report.cjs <results.json> <out.html>'); process.exit(2); }
  const data = JSON.parse(fs.readFileSync(resultsPath, 'utf8'));
  buildReview(data.assets, outPath);
  console.log('WROTE', outPath, '(' + data.assets.reduce((s, a) => s + a.violations.length, 0) + ' items)');
}

module.exports = { buildReview };
