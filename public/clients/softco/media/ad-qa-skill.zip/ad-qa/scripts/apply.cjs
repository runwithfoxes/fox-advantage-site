// ad-qa: apply a reviewer's decisions back into the brand's OWN config. This is the
// step that makes a Yes/No actually change what the gate does. Run by the brand's
// own Claude after they click "Apply" on the review page.
//
//   node apply.cjs <qa-decisions.json>
//
// - "accept": waive this one asset -> appended to configs/<brand>.overrides.json
// - "rule":   change the guardrail for all -> patched into configs/<brand>.json
// - "fix":    no change (the ad stays failing until the design is fixed)
//
// Everything is printed in plain English and fails loudly, never silently.

const fs = require('fs');
const path = require('path');

const CONFIG_DIR = path.join(__dirname, '..', 'configs');

function readJSON(p, fallback) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { return fallback; } }

const decPath = process.argv[2];
if (!decPath || !fs.existsSync(decPath)) { console.error('Could not find the decisions file. Usage: node apply.cjs <qa-decisions.json>'); process.exit(2); }

const data = readJSON(decPath, null);
if (!data || !Array.isArray(data.decisions)) { console.error('That file is not a valid qa-decisions.json (no decisions array). Nothing changed.'); process.exit(2); }

const brand = data.brand || 'softco';
const cfgPath = path.join(CONFIG_DIR, brand + '.json');
const ovPath = path.join(CONFIG_DIR, brand + '.overrides.json');
if (!fs.existsSync(cfgPath)) { console.error(`No config for brand "${brand}" at ${cfgPath}. Nothing changed.`); process.exit(2); }

const cfg = readJSON(cfgPath, null);
const overrides = readJSON(ovPath, []);
const log = [];

for (const d of data.decisions) {
  if (d.choice === 'accept') {
    if (!overrides.some(o => o.assetId === d.assetId && o.gate === d.gate && o.el === d.el)) {
      overrides.push({ assetId: d.assetId, gate: d.gate, el: d.el, when: '' });
      log.push(`ACCEPTED one asset: "${d.assetId}" may pass despite [${d.gate}] on ${d.el}.`);
    }
  } else if (d.choice === 'rule' && d.fix) {
    const f = d.fix;
    const fc = cfg.formats[f.format] || (cfg.formats[f.format] = Object.assign({}, cfg.formats._default));
    if (f.type === 'minFontPx') {
      const before = fc.minFontPx; fc.minFontPx = Math.min(before != null ? before : f.value, f.value);
      log.push(`RULE CHANGED: ${f.format} minimum font ${before}px -> ${fc.minFontPx}px (applies to all future ${f.format} ads).`);
    } else if (f.type === 'maxWords') {
      const before = fc.maxWords; fc.maxWords = Math.max(before != null ? before : f.value, f.value);
      log.push(`RULE CHANGED: ${f.format} word cap ${before} -> ${fc.maxWords} (applies to all future ${f.format} ads).`);
    } else if (f.type === 'approvedPair') {
      cfg.contrast.approvedPairs = cfg.contrast.approvedPairs || [];
      if (!cfg.contrast.approvedPairs.some(p => p.fg === f.fg && p.bg === f.bg)) {
        cfg.contrast.approvedPairs.push({ fg: f.fg, bg: f.bg });
        log.push(`RULE CHANGED: approved the colour pair ${f.fg} on ${f.bg} for large text (applies brand-wide).`);
      }
    }
  } // 'fix' -> intentionally no change
}

if (!log.length) { console.log('No changes to apply (everything was left as "fix it"). The flagged ads still need their designs corrected.'); process.exit(0); }

fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2) + '\n');
fs.writeFileSync(ovPath, JSON.stringify(overrides, null, 2) + '\n');

console.log('Applied ' + log.length + ' decision(s) to SoftCo\'s QA rules:\n');
for (const l of log) console.log('  - ' + l);
console.log('\nConfig: ' + cfgPath);
console.log('Waivers: ' + ovPath);
console.log('\nRe-run the ad and it will now follow these calls.');
