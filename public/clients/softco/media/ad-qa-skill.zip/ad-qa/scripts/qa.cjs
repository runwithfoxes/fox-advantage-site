// ad-qa: reusable readability QA gate for HTML-rendered ads.
//
// Two ways to use:
//   1) CLI:    NODE_PATH=<playwright> node qa.cjs <brand> <format> <resolved.html> [W] [H]
//   2) Module: const qa = require('.../ad-qa/scripts/qa.cjs')
//              const res = await qa.runQAOnPage(page, brand, format, W, H)  // page already at READY
//
// Gates (every one measured from a real render, never eyeballed):
//   1 contrast  - two-tier: body >= 4.5:1, large >= 3:1 OR an approved brand pair
//   2 min-font  - each text block >= the per-format floor (px at true output size)
//   3 edge      - text not jammed against the canvas edge; logo not buried
//   4 density   - words per asset under the format cap; single-line formats stay one line
//
// Contrast is computed from the ACTUAL pixels behind each text block (the rendered
// screenshot is sampled in a ring around the block), so gradients and photo
// backgrounds are handled the same as flat colour. Worst-case sample wins.
//
// Verdict: { pass, violations:[...] }. CLI exits 1 on fail. Bypass with QA_OFF=1;
// warn-not-block with QA_WARN=1 (handled by the caller, e.g. produce.cjs).

const fs = require('fs');
const path = require('path');

const CONFIG_DIR = path.join(__dirname, '..', 'configs');

// ---- config ----
function loadConfig(brand) {
  const def = JSON.parse(fs.readFileSync(path.join(CONFIG_DIR, '_default.json'), 'utf8'));
  const bp = path.join(CONFIG_DIR, (brand || '_default') + '.json');
  if (!fs.existsSync(bp)) return normalise(def, def);
  const b = JSON.parse(fs.readFileSync(bp, 'utf8'));
  return normalise(b, def);
}
function normalise(b, def) {
  return {
    brand: b.brand || def.brand,
    contrast: Object.assign({}, def.contrast, b.contrast),
    logo: Object.assign({}, def.logo, b.logo),
    formats: Object.assign({}, def.formats, b.formats),
  };
}
function fmtCfg(cfg, format) {
  const base = cfg.formats._default || {};
  return Object.assign({}, base, cfg.formats[format] || {});
}

// ---- colour maths (WCAG 2.x) ----
function lin(c) { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
function lum(p) { return 0.2126 * lin(p.r) + 0.7152 * lin(p.g) + 0.0722 * lin(p.b); }
function ratio(a, b) { const L1 = lum(a), L2 = lum(b), hi = Math.max(L1, L2), lo = Math.min(L1, L2); return (hi + 0.05) / (lo + 0.05); }
function blend(fg, bg, a) { return { r: fg.r * a + bg.r * (1 - a), g: fg.g * a + bg.g * (1 - a), b: fg.b * a + bg.b * (1 - a) }; }
function hexToRgb(h) { h = h.replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h, 16); return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 }; }
function near(a, b, tol) { return Math.abs(a.r - b.r) <= tol && Math.abs(a.g - b.g) <= tol && Math.abs(a.b - b.b) <= tol; }

// ---- in-page collection: every text block + the logo ----
async function collect(page, W, H) {
  return await page.evaluate(({ W, H }) => {
    function parseColor(s) {
      const m = s.match(/rgba?\(([^)]+)\)/); if (!m) return { r: 0, g: 0, b: 0, a: 1 };
      const p = m[1].split(',').map(x => parseFloat(x));
      return { r: p[0], g: p[1], b: p[2], a: p[3] === undefined ? 1 : p[3] };
    }
    const blocks = [];
    for (const el of document.querySelectorAll('*')) {
      const cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) continue;
      let t = '';
      for (const n of el.childNodes) if (n.nodeType === 3) t += n.nodeValue;
      t = t.replace(/\s+/g, ' ').trim();
      if (!t) continue;
      const r = el.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) continue;
      if (r.right <= 0 || r.bottom <= 0 || r.left >= W || r.top >= H) continue;
      const col = parseColor(cs.color);
      blocks.push({
        tag: el.id || (typeof el.className === 'string' && el.className) || el.tagName.toLowerCase(),
        text: t, words: t.split(' ').length, chars: t.length,
        fontPx: parseFloat(cs.fontSize), weight: parseInt(cs.fontWeight) || 400,
        color: { r: col.r, g: col.g, b: col.b }, alpha: col.a * parseFloat(cs.opacity),
        lineHeight: cs.lineHeight === 'normal' ? parseFloat(cs.fontSize) * 1.2 : parseFloat(cs.lineHeight),
        rect: { x: r.left, y: r.top, w: r.width, h: r.height, right: r.right, bottom: r.bottom },
      });
    }
    const logoEl = document.getElementById('logo');
    let logo = null;
    if (logoEl) { const lr = logoEl.getBoundingClientRect(); logo = { rect: { x: lr.left, y: lr.top, w: lr.width, h: lr.height, right: lr.right, bottom: lr.bottom } }; }
    return { blocks, logo };
  }, { W, H });
}

// ---- sample the background behind each block from the screenshot (in-page canvas) ----
async function sampleBg(page, b64, rects, W, H) {
  return await page.evaluate(async ({ b64, rects, W, H }) => {
    const img = await createImageBitmap(await (await fetch('data:image/png;base64,' + b64)).blob());
    const cv = new OffscreenCanvas(W, H); const ctx = cv.getContext('2d');
    ctx.drawImage(img, 0, 0, W, H);
    const data = ctx.getImageData(0, 0, W, H).data;
    const px = (x, y) => { x = Math.max(0, Math.min(W - 1, Math.round(x))); y = Math.max(0, Math.min(H - 1, Math.round(y))); const i = (y * W + x) * 4; return { r: data[i], g: data[i + 1], b: data[i + 2] }; };
    // Sample directly ABOVE and BELOW the block only. Left/right of a block can be a
    // neighbouring inline element (e.g. white headline text around a coloured span),
    // which would read as a false background. Above/below a line is the real backdrop.
    const d = 6;
    return rects.map(r => [
      [r.x + 2, r.y - d], [r.x + r.w / 2, r.y - d], [r.right - 2, r.y - d],
      [r.x + 2, r.bottom + d], [r.x + r.w / 2, r.bottom + d], [r.right - 2, r.bottom + d],
    ].map(([x, y]) => px(x, y)));
  }, { b64, rects, W, H });
}

// ---- the gate ----
async function runQAOnPage(page, brand, format, W, H) {
  const cfg = loadConfig(brand);
  const f = fmtCfg(cfg, format);
  const C = cfg.contrast;
  const { blocks, logo } = await collect(page, W, H);
  const shot = await page.screenshot({ clip: { x: 0, y: 0, width: W, height: H } });
  const bg = await sampleBg(page, shot.toString('base64'), blocks.map(b => b.rect), W, H);
  const V = [];

  blocks.forEach((b, i) => {
    const isLarge = b.fontPx >= C.largePx || (b.weight >= 700 && b.fontPx >= C.largeBoldPx);
    let worst = Infinity, worstBg = null;
    for (const s of bg[i]) {
      const eff = b.alpha < 1 ? blend(b.color, s, b.alpha) : b.color;
      const cr = ratio(eff, s);
      if (cr < worst) { worst = cr; worstBg = s; }
    }
    let whitelisted = false;
    if (isLarge && C.approvedPairs) {
      for (const p of C.approvedPairs) {
        if (near(b.color, hexToRgb(p.fg), p.tol || 10) && worstBg && near(worstBg, hexToRgb(p.bg), p.bgTol || 18)) { whitelisted = true; break; }
      }
    }
    const min = isLarge ? C.largeMin : C.bodyMin;
    if (!whitelisted && worst < min) {
      V.push({ gate: 'contrast', el: b.tag, detail: `"${snip(b.text)}" ${isLarge ? 'large' : 'body'} text`, measured: worst.toFixed(2) + ':1', threshold: '>= ' + min + ':1' });
    }
    if (f.minFontPx != null && b.fontPx < f.minFontPx) {
      V.push({ gate: 'min-font', el: b.tag, detail: `"${snip(b.text)}"`, measured: round(b.fontPx) + 'px', threshold: '>= ' + f.minFontPx + 'px' });
    }
    if (f.minEdgePx != null) {
      const edge = Math.min(b.rect.x, b.rect.y, W - b.rect.right, H - b.rect.bottom);
      if (edge < f.minEdgePx) V.push({ gate: 'edge', el: b.tag, detail: `"${snip(b.text)}" too close to the canvas edge`, measured: round(edge) + 'px', threshold: '>= ' + f.minEdgePx + 'px' });
    }
    if (f.singleLine) {
      const lines = b.rect.h / (b.lineHeight || b.fontPx * 1.2);
      if (lines > 1.6) V.push({ gate: 'single-line', el: b.tag, detail: `"${snip(b.text)}" wraps past one line`, measured: round(lines) + ' lines', threshold: '1 line' });
    }
  });

  if (f.maxWords != null) {
    const total = blocks.reduce((s, b) => s + b.words, 0);
    if (total > f.maxWords) V.push({ gate: 'density', el: '(asset)', detail: 'too many words for this format', measured: total + ' words', threshold: '<= ' + f.maxWords });
  }

  if (logo) {
    if (cfg.logo.minHeightPx && logo.rect.h < cfg.logo.minHeightPx) {
      V.push({ gate: 'logo-size', el: 'logo', detail: 'logo below minimum height', measured: round(logo.rect.h) + 'px', threshold: '>= ' + cfg.logo.minHeightPx + 'px' });
    }
    for (const b of blocks) {
      const overlapX = b.rect.x < logo.rect.right && b.rect.right > logo.rect.x;
      const overlapY = b.rect.y < logo.rect.bottom && b.rect.bottom > logo.rect.y;
      if (overlapX && overlapY) { V.push({ gate: 'logo-clear', el: b.tag, detail: 'text overlaps the logo', measured: 'overlap', threshold: 'no overlap' }); break; }
    }
  }

  return { pass: V.length === 0, violations: V, counts: { blocks: blocks.length } };
}

function snip(t) { return t.length > 40 ? t.slice(0, 40) + '…' : t; }
function round(n) { return Math.round(n); }

function printReport(res, label) {
  if (res.pass) { console.log(`QA PASS  ${label}  (${res.counts.blocks} text blocks checked, all gates clear)`); return; }
  console.log(`QA FAIL  ${label}  - ${res.violations.length} violation(s):`);
  for (const v of res.violations) console.log(`  [${v.gate}] ${v.el}: ${v.detail}  ->  measured ${v.measured}, need ${v.threshold}`);
}

// ---- CLI ----
if (require.main === module) {
  (async () => {
    const [, , brand, format, htmlPath, wStr, hStr] = process.argv;
    if (!brand || !format || !htmlPath) { console.error('usage: node qa.cjs <brand> <format> <resolved.html> [W] [H]'); process.exit(2); }
    const W = parseInt(wStr || '1080', 10), H = parseInt(hStr || '1080', 10);
    const { chromium } = require('playwright');
    const browser = await chromium.launch();
    const page = await browser.newPage({ viewport: { width: W, height: H } });
    await page.goto('file://' + path.resolve(htmlPath));
    try { await page.waitForFunction('window.READY === true', null, { timeout: 15000 }); }
    catch (e) { await page.waitForTimeout(500); }
    const res = await runQAOnPage(page, brand, format, W, H);
    await browser.close();
    printReport(res, `${brand}/${format}`);
    process.exit(res.pass ? 0 : 1);
  })();
}

module.exports = { loadConfig, fmtCfg, runQAOnPage, printReport };
