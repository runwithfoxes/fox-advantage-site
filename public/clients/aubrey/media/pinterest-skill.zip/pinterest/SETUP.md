# Setup

Do this once. About ten minutes, most of it waiting for installs.

You need three things: the files in the right folder, some Python packages, and
your own Replicate token.

---

## 1. Put the skill where Claude Code will find it

Unzip this folder into your project, at exactly this path:

```
your-project/
  .claude/
    skills/
      pinterest/
        SKILL.md
        SETUP.md
        requirements.txt
        scripts/
```

The folder must be called `pinterest`, and `SKILL.md` must sit directly inside it.
That is how Claude Code finds a skill. Nothing else registers it, there is no
install step, no config file to edit. The file being in the right place *is* the
installation.

If you want it available in **every** project rather than just this one, put it at
`~/.claude/skills/pinterest/` instead.

Restart Claude Code. Type `/pinterest` and it should appear.

---

## 2. Install the packages

In your terminal, from inside the `pinterest` folder:

```bash
pip3 install -r requirements.txt
python3 -m playwright install chromium
```

The second line downloads a headless browser. It is a big download and it will sit
there looking like it has hung. It has not. Let it finish.

**What each one is for:**

| Package | Why |
|---|---|
| `requests` | Talks to the image model |
| `playwright` | A browser with no window. Screenshots live sites, and renders crisp text onto images |
| `pillow` | Reads image dimensions |
| `gallery-dl` | Downloads the Pinterest image from a pin URL |

---

## 3. Get your own Replicate token

Generating an image costs money. Not much, about **3 cents an image**, but it is
real, and it goes on your card, so the token has to be yours.

1. Make an account at **https://replicate.com** (you can sign in with GitHub).
2. Add a card. Replicate is pay as you go, there is no subscription.
3. Go to **https://replicate.com/account/api-tokens** and copy your token. It starts
   with `r8_`.
4. Open your shell config file. On a Mac that is almost certainly `~/.zshrc`:

   ```bash
   open -e ~/.zshrc
   ```

5. Add this line at the bottom, with your real token in place of the example:

   ```bash
   export REPLICATE_API_TOKEN='r8_your_real_token_goes_here'
   ```

6. Save it, close the terminal, and **open a new one**. This matters. The old
   terminal will never see the new line.

7. Check it worked:

   ```bash
   echo $REPLICATE_API_TOKEN
   ```

   If that prints your token, you are done. If it prints nothing, step 6 did not
   happen, or the line went into the wrong file.

### Keep the token to yourself

Never paste that token into a document, a chat, a shared file, or a public repo.
Anyone who has it can spend your money. It lives in `~/.zshrc` on your machine and
nowhere else. If you ever think it has leaked, revoke it on the same Replicate page
and make a new one. That takes ten seconds and costs nothing.

---

## 4. Check the whole thing works

Ask Claude Code to run this. It costs nothing, it does not generate anything, it
just proves the browser and the screenshotter are alive:

```bash
python3 scripts/screenshot.py --url "https://example.com" --out /tmp/test.png
```

If a PNG lands at `/tmp/test.png`, the setup is good.

---

## What it costs, so there are no surprises

| Thing | Cost |
|---|---|
| Pulling a pin | Free |
| Screenshotting a live site | Free |
| Overlaying a headline | Free |
| **Generating an image** | **About 3 cents** |

Only one line in that table charges you, and the skill is built to stop and ask
before it crosses it. That is what the gate check in `SKILL.md` is for. If Claude
ever generates without showing you the gate check first, that is a bug, tell it so.

Ten directions, generated twice each while you iterate, is about a dollar. This is
not a thing you need to budget for. It is a thing you need to be *aware* of, which
is different.
