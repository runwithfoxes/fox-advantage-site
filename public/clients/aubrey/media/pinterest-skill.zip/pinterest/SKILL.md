---
name: pinterest
description: Turn a Pinterest pin into a finished mockup of a brand living in that aesthetic. Two surfaces - a billboard (a fresh cinematic scene with a headline overlaid) and a homepage (the brand's real live homepage re-rendered in the pin's look). Use when someone pastes a pinterest.com or pin.it link, says "what would this look like in that style", "show me this as a billboard", "restyle the homepage like this pin", or is choosing between visual directions and wants to see them made real instead of described.
---

# pinterest - the aesthetic visualiser

Show someone what a direction looks like, instead of describing it. Paste a pin,
get back the brand rendered in that world.

**The chain:** paste a pin, pull the image, read its aesthetic, generate the brand
in that aesthetic, overlay the real message, finished PNG.

**The insight that shapes everything:** the brand's *existing* look mostly does not
matter, because the whole point is to reimagine it. What stays constant is only the
brand **name**, **what it does** (one line), and the **message** for this direction.
Everything visual is generated fresh from the pin.

## Before anything: check the setup

If `REPLICATE_API_TOKEN` is not set, stop and read `SETUP.md`. Every generation
costs real money (about 3 cents an image). Never generate without approval.

## The two surfaces

They work **differently**. Do not conflate them.

| Surface | What it is | Method |
|---|---|---|
| **Billboard** | 16:9 cinematic scene of the brand in the aesthetic, message overlaid | Generate fresh (steps 1 to 5) |
| **Homepage** | The brand's *real* homepage re-rendered in the aesthetic, same layout and nav and copy | Screenshot the live site, feed it in as the structure (see Homepage) |

**Hard lesson, already paid for:** for a homepage, do NOT generate a pretty image and
hand-build a page around it, and do NOT paste the pin onto a page. Both look wrong.
Feed the *real homepage screenshot* in as the structural reference, so the client sees
*their own page* reimagined.

## Step 1 - Pull the pin

```bash
gallery-dl -D . "<pin-or-board-url>"
```

A single pin gives one image. A board URL gives every image on it. Then **open the
image and look at it.** You cannot write the prompt from the URL.

## Step 2 - Read the aesthetic into a spec

From the image, write down, in this order:

- **Palette** - the actual inks. Two or three, named.
- **Type** - weight, width, case, era.
- **Photo treatment** - duotone, grain, blown highlights, flat vector, whatever it is.
- **Texture** - paper, print, ink, none.
- **Composition** - where things sit, what is empty.
- **Mood** - one line.

This becomes the prompt. The pin is *also* passed to the model as a reference image,
because it carries the look better than any words you can write about it.

## Step 3 - The gate check (HARD RULE)

Never call the generator without putting this in front of the human first. It costs money.

```
GATE CHECK
[ ] Surface          - billboard or homepage
[ ] Scene concept    - what is happening, and where the message goes
[ ] Message position - which band of the frame stays EMPTY for the text
[ ] Message          - the headline, verbatim
[ ] Prompt           - the full prompt, verbatim
[ ] Reference images - the pin, plus the structural ref if it is a homepage
[ ] Aspect ratio     - 16:9 billboard / 3:4 or 16:9 homepage

Approve to generate?
```

Decide the message position **before** you write the prompt, and reserve an empty band
for it (open sky, a blank wall, a flat field of colour). State it as an explicit
fraction in the prompt: *"the entire top quarter is open sky with nothing in it."*
Otherwise the model fills the frame and the headline lands on top of a face.

## Step 4 - Generate the scene

```bash
python3 scripts/generate.py \
  --mood-ref pin.jpg \
  --prompt "<the full prompt>" \
  --aspect 16:9 \
  --out out/brand-billboard-scene.png
```

Prompt style that is proven to work:

- Keep any brand character described consistently ("Pixar-style", or whatever it is).
- Describe the environment as **photographed**: "photographed on location, shot on 35mm film".
- End with a lighting instruction: "cinematic film photography lighting".
- Name the empty band explicitly.

## Step 5 - Overlay the real message

The model **cannot render exact text.** It will produce something that looks like your
headline from three feet away and is gibberish up close. So the type goes on afterwards,
crisply, in HTML.

```bash
python3 scripts/overlay.py \
  --scene out/brand-billboard-scene.png \
  --headline "Stop following|Start hunting" \
  --out out/brand-billboard.png \
  --text-color "#FAFAF8"
```

- Lines split on `|`.
- A dark gradient **scrim** sits behind the headline by default. It fixes the contrast
  weak spot where text crosses a bright part of the image. `--no-scrim` to drop it.
- `--pos bottom` moves the headline. `--logo "/Yourbrand"` adds a small wordmark.
- `--font` takes any Google Font name (default Anton).

## Step 6 - Review, then show

**Open the PNG and look at it.** Say what you actually see before you show anyone. Check:

- Text never touches the subject's face.
- Contrast holds across the *whole* headline, not just the start of it.
- No full stop at the end of the headline.
- The wordmark is small, and the right colour for the scene.
- Nothing is clipped at the edges.

If it is wrong, say it is wrong. A mockup that flatters the direction is worse than
useless, because someone will pick the direction based on it.

## Homepage - restyle the real page

This surface does **not** generate a scene. It re-renders the client's actual homepage.

**1. Screenshot the live homepage.**

```bash
python3 scripts/screenshot.py --url "https://example.com" --out live-homepage.png
```

**2. Feed the screenshot plus the pin to the generator.** The screenshot is the
*structure* (passed first). The pin is the *aesthetic* (passed second).

```bash
python3 scripts/generate.py \
  --structure-ref live-homepage.png \
  --mood-ref pin.jpg \
  --aspect 16:9 \
  --out out/brand-homepage.png \
  --prompt "Redesign this website homepage (first image) in the visual aesthetic, colour palette and mood of the second reference image. Keep the exact same layout, structure, top navigation bar, large headline and body paragraph in their current positions, so it still clearly reads as a real website homepage. Transform the hero photograph into <the aesthetic scene>. Recolour the whole page to <the palette>. Keep <the subject> in the hero. Clean modern web design, sharp legible text, no rounded corners."
```

**3. What you get.** A concept mockup. The layout, the nav and the headline hold, and
the text comes back largely legible. **Body copy will be garbled up close. That is
normal and it is not a bug you can fix by re-prompting.** It is a vibe shot for a
positioning conversation, not a deployable page. If one headline has to be perfect,
overlay it afterwards with `overlay.py`.

## Known failure modes (all of these have actually happened)

| What happens | Why | What to do |
|---|---|---|
| The page turns into a poster or a newspaper | The pin *was* a poster, and the model followed the pin harder than the structure | Say explicitly: "this is a website, not a poster. No printed columns, no fake headlines." |
| The subject's face stays in original colour while the background gets the treatment | The model treats the person as a cutout | Say: "the portrait itself is fully <treatment>, no original colour left in the face" |
| The aesthetic is right but flat/vector came back rendered and airbrushed | "Flat" is a weak word to a model | Name it hard: "hard-edged flat vector shapes, no gradients, no shading, no soft light" |
| Body copy is nonsense | The model cannot render text. It never will. | Expected. Overlay real type, or accept it as a vibe shot |
| The headline lands on a face | No empty band was reserved | Go back to step 3. This is a prompt failure, not a luck failure |

**When the pin is itself a web design** rather than a photograph or a poster, this whole
method fights you, because image models are good at scenes and bad at interfaces. The
honest route then is to generate the *illustration* alone and build the page around it
in real HTML.

## Output convention

```
out/{direction}/
   {brand}-{direction}-billboard.png         finished, message on it
   {brand}-{direction}-billboard-scene.png   the raw scene before the overlay
   {brand}-{direction}-homepage.png
```

One folder per direction. Keep the raw scene: you will want to re-overlay a different
headline on it, and re-generating costs money.
