#!/usr/bin/env python3
"""Generate a brand in a borrowed aesthetic (Seedream 4.5, via Replicate).

Two ways to call it:

  BILLBOARD - a fresh scene in the pin's aesthetic
    python3 generate.py \
      --mood-ref pin.jpg \
      --prompt "..." \
      --aspect 16:9 \
      --out out/billboard-scene.png

  HOMEPAGE - the real homepage, re-rendered in the pin's aesthetic
    python3 generate.py \
      --structure-ref live-homepage.png \
      --mood-ref pin.jpg \
      --aspect 16:9 \
      --out out/homepage.png \
      --prompt "Redesign this website homepage (first image) in the ... of the second image ..."

Reference images are sent in the order: structure first, then mood. That order
matters: the prompt refers to them as "first image" and "second image".

Costs real money (about 3 cents an image). Never run it without approval.
"""
import argparse
import os
import sys
import time

try:
    import requests
except ImportError:
    sys.exit(
        "Missing the 'requests' package.\n"
        "Run:  pip3 install -r requirements.txt"
    )

API = "https://api.replicate.com/v1"
MODEL = "bytedance/seedream-4.5"

TOKEN = os.environ.get("REPLICATE_API_TOKEN", "").strip()
if not TOKEN:
    sys.exit(
        "REPLICATE_API_TOKEN is not set.\n\n"
        "This skill generates images through Replicate, so it needs your own\n"
        "Replicate token. Read SETUP.md - it takes about two minutes.\n\n"
        "Short version:\n"
        "  1. Make an account at https://replicate.com\n"
        "  2. Copy your token from https://replicate.com/account/api-tokens\n"
        "  3. Add this line to ~/.zshrc, then open a new terminal:\n"
        "       export REPLICATE_API_TOKEN='r8_your_token_here'\n"
    )

HEADERS = {"Authorization": f"Bearer {TOKEN}"}


def upload(path):
    """Upload a local image to Replicate and return a URL the model can read."""
    path = os.path.expanduser(path)
    if not os.path.isfile(path):
        sys.exit(f"Reference image not found: {path}")
    with open(path, "rb") as f:
        r = requests.post(
            f"{API}/files",
            headers=HEADERS,
            files={"content": (os.path.basename(path), f, "application/octet-stream")},
        )
    if r.status_code == 401:
        sys.exit(
            "Replicate rejected the token (401).\n"
            "Check REPLICATE_API_TOKEN is your real token and has not been revoked:\n"
            "  https://replicate.com/account/api-tokens"
        )
    r.raise_for_status()
    return r.json()["urls"]["get"]


def main():
    ap = argparse.ArgumentParser(description="Generate a brand in a borrowed aesthetic.")
    ap.add_argument("--prompt", required=True, help="the full prompt, verbatim")
    ap.add_argument("--mood-ref", required=True,
                    help="the Pinterest pin: the aesthetic to borrow")
    ap.add_argument("--structure-ref", default=None,
                    help="optional. A homepage screenshot, or a character/product "
                         "reference. Sent FIRST, so the prompt calls it 'first image'.")
    # These lists are the model's real ones. Do not add to them: anything the
    # model does not know is a 422 back from the API.
    ap.add_argument("--aspect", default="16:9",
                    choices=["1:1", "4:3", "3:4", "4:5", "5:4", "16:9", "9:16",
                             "3:2", "2:3", "21:9", "9:21", "match_input_image"],
                    help="16:9 billboard or homepage, 3:4 portrait")
    ap.add_argument("--size", default="2K", choices=["2K", "4K"])
    ap.add_argument("--out", required=True, help="where to write the PNG")
    a = ap.parse_args()

    out = os.path.expanduser(a.out)

    print("Uploading reference images...")
    refs = []
    if a.structure_ref:
        refs.append(upload(a.structure_ref))   # "first image"
    refs.append(upload(a.mood_ref))            # "second image" (or the only one)
    print(f"  {len(refs)} reference(s) uploaded")

    print(f"Generating ({a.aspect}, {a.size})... this usually takes 40 to 60 seconds.")
    r = requests.post(
        f"{API}/models/{MODEL}/predictions",
        headers=HEADERS,
        json={"input": {
            "prompt": a.prompt,
            "image_input": refs,
            "size": a.size,
            "aspect_ratio": a.aspect,
        }},
    )
    r.raise_for_status()
    get_url = r.json()["urls"]["get"]

    for _ in range(90):
        time.sleep(5)
        s = requests.get(get_url, headers=HEADERS).json()
        status = s["status"]
        print(f"  {status}")
        if status == "succeeded":
            output = s["output"]
            img_url = output[0] if isinstance(output, list) else output
            parent = os.path.dirname(out)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(out, "wb") as f:
                f.write(requests.get(img_url).content)
            print(f"\nSAVED: {out}")
            print("Now OPEN it and look at it before showing anyone.")
            return
        if status in ("failed", "canceled"):
            sys.exit(f"Generation {status}: {s.get('error')}")

    sys.exit("Timed out after 7 minutes. Check https://replicate.com/predictions")


if __name__ == "__main__":
    main()
