#!/usr/bin/env python3
"""Overlay a real headline onto a generated scene.

The image model cannot render text. It produces something that looks like your
headline from three feet away and is gibberish up close. So the type goes on
afterwards, crisply, via HTML and a headless browser at 2x.

  python3 overlay.py \
    --scene out/billboard-scene.png \
    --headline "Stop following|Start hunting" \
    --out out/billboard.png

A dark gradient scrim sits behind the headline by default, so contrast holds
wherever the text crosses a bright part of the image. --no-scrim to drop it.

Free. No API, no cost.
"""
import argparse
import os
import sys
import tempfile

try:
    from PIL import Image
    from playwright.sync_api import sync_playwright
except ImportError:
    sys.exit(
        "Missing playwright or pillow.\n"
        "Run:  pip3 install -r requirements.txt\n"
        "Then: python3 -m playwright install chromium"
    )

HTML = """<!DOCTYPE html><html><head><meta charset="utf-8">
<link href="https://fonts.googleapis.com/css2?family={FONT_URL}:wght@400&family=JetBrains+Mono:wght@300&display=swap" rel="stylesheet">
<style>
  * {{ margin:0; padding:0; box-sizing:border-box; }}
  html,body {{ width:{W}px; height:{H}px; overflow:hidden; }}
  .stage {{ position:relative; width:{W}px; height:{H}px;
    background:url('file://{SCENE}') center/cover; }}
  .scrim {{ position:absolute; left:0; right:0; {SCRIM_EDGE}:0; height:38%;
    background:linear-gradient(to {SCRIM_DIR}, rgba(0,0,0,.55), rgba(0,0,0,0));
    display:{SCRIM_DISPLAY}; }}
  .headline {{ position:absolute; {POS} left:50%; transform:translateX(-50%);
    text-align:center; font-family:'{FONT}',sans-serif; font-size:{FS}px;
    line-height:1.02; color:{TEXT_COLOR}; text-transform:uppercase; letter-spacing:4px;
    text-shadow:0 3px 18px rgba(0,0,0,.65),0 1px 4px rgba(0,0,0,.45); white-space:nowrap; }}
  .logo {{ position:absolute; right:42px; bottom:30px; font-family:'JetBrains Mono',monospace;
    font-weight:300; font-size:22px; letter-spacing:1px; color:{TEXT_COLOR};
    text-shadow:0 1px 6px rgba(0,0,0,.5); display:{LOGO_DISPLAY}; }}
</style></head><body>
  <div class="stage"><div class="scrim"></div>
    <div class="headline">{HEADLINE}</div>
    <div class="logo">{LOGO}</div></div>
</body></html>"""


def main():
    ap = argparse.ArgumentParser(description="Overlay a headline onto a scene.")
    ap.add_argument("--scene", required=True, help="the generated PNG")
    ap.add_argument("--headline", required=True,
                    help="lines split by | e.g. 'Stop following|Start hunting'")
    ap.add_argument("--out", required=True)
    ap.add_argument("--logo", default="", help="optional small wordmark, bottom right")
    ap.add_argument("--text-color", default="#FAFAF8",
                    help="#FAFAF8 on dark scenes, #333333 on bright ones")
    ap.add_argument("--font", default="Anton",
                    help="any Google Font name, e.g. Anton, Oswald, Archivo Black")
    ap.add_argument("--pos", default="top", choices=["top", "bottom"])
    ap.add_argument("--font-size", type=int, default=58)
    ap.add_argument("--no-scrim", action="store_true")
    a = ap.parse_args()

    scene = os.path.abspath(os.path.expanduser(a.scene))
    out = os.path.expanduser(a.out)
    if not os.path.isfile(scene):
        sys.exit(f"Scene not found: {scene}")

    iw, ih = Image.open(scene).size
    W = 1280
    H = round(W * ih / iw)

    top = a.pos == "top"
    html = HTML.format(
        W=W, H=H, SCENE=scene,
        HEADLINE="<br>".join(a.headline.split("|")),
        LOGO=a.logo,
        LOGO_DISPLAY=("block" if a.logo else "none"),
        TEXT_COLOR=a.text_color,
        FONT=a.font,
        FONT_URL=a.font.replace(" ", "+"),
        FS=a.font_size,
        POS=("top:42px;" if top else "bottom:64px;"),
        SCRIM_EDGE=("top" if top else "bottom"),
        SCRIM_DIR=("bottom" if top else "top"),
        SCRIM_DISPLAY=("none" if a.no_scrim else "block"),
    )

    tmp = os.path.join(tempfile.gettempdir(), "_pinterest_overlay.html")
    with open(tmp, "w") as f:
        f.write(html)

    parent = os.path.dirname(out)
    if parent:
        os.makedirs(parent, exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": W, "height": H}, device_scale_factor=2)
        page.goto(f"file://{tmp}")
        page.wait_for_timeout(1500)  # let the web font actually load before shooting
        page.screenshot(path=out)
        browser.close()

    print(f"SAVED: {out}")
    print("Open it. Check the text does not touch the subject and the contrast holds.")


if __name__ == "__main__":
    main()
