#!/usr/bin/env python3
"""Screenshot a live homepage, to use as the structural reference for a restyle.

  python3 screenshot.py --url "https://example.com" --out live-homepage.png

Captures the above-the-fold hero at 2x, which is what the restyle needs. Pass
--full-page for the whole scrolling page (rarely what you want here: the model
handles one screenful far better than a long strip).

Free. No API, no cost. This is just a browser.
"""
import argparse
import os
import sys

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    sys.exit(
        "Missing playwright.\n"
        "Run:  pip3 install -r requirements.txt\n"
        "Then: python3 -m playwright install chromium"
    )


def main():
    ap = argparse.ArgumentParser(description="Screenshot a live homepage.")
    ap.add_argument("--url", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--width", type=int, default=1440)
    ap.add_argument("--height", type=int, default=900)
    ap.add_argument("--full-page", action="store_true")
    ap.add_argument("--wait", type=int, default=6000,
                    help="milliseconds to wait after load, for fonts and images")
    a = ap.parse_args()

    out = os.path.expanduser(a.out)
    parent = os.path.dirname(out)
    if parent:
        os.makedirs(parent, exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(
            viewport={"width": a.width, "height": a.height},
            device_scale_factor=2,
        )
        # Deliberately NOT wait_until="networkidle": plenty of real sites keep a
        # socket open forever (chat widgets, analytics) and never go idle, so it
        # just times out. Load the DOM, then wait a beat for fonts and images.
        page.goto(a.url, wait_until="domcontentloaded", timeout=60000)
        page.wait_for_timeout(a.wait)
        page.screenshot(path=out, full_page=a.full_page)
        title = page.title()
        browser.close()

    print(f"SAVED: {out}")
    print(f"Page title: {title}")
    print("Open it and check the hero actually captured before you generate from it.")


if __name__ == "__main__":
    main()
