# The kit

Seven files. They are not for reading. They are for **pasting into Claude Code**.

The guide (`index.html`) tells you why. This tells your laptop what to do.

Use them in order. Each one says at the top exactly when to paste it and what
should exist before you do.

| File | When | What it does |
|---|---|---|
| `01-brand-extraction-prompt.md` | Phase 1, once you have the screengrabs in a folder | Makes Claude read your screengrabs and pull an aesthetic out of them, then argue with you about it |
| `02-BRAND.template.md` | Phase 2 | The empty brand spec. Every section, every rule slot, with the checkable-rule test baked in |
| `03-MESSAGING.template.md` | Phase 3 | The empty messaging framework |
| `04-CLAUDE.template.md` | Phase 5, the moment the repo exists | Goes at the repo root. The always-on law **and the audit gate**. This is the single most important file in the project |
| `05-build-prompts.md` | Phase 6 | The exact prompts for the styleguide, each page, and the change loop |
| `06-deploy.md` | Phase 7 | Deploy, domain, and the two things that will bite you |
| `07-chatbot.md` | Phase 9 | Real code. The API route, the widget, and the system prompt that stops it inventing things |

## The one thing to understand before you start

Claude Code is very good and completely without judgement about your brand. It
will do exactly what the last sentence you said implies, and then it will forget.

So you are not "asking it nicely" for consistency. You are building a set of files
it is forced to read and a check it is forced to run. That is what this kit is.

**Everything else in here is downstream of one idea: a rule in a document is not a
gate, it is a note. A gate is something that blocks.**
