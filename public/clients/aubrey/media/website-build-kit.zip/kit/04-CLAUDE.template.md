# 04. CLAUDE.md

**When:** Phase 5, the moment the repo exists. Before you build a single page.
**Where it goes:** `CLAUDE.md`, at the root of the repo. Exactly that name.

This is the single most important file in the project. Claude Code reads it
automatically at the start of every session in that folder, forever. You do not
have to remember to load it. That is the whole point.

Two jobs:
1. **The law.** The handful of things that must never be forgotten.
2. **The gate.** The check it must run on its own work before it is allowed to
   tell you it is done.

Keep it **short**. It is not the place for the full spec. It points at the spec.

---

## Copy everything below into `CLAUDE.md` and fill in the brackets

```markdown
# [project name]

Next.js + Tailwind. TypeScript. App Router.
Deployed on Vercel from `main`. A push to `main` is a publish.

## Read before you touch anything
- `docs/BRAND.md`   - the full brand spec. Read it before building ANY page.
- `docs/MESSAGING.md` - the messaging framework. Read it before writing ANY copy.

The rules below are the summary. The spec is the truth. Where they disagree, the
spec wins and you tell me the summary is out of date.

## Brand (law)
- `--bg`     [#______]  page background. Never pure white.
- `--text`   [#______]  all copy. Never pure black.
- `--accent` [#______]  THE ONLY saturated colour on any page. There is no second accent.
- `--dark`   [#______]  dark sections, footer.
- `--muted`  [#______]  secondary text, borders.
- Fonts: [______] (default), [______] ([where it is used]).
- Allowed font weights: [___, ___]. No others.
- Spacing scale: 8, 16, 24, 32, 48, 64, 96. No value outside it.
- Default transition: 0.3s ease, on `transform` and `opacity` only.

## Never
- No rounded corners. `border-radius` is 0 everywhere.
- No gradients.
- No box-shadows.
- No colour that is not in the list above.
- No Title Case. Sentence case everywhere, including buttons and nav.
- No em dashes.
- No stock photography.
- No emoji as decoration.
- No content hidden behind hover. Touch users cannot hover.
- Never animate layout properties (width, height, top, left, margin, padding).
- Never ship an animation without a `prefers-reduced-motion` guard.
- Never cap body copy narrower than the heading above it.
- Never invent a fact, a figure, a date, a price or a claim. If you need one and
  do not have it, stop and ask me.

## Copy
Before writing any copy, read `docs/MESSAGING.md`. Then, before you write a word,
tell me which pillar the page leads with and which specific proof point backs it.
Afterwards, list which framework elements you used.

## Git
- Commit whenever something works. Small commits, clear messages.
- Stage explicit paths. Never `git add .` and never `git commit -am`.
- `npm run build` must pass before any push to `main`.

## THE GATE

You may not tell me a page is finished until you have done all five of these and
shown me the output. Not a summary of the output. The output.

1. **Build.** Run `npm run build`. It must pass. Paste the result.

2. **Grep for banned patterns** in every file you touched, and paste what you
   found:

   | Check | Command | Expected |
   |---|---|---|
   | Rounded corners | `grep -rniE "rounded\|border-radius" <files>` | zero hits |
   | Gradients | `grep -rni "gradient" <files>` | zero hits |
   | Shadows | `grep -rni "shadow" <files>` | zero hits |
   | Off-palette colour | `grep -roE "#[0-9a-fA-F]{3,6}" <files>` | every hit is in the palette above |
   | Title Case | read every heading | sentence case only |
   | Em dashes | `grep -rn " - " <files>` | zero hits |

3. **Look at it.** Screenshot the page at 1440px wide and at 390px wide, and
   actually look at both images. Do not describe a page you have not rendered.
   Tell me what is wrong with it before I have to.

4. **Report the table.** One row per check:

   | Check | What I ran | Expected | Found | Pass/fail |

5. **If any row fails, fix it and run the whole gate again.** Do not show me a
   failing table with an explanation. Show me a passing one.

If you cannot run a check, say so explicitly and say why. Never mark a check as
passed because the code "looks right". Reading your own diff and finding it
convincing is not evidence.

## How I work
- I dictate by voice, so expect typos and odd phrasing. If a word looks like a
  transcription error, infer what I meant. Ask only if the meaning genuinely changes.
- I describe outcomes, not code. "The nav feels cramped" is a valid instruction.
- One job per session.
- If I correct the same thing twice, that is a missing rule. Tell me, and add it
  to the Never list above.
```

---

## Why the gate is written this way

Three things it is doing that a normal "please follow the brand" instruction does
not:

**It names the command.** "Check for rounded corners" is a suggestion. `grep -rniE
"rounded|border-radius"` is a thing that either returns lines or does not.

**It demands the output, not the conclusion.** An agent asked "did you check?" will
say yes. An agent asked to paste the grep output has to actually run the grep.

**It makes looking mandatory.** Step 3 exists because an agent will otherwise
describe, in convincing detail, a page it has never rendered. Make it screenshot
the page and look at the image.

The gate is the difference between a site that stays on brand for a year and one
that quietly rots by page six.
