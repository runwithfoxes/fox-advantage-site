# 07. The chatbot

**When:** Phase 9. The site is live and stable. Not before.
**Time:** An evening.

Three pieces: a key, a server route, a widget. The hard part is none of those. The
hard part is **what it is allowed to say**.

---

## 1. The key

Get one at console.anthropic.com. Put it in `.env.local` at the root of the project:

```
ANTHROPIC_API_KEY=sk-ant-...
```

Now, before you do anything else:

```bash
grep -n "env" .gitignore
```

You must see `.env*` or `.env.local` in there. Next.js puts it in the default
`.gitignore`, but **look with your own eyes**. A key pushed to GitHub is scraped and
abused within minutes, and deleting it afterwards does not help, because it is
already in the commit history and already copied.

**Never paste a key into a document, a chat, a page, or a README.**

Then add the same key in **Vercel → Settings → Environment Variables**, or the
chatbot will work on your laptop and 500 in production.

```bash
npm install @anthropic-ai/sdk
```

---

## 2. The server route

`src/app/api/chat/route.ts`. The key stays here, on the server. It never reaches the
browser.

```ts
import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic();

const SYSTEM = `You are the assistant on [name]'s website.

WHAT YOU KNOW
[Paste the real content here: who he is, what he does, his positions, his
services, his prices, how to get in touch. This should come from docs/MESSAGING.md
and the actual copy on the site. Nothing else.]

HOW YOU SPEAK
[Paste the voice section from docs/MESSAGING.md. The X-not-Y principles and the
never-use list.]

WHAT YOU MUST NEVER DO
- Never invent a figure, a date, a price, a position, or a commitment.
- Never guess. If you do not know, say "I don't know, but I can put you in touch
  with [name]" and offer the contact page.
- Never speculate about what he thinks on a topic he has not published on.
- If asked something you cannot answer from the information above, say so plainly.

Keep answers short. Two or three sentences unless asked for more.`;

export const runtime = "nodejs";

export async function POST(req: Request) {
  const { messages } = await req.json();

  const stream = client.messages.stream({
    model: "claude-opus-4-8",
    max_tokens: 1024,
    system: SYSTEM,
    messages,
  });

  const encoder = new TextEncoder();
  return new Response(
    new ReadableStream({
      async start(controller) {
        try {
          for await (const event of stream) {
            if (
              event.type === "content_block_delta" &&
              event.delta.type === "text_delta"
            ) {
              controller.enqueue(encoder.encode(event.delta.text));
            }
          }
        } catch {
          controller.enqueue(encoder.encode("Sorry, something went wrong."));
        }
        controller.close();
      },
    }),
    { headers: { "Content-Type": "text/plain; charset=utf-8" } },
  );
}
```

Notes on that code, because they matter:

- **`new Anthropic()` with no arguments** reads `ANTHROPIC_API_KEY` from the
  environment. Do not pass the key in as a string. Do not hardcode it.
- **It streams.** The words appear as they are generated. A chatbot that sits silent
  for six seconds and then dumps a paragraph feels broken, even when it isn't.
- **`messages`** is the whole conversation so far, sent from the browser. The API is
  stateless: it remembers nothing between requests, so you send the history every
  time.
- **`claude-opus-4-8`** is the most capable model. If traffic grows and cost becomes
  real, `claude-sonnet-5` is cheaper and still excellent. That is a decision to make
  later, with numbers, not now.

---

## 3. The widget

Ask for it in the site's brand. It is a component like any other, and it obeys
`docs/BRAND.md` like any other.

> "Build a chat widget as a client component. A small launcher in the bottom right
> that opens a panel. It posts the message history to /api/chat and streams the
> reply into the panel as it arrives. Style it strictly from docs/BRAND.md: no
> rounded corners, our colours, our type scale, our 0.3s transitions. It must work
> on a 390px phone. Then run the gate."

The one thing to insist on: **it must never send the key to the browser.** If you
ever see `NEXT_PUBLIC_ANTHROPIC_API_KEY` anywhere, stop. `NEXT_PUBLIC_` means "ship
this to every visitor". That would publish your key to the world.

---

## The part that actually matters

A chatbot that knows nothing is a toy. A chatbot that makes things up is a
liability, and on a public-facing site, a **made-up answer is a quote you did not
say**.

Three rules:

**Give it only your real content.** The pages, the positions, the facts. Nothing
else. It should not be reasoning from the internet, it should be answering from you.

**Give it the messaging framework as its system prompt.** It sounds like the brand
because it has been handed the brand. That is the same document your pages are
written from, so the site and the bot say the same thing.

**Forbid invention, explicitly, in writing.** This is not optional and it is not
paranoia. An agent will produce a confident, friendly, entirely plausible answer to
a question it has no information about, and it will do it in your voice. The
instruction has to be a flat ban with a defined escape hatch: *"If you do not know,
say you do not know and offer to put them in touch."*

---

## Test it like an adversary before it goes live

Do not just ask it easy questions. Sit down and try to make it lie:

- Ask it something you have never published a view on.
- Ask it for a price you have never quoted.
- Ask it what you think about a controversial topic.
- Ask it to commit to something on your behalf. *"Can he do this by Friday?"*
- Tell it something false and see if it agrees with you to be polite.

If it invents anything, tighten the system prompt and go again. **Do not put it on a
live site until you have tried and failed to make it lie.**
