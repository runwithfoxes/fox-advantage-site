# 05. Build prompts

**When:** Phase 6. The repo exists, `CLAUDE.md` is in place, `docs/BRAND.md` and
`docs/MESSAGING.md` are filled in.

Paste these in order. Do not skip the styleguide.

---

## Scaffold (terminal, not a prompt)

```bash
cd ~/projects
npx create-next-app@latest my-site
# TypeScript: yes.  ESLint: yes.  Tailwind: yes.
# src/ directory: yes.  App Router: yes.  Turbopack: yes.
# Custom import alias: no.

cd my-site
npm run dev          # leave this running. localhost:3000

git init
git add -A
git commit -m "Fresh Next.js scaffold"
gh repo create my-site --private --source=. --push
```

Then put `CLAUDE.md`, `docs/BRAND.md` and `docs/MESSAGING.md` in place **before you
build anything.**

---

## Prompt 1: wire the tokens in

> Read `docs/BRAND.md`.
>
> Put every colour from the colours table into `src/app/globals.css` as CSS custom
> properties on `:root`, using exactly the token names in the spec. Mirror them
> into `tailwind.config.ts` so I can use them as Tailwind classes.
>
> Set the base typography (font families, body size, weight, line-height) from the
> spec. Load the fonts with `next/font`.
>
> Add the `prefers-reduced-motion` guard from the spec to `globals.css`.
>
> Set `border-radius` to 0 globally so a stray `rounded` class cannot do anything.
>
> Then run the gate in CLAUDE.md.

---

## Prompt 2: the styleguide (do this BEFORE any real page)

> Build a page at `/styleguide` that renders every element in `docs/BRAND.md`,
> live, not described:
>
> - every colour as a swatch, with its hex and its token name printed underneath
> - the full type scale, each level rendered at its real size with its name, size,
>   weight and letter-spacing labelled
> - every button state
> - the card, at rest and hovered
> - links, at rest and hovered
> - every form field, including the focus state
> - the spacing scale, rendered as blocks so I can see the rhythm
>
> This is for me to check the system. It will not be public. Do not make it pretty,
> make it complete.
>
> Then run the gate.

**Look at this page properly. Fix the system here.** Everything downstream inherits
from it, so an hour spent here saves ten later. It is also the beginning of your
public `/brand` page, so keep it.

---

## Prompt 3: structure before prose (for every page)

> Before you write any code, describe the [about] page to me, section by section.
>
> For each section: what is in it, what job it does, and why it is in that
> position. Tell me which messaging pillar each section is carrying.
>
> Do not code yet. I want to argue with the structure first.

Argue. Reorder. Cut a section. Only when the skeleton is right:

> Good. Build that, exactly as agreed. Do not add sections I did not ask for and
> do not reword the headings we agreed.
>
> Then run the gate.

That last sentence stops the most common failure: the agent silently improving your
approved structure on the way to building it.

---

## Prompt 4: the change loop

This is where you will spend most of your time, and it is all voice. Describe the
outcome, not the code.

> The gap between the heading and the paragraph is too tight.

> The accent colour is doing too much work on this page. Pull it back to just the
> links.

> This section is fine but it is boring. Give me three other ways to lay it out.
> Build all three, screenshot each, and show me the three images side by side.

> It looks wrong on my phone. Screenshot it at 390 wide and tell me what is broken
> before I do.

> That is closer, but you have drifted from the spec. Re-read `docs/BRAND.md`, run
> the gate, and show me the table.

---

## Prompt 5: when it goes sideways

It will. A change breaks something else. Do not patch forward.

```bash
git diff              # what did it actually change
git checkout .        # throw it away, start the instruction again
```

Then re-issue the instruction more precisely. Rewinding is almost always faster
than debugging a change you did not want in the first place.

---

## Prompt 6: when you correct the same thing twice

> You have made that mistake twice now. That means a rule is missing.
>
> Add it to the Never list in `CLAUDE.md`, phrased as a flat ban, and add a grep
> for it to the gate if it is greppable.

This is how the project gets **easier** as it grows rather than harder. Every
correction becomes a permanent gate. Do this religiously for the first two weeks
and the site will more or less defend itself after that.
