# 02. The brand spec template

**When:** Phase 2, straight after brand extraction.
**Where it ends up:** `docs/BRAND.md` in your repo.

Fill every `[ ]`. Delete nothing. If a section genuinely does not apply, write
"Not used" rather than removing it, so nobody wonders later whether it was
forgotten or decided.

---

## Paste this first

> Take the numbers we just extracted and fill in the brand spec template below.
>
> **The test for every single line you write: could a script check this?**
> A hex code, a number, or a flat ban passes. Anything else does not.
> If you write a line I could not check, delete it and replace it with one I could.
>
> "Modern and clean" is not a rule. "No border-radius anywhere" is a rule.
> "Approachable but professional" is not a rule. "Body copy is 16px / 300 / 1.7"
> is a rule.
>
> Where you do not have a real number from the extraction, write `[TO DECIDE]` and
> ask me. Do not invent one.
>
> [paste the template below]

---

# BRAND

> The contract. Every page obeys this. If a page contradicts this file, the page
> is wrong, not the file.
> Last updated: [date]

## 1. Colours

| Token | Hex | Used for |
|---|---|---|
| `--bg` | `[#______]` | Page background. Every page. |
| `--text` | `[#______]` | All body copy and headings. |
| `--accent` | `[#______]` | The one loud colour. Links, CTAs, active states. |
| `--dark` | `[#______]` | Dark sections, footer, nav. |
| `--muted` | `[#______]` | Secondary text, captions, borders. |
| `--line` | `[#______]` | Rules and dividers. |

**Rules**
- `--accent` is the only saturated colour on any page. There is no second accent.
- Never pure black (`#000`) and never pure white (`#FFF`). Use `--text` and `--bg`.
- White text only on `--dark` or `--accent`. Never anywhere else.
- No colour outside this table appears anywhere in the codebase. If you need one,
  it is a change to this file first, not a one-off in a component.
- [ any brand-specific colour ban ]

## 2. Typography

| Level | Font | Size | Weight | Letter-spacing | Used for |
|---|---|---|---|---|---|
| Hero | `[ ]` | `[ ]` | `[ ]` | `[ ]` | Page title, once per page |
| Section heading | `[ ]` | `[ ]` | `[ ]` | `[ ]` | `h2` |
| Sub-heading | `[ ]` | `[ ]` | `[ ]` | `[ ]` | `h3` |
| Body | `[ ]` | `[ ]` | `[ ]` | `[ ]` | Everything else |
| Small | `[ ]` | `[ ]` | `[ ]` | `[ ]` | Captions, meta |
| Label | `[ ]` | `[ ]` | `[ ]` | `[ ]` | Uppercase micro-labels |

**Body line-height: `[ ]`**

**Rules**
- Allowed weights: `[ list them. two or three, no more ]`. No other weight is used.
- **Sentence case everywhere. Never Title Case.** Not in headings, not in buttons,
  not in nav.
- The default font is `[ ]`. The other font is used only for `[ ]`.
- Body copy runs the full width of its container. Never cap a paragraph at a
  narrower width than the heading above it.

## 3. Logo

- Construction: `[ ]`
- Colour: `[ ]`
- Minimum clear space around it: `[ ]`
- Minimum size: `[ ]`

**Never**
- [ ] Never recolour it.
- [ ] Never stretch, rotate or add effects.
- [ ] Never place it on `[ ]`.

## 4. Layout and spacing

- Container max-width: `[ ]`
- Section padding, desktop: `[ ]`
- Section padding, mobile: `[ ]`
- **Spacing scale (the only numbers allowed):** `[ 8, 16, 24, 32, 48, 64, 96 ]`

**Rules**
- No spacing value outside the scale. If 20px feels right, use 16 or 24.
- Body copy runs the full content width. No 560px lede caps.

## 5. Components

### Buttons
| State | Background | Text | Border |
|---|---|---|---|
| Primary, rest | `[ ]` | `[ ]` | `[ ]` |
| Primary, hover | `[ ]` | `[ ]` | `[ ]` |
| Secondary, rest | `[ ]` | `[ ]` | `[ ]` |
| Secondary, hover | `[ ]` | `[ ]` | `[ ]` |

Type: `[ font / size / weight / letter-spacing / case ]`
Padding: `[ ]`
Border-radius: `[ 0 ]`

### Cards
Background `[ ]`, border `[ ]`, padding `[ ]`, hover `[ ]`.

### Links
Rest `[ ]`, hover `[ ]`, underline `[ yes / no ]`.

### Form fields
Border `[ ]`, background `[ ]`, focus state `[ ]`, height `[ ]`.

## 6. Motion

- Default transition: `[ 0.3s ease ]`
- **Only `transform` and `opacity` may be animated.** Never `width`, `height`,
  `top`, `left`, `margin` or `padding`. They make the page stutter.
- Maximum **three or four** moments of motion per page. Not more.
- **`prefers-reduced-motion` must be respected on every animation, always.**

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

## 7. Imagery

- What we use: `[ ]`
- Treatment: `[ ]`
- **Never stock photography.**
- **Text over a photograph must have guaranteed legibility.** Use a scrim, a solid
  panel, or move the text off the image. Contrast must clear 3:1. Never place text
  on a photo and hope.

## 8. Responsive

| Breakpoint | Container padding | Type changes | Layout changes |
|---|---|---|---|
| Desktop | `[ ]` | `[ ]` | `[ ]` |
| `max-width: 768px` | `[ ]` | `[ ]` | `[ ]` |
| `max-width: 380px` | `[ ]` | `[ ]` | `[ ]` |

## 9. Voice

One sentence: `[ we write like ______ ]`

**Principles (X, not Y)**
- `[ ]`, not `[ ]`
- `[ ]`, not `[ ]`
- `[ ]`, not `[ ]`
- `[ ]`, not `[ ]`

**Five sentences I would happily publish**
1. `[ ]`

**Five I would not, and why**
1. `[ ]`

**Never use these words:** `[ list them ]`

## 10. Never do this

The list. Flat, no explanation, no exceptions.

- ✕ Rounded corners
- ✕ Gradients
- ✕ Drop shadows
- ✕ Pure black or pure white
- ✕ A second accent colour
- ✕ Title Case
- ✕ Em dashes
- ✕ Stock photography
- ✕ Emoji as decoration
- ✕ Decorative icons that carry no information
- ✕ Text on a photo with no scrim
- ✕ Content hidden behind hover (touch users cannot hover)
- ✕ Animating layout properties
- ✕ Ignoring `prefers-reduced-motion`
- ✕ More than four moments of motion on a page
- ✕ Any spacing value outside the scale
- ✕ Any colour not in the colours table
- ✕ `[ add your own as you find them ]`

---

**When you catch yourself correcting the same thing twice, that correction belongs
in section 10. Add it, and you never say it again.**
