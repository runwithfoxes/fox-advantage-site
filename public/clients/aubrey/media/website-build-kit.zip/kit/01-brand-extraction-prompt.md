# 01. Brand extraction

**When:** Phase 1. You have ten to fifteen sites' worth of screengrabs in one folder.
**Before you paste:** `cd` into that folder and start Claude Code there.

---

## Paste this (prompt 1 of 3): read the evidence

> Look at every image in this folder. Do not skip any.
>
> For each site, tell me what makes it feel the way it does. Be specific and
> physical, not adjectival. I want:
> - how much white space there is, in rough proportion
> - the type: how big is the hero, how big is the body, what is the ratio between them, what weight, is it a serif or not
> - how many colours are actually on the page (count them), and which one is the loud one
> - are the corners sharp or rounded, and by how much
> - is there any shadow, any gradient, any border
> - does anything move
> - how wide does the body copy run before it wraps
>
> Then, across all of them, find the pattern. Tell me what I appear to be drawn to.
>
> Do not be polite about it. If my taste is inconsistent, say so and show me
> exactly which two sites contradict each other.

---

## Paste this (prompt 2 of 3): force a choice

> Now give me three different directions I could take, each one a paragraph.
>
> Each must be a real choice with a real trade-off, and you must name the
> trade-off. Do not give me a safe middle option, and do not give me three
> variations of the same thing.
>
> For each direction, tell me what it would cost me: what I would have to give up,
> and where it would be hard to hold the line.

Pick one. Say out loud what you picked and why. That sentence is the first line of
your brand spec.

---

## Paste this (prompt 3 of 3): extract the numbers

> I have chosen direction [X].
>
> Go back through the screengrabs that fed that direction and extract the actual
> numbers. I want real values I can put in a spec, not descriptions:
>
> - Every colour, as a hex code. Sample them from the images. Tell me which is the
>   background, which is the text, which is the single accent, which is the dark.
> - The type scale, in px. Hero, section heading, sub-heading, body, small, label.
>   Give me the weight and the letter-spacing for each.
> - The line-height on body copy.
> - The container width and the section padding.
> - The border-radius, if any. The shadow, if any. Say zero if it is zero.
> - Transition durations, if anything moves.
>
> Where you are inferring rather than measuring, say so explicitly. Do not give me
> a confident number you guessed.

That last line matters. An agent will produce a very plausible `#2C3E50` that
exists nowhere in any of your images, and it will not tell you unless you ask.

---

## The rule for this phase

**Do not let it copy a site.** You are extracting a feeling, not cloning a layout.

If it starts producing something that is recognisably one of your reference sites,
stop it:

> That is too close to [site]. I want the underlying principle, not their layout.
> Tell me what principle you were applying, and then apply it differently.
