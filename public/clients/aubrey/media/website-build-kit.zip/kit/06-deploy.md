# 06. Deploy

**When:** Phase 7. You have a homepage you are not embarrassed by.

Four minutes, and then never again.

---

## The first deploy (click, do not paste)

1. **vercel.com** → log in **with GitHub**. Not email. The GitHub link is what
   makes everything after this automatic.
2. **Add New → Project.** It lists your repos. Pick yours.
3. It detects Next.js on its own. **Change nothing.** Click **Deploy**.
4. A minute later you have a live URL: `my-site-xyz.vercel.app`.

That is your site. On the internet. Send it to someone.

---

## What just happened

Vercel is now **watching your GitHub repo**. From here on, this is your entire
deploy process, forever:

```bash
npm run build          # must pass. non-negotiable.
git add src/app/about/page.tsx docs/BRAND.md    # explicit paths, never `git add .`
git commit -m "About page"
git push
```

Live in about a minute.

**"Commit" now means "publish".** Sit with that for a second. It changes how you
work: you commit when something is *right*, not when you are tired.

---

## Your domain

**Vercel → Project → Settings → Domains → Add.**

Type your domain. Vercel tells you the exact DNS records to create. Go to wherever
you bought the domain, paste them in, wait. Usually minutes, occasionally a couple
of hours.

Vercel issues the SSL certificate itself, so HTTPS just appears. You do nothing.

Add **both** `yourdomain.com` and `www.yourdomain.com`, and set one to redirect to
the other. Vercel offers to do this. Say yes.

---

## The two things that will bite you

**1. Vercel only deploys `main`.**
If you are on a branch, your changes are not live, no matter how many times you
commit. This catches everybody once. Check what branch you are on:

```bash
git branch --show-current
```

**2. It builds on Vercel's machine, not yours.**
A page that runs happily on `npm run dev` can still fail the deploy, usually
because of a TypeScript error that `dev` tolerates and `build` does not.

This is exactly why `npm run build` before every push is written into your
`CLAUDE.md`. If it builds locally, it will build there. If you skip it, you will
find out from a red email.

---

## Preview deploys: free, and better than you expect

Push a **branch** instead of `main` and Vercel builds a private URL for that branch
alone.

```bash
git checkout -b new-homepage
# ...work...
git add src/components/Hero.tsx
git commit -m "New hero"
git push -u origin new-homepage
```

Vercel comments the preview URL on the branch. Send it to Paul. He looks at the
real thing, on a real phone, and nothing on your live site has moved.

When you are happy:

```bash
git checkout main
git merge new-homepage
git push          # now it is live
```

**For anything you are unsure about, work on a branch.** It costs nothing and it
means "let me show you something" never means "let me break the live site for
ninety seconds".

---

## Rolling back

You will break something eventually. In Vercel: **Deployments → find the last good
one → ⋯ → Promote to Production.** Live again in seconds.

Knowing this exists is worth more than never needing it.
