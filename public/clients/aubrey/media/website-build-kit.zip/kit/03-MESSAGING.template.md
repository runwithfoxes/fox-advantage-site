# 03. The messaging framework template

**When:** Phase 3. Do it with Paul.
**Where it ends up:** `docs/MESSAGING.md` in your repo.

Five sections, top down. Each one feeds the next, so do not skip ahead. Positioning
is upstream of everything: get it wrong and the pillars will be wrong in a way that
is very hard to see.

---

## Paste this

> Help me fill in the messaging framework below. Work top down: value proposition,
> then positioning, then pillars, then hierarchy, then voice. Do not jump ahead.
>
> **Hard rules:**
> - **Never invent a proof point.** If I have not given you a real fact, a real
>   number or a real named thing, write `[NEED PROOF]` and ask me for it. A
>   plausible-sounding proof point is worse than an empty slot, because I will
>   publish it.
> - A pillar with no proof is not a pillar. Tell me so.
> - "What makes us different" is **one** thing. If I give you three, push back and
>   make me choose.
> - Interview me. Ask one question at a time and wait. Do not fill the whole thing
>   in from what you can guess.
>
> [paste the template below]

---

# MESSAGING

> One source of truth. Every headline, every page, every email traces back to this.
> Last updated: [date]

## 1. Core value proposition

- **The one line:** `[ must survive "so what?" ]`
- **Functional benefit:** `[ concretely, what it does ]`
- **Emotional benefit:** `[ what internal state it resolves ]`
- **Social benefit:** `[ what choosing us says about the person choosing. Delete
  this line if it is not really true. A forced one is worse than none. ]`

## 2. Positioning

The strategic anchor. Everything below hangs off this.

- **Category:** `[ be precise. "HRIS technology consulting", not "consulting" ]`
- **Target audience:** `[ a role, in a situation, with a tension, that creates a
  need. Not a demographic. ]`
- **What makes us different:** `[ ONE thing ]`
- **Proof that it is true:** `[ real, named, checkable ]`

**The statement:**

> For `[audience]` who `[tension]`, `[brand]` is the `[category]` that
> `[key benefit]` because `[proof]`.

## 3. Messaging pillars

Three or four. Each a genuinely different dimension. If two overlap, merge them.

### Pillar 1: `[ name. short, specific, memorable. "Quality service" is not a pillar ]`
- **Claim:** `[ the belief we want the market to accept ]`
- **Proof points:**
  - `[ real fact / number / named thing ]`
  - `[ real fact / number / named thing ]`
- **Competitive contrast:** `[ what others do worse, specifically ]`

### Pillar 2: `[ ]`
- **Claim:** `[ ]`
- **Proof points:** `[ ]`
- **Competitive contrast:** `[ ]`

### Pillar 3: `[ ]`
- **Claim:** `[ ]`
- **Proof points:** `[ ]`
- **Competitive contrast:** `[ ]`

## 4. Messaging hierarchy

Most important to least.

- **Hero message:** `[ the billboard. One line. ]`
- **Primary headline:** `[ the rational backing underneath it ]`
- **Approved lines:** a bank of exact, pre-cleared phrases, so we are not
  rewriting our own boilerplate at midnight.
  - `[ ]`
  - `[ ]`
  - `[ ]`

## 5. Voice and tone

- **Voice, in one sentence, using a metaphor:** `[ e.g. "like a smart colleague
  sharing war stories over coffee" ]`

**Writing principles (X, not Y)**
- `[ ]`, not `[ ]`
- `[ ]`, not `[ ]`
- `[ ]`, not `[ ]`
- `[ ]`, not `[ ]`

**Never use:** `[ actual banned words ]`
**Never do:** `[ actual banned behaviours ]`

## 6. What they say, what we lead with

The entry-point table. When someone arrives thinking this, we open with that.

| What they say / think | What we lead with | Which pillar |
|---|---|---|
| `[ ]` | `[ ]` | `[ ]` |
| `[ ]` | `[ ]` | `[ ]` |
| `[ ]` | `[ ]` | `[ ]` |

---

## The rule that makes this operational

Add this to `CLAUDE.md`, or the framework quietly becomes wallpaper:

```
## Copy
Before writing ANY copy, read docs/MESSAGING.md.
Then, before you write a word, tell me:
  - which pillar this page leads with
  - which specific proof point backs it
Write. Then list which framework elements you used.
Never invent a proof point, a figure, a date or a claim. If you need one and do
not have it, stop and ask.
```

Without that, a pillar decays into a loose label within a fortnight and you are
back to making it up.
